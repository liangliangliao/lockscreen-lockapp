package com.example.lockapp.util

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.R

/**
 * 兜底：当后台启动Activity被系统限制时，用全屏通知拉起LockScreenActivity
 */
object LockFsNotifier {
    private const val CHANNEL_ID = "lock_fsi_channel"
    private const val NOTIFY_ID = 0x90123

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = context.getSystemService(NotificationManager::class.java)
            val existing = nm.getNotificationChannel(CHANNEL_ID)
            if (existing == null) {
                val ch = NotificationChannel(
                    CHANNEL_ID,
                    "Lock Screen Full Screen",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    enableLights(true)
                    enableVibration(true)
                    if (android.os.Build.VERSION.SDK_INT >= 26) setBypassDnd(true)
                    description = "Used to bring up lock screen when background launches are restricted"
                    setShowBadge(false)
                    enableLights(false)
                    enableVibration(false)
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
                nm.createNotificationChannel(ch)
            }
        }
    }

    fun showFullScreen(context: Context) {
        ensureChannel(context)
        val nm = context.getSystemService(NotificationManager::class.java)

        val intent = Intent(context, LockScreenActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)

        val pi = PendingIntent.getActivity(context, 991, intent, (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT else 0)) PendingIntent.FLAG_IMMUTABLE else 0) or
                PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("解锁")
            .setContentText("请验证以继续")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(Notification.CATEGORY_CALL)
            .setDefaults(android.app.Notification.DEFAULT_ALL)
            .setOngoing(true)
            .setAutoCancel(true)
            .setFullScreenIntent(pi, true)

        val n = builder.build()
        nm.notify(NOTIFY_ID, n)

        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            try { nm.cancel(NOTIFY_ID) } catch (_: Throwable) {}
        }, 2000)
    }
}
