
package com.example.lockapp.service

import android.app.*
import android.content.*
import android.os.Build
import android.os.IBinder
import android.content.pm.ServiceInfo
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import androidx.core.app.NotificationCompat
import com.example.lockapp.ui.LockActivity
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.data.LockConfigStore
import com.example.lockapp.data.ActiveLockStore

class GatekeeperService : Service() {
    companion object { const val ACTION_REQUEST_LOCK = "com.example.lockapp.action.REQUEST_LOCK" 
private const val CH_ID = "gatekeeper_fg"
        fun ensureChannel(ctx: Context): String {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = ctx.getSystemService(NotificationManager::class.java)
                if (nm.getNotificationChannel(CH_ID) == null) {
                    nm.createNotificationChannel(
                        NotificationChannel(CH_ID, "Gatekeeper", NotificationManager.IMPORTANCE_MIN).apply {
                            setShowBadge(false)
                            lockscreenVisibility = Notification.VISIBILITY_SECRET
                        }
                    )
                }
            }
            return CH_ID
        }
}
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    // Mark as locked when screen turns off
                    if (LockConfigStore.isArmed(context)) LockStateStore.setLocked(context, true)
                }
                Intent.ACTION_SCREEN_ON -> {
                    // On wake, if locked, launch our LockActivity over keyguard
                    maybeLaunchLock(context)
                }
                Intent.ACTION_USER_PRESENT -> {
                    // If system keyguard gets cleared, we still enforce our own lock if flagged
                    maybeLaunchLock(context)
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundWithNotification()
        // Register dynamic receiver for screen on/off and user present
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        registerReceiver(screenReceiver, filter)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Ensure we respect current lock state when service (re)starts
        if (LockStateStore.isLocked(this)) {
            maybeLaunchLock(this)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun maybeLaunchLock(context: Context) {
        if (!LockStateStore.isLocked(context) || !LockConfigStore.isArmed(context)) return
        val i = Intent(context, LockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
            action = "com.example.lockapp.ACTION_LOCK"
        }
        val pwd = ActiveLockStore.getPwd(context)
            if (!pwd.isNullOrEmpty()) context.startActivity(i)
    }

    private fun startForegroundWithNotification() {
        val channelId = ensureChannel(this)
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        val n = NotificationCompat.Builder(this, channelId)
            .setContentTitle("屏幕锁守护中")
            .setContentText("点击可查看锁屏")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setContentIntent(pi)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(101, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(101, n)
        }
    }

    

    private fun showFullScreenLockNotification() {
        val channelId = "lock_guard_channel"
        val nm = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            if (nm.getNotificationChannel(channelId) == null) {
                nm.createNotificationChannel(android.app.NotificationChannel(channelId, "Lock Guard", android.app.NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Lock guard full-screen notification"
                    lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                })
            }
        }
        val pi = android.app.PendingIntent.getActivity(
            this,
            1001,
            android.content.Intent(this, com.example.lockapp.ui.LockActivity::class.java).apply {
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            (android.app.PendingIntent.FLAG_UPDATE_CURRENT or (if (android.os.Build.VERSION.SDK_INT >= 23) android.app.PendingIntent.FLAG_IMMUTABLE else 0))
        )
        val nb = androidx.core.app.NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("Unlock required")
            .setContentText("Tap to unlock")
            .setPriority(androidx.core.app.NotificationCompat.PRIORITY_MAX)
            .setCategory(androidx.core.app.NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .setFullScreenIntent(pi, true)
        nm.notify(1002, nb.build())
    }
}
