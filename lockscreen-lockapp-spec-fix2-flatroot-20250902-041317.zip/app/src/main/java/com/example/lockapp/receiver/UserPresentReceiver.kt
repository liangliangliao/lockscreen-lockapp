package com.example.lockapp.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.lockapp.data.ActiveLockStore
import com.example.lockapp.data.LockConfigStore
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.service.GatekeeperService

class UserPresentReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try {
            if (!LockConfigStore.isArmed(context)) return
            val pwd = ActiveLockStore.getPwd(context)
            if (pwd.isNullOrEmpty()) return

            // Enforce lock gate on first user-present after a screen cycle
            LockStateStore.setLocked(context, true)

            val svc = Intent(context, GatekeeperService::class.java).apply {
                action = GatekeeperService.ACTION_REQUEST_LOCK
            }
            try { context.startForegroundService(svc) } catch (_: Throwable) { context.startService(svc) }
        } catch (t: Throwable) {
            Log.e("UserPresentReceiver", "failed to launch lock", t)
        }
    }
}