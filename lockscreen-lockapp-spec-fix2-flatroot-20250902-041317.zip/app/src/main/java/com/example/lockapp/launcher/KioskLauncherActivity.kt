package com.example.lockapp.launcher

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import androidx.activity.ComponentActivity
import com.example.lockapp.device.LockAdminReceiver
import com.example.lockapp.data.LockConfigStore
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.ui.LockActivity
import com.example.lockapp.ui.preview.PreviewActivity

class KioskLauncherActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        maybeSetupDeviceOwnerDefaults()
    }

    override fun onResume() {
        super.onResume()
        route()
    }

    private fun route() {
        val armed = LockConfigStore.isArmed(this)
        val locked = LockStateStore.isLocked(this)
        val target = if (armed && locked) LockActivity::class.java else PreviewActivity::class.java
        startActivity(Intent(this, target).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        finish()
    }

    private fun maybeSetupDeviceOwnerDefaults() {
        val dpm = getSystemService(DevicePolicyManager::class.java) ?: return
        if (!dpm.isDeviceOwnerApp(packageName)) return
        val admin = ComponentName(this, LockAdminReceiver::class.java)
        // 1) LockTask 白名单
        try { dpm.setLockTaskPackages(admin, arrayOf(packageName)) } catch (_: Throwable) {}
        // 2) 设为持久默认桌面
        try {
            val filter = IntentFilter(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                addCategory(Intent.CATEGORY_DEFAULT)
            }
            dpm.addPersistentPreferredActivity(admin, filter, ComponentName(this, KioskLauncherActivity::class.java))
        } catch (_: Throwable) {}
    }
}
