package com.example.lockapp.service
import android.app.*
import android.content.*
import android.os.*
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.overlay.OverlayLockService
import com.example.lockapp.util.LockVisibilityTracker

class GatekeeperService : Service() {
    private val prefs by lazy { getSharedPreferences("gatekeeper", MODE_PRIVATE) }
    private fun lastLaunchMs(): Long = prefs.getLong("last_launch_ms", 0L)
    private fun markLaunchNow() { prefs.edit().putLong("last_launch_ms", SystemClock.elapsedRealtime()).apply() }
    private fun shouldLaunch(): Boolean = (SystemClock.elapsedRealtime() - lastLaunchMs()) > 2500L

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_ON -> scheduleGate(context)
                Intent.ACTION_USER_PRESENT, Intent.ACTION_USER_UNLOCKED -> { /* no-op */ }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        startCoreForeground()
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_USER_UNLOCKED)
        }
        registerReceiver(screenReceiver, f)
    }

    override fun onDestroy() {
        try { unregisterReceiver(screenReceiver) } catch (_: Throwable) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        scheduleGate(this)
        return START_STICKY
    }

    private fun startCoreForeground() {
        val chId = "guard_core"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(chId) == null) {
            nm.createNotificationChannel(
                NotificationChannel(chId, "守护服务", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "用于保持解锁守护常驻"
                    setShowBadge(false)
                }
            )
        }
        val notif = NotificationCompat.Builder(this, chId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("锁屏守护已开启")
            .setContentText("确保亮屏/解锁时能及时弹出密码界面")
            .setOngoing(true)
            .build()
        startForeground(7711001, notif)
    }

    private fun scheduleGate(context: Context) {
        val km = getSystemService(KeyguardManager::class.java)

        val intent = Intent(context, LockScreenActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        val pi = PendingIntent.getActivity(
            context, 1, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // 1) 优先 FSI（更通用）
        if (shouldLaunch()) {
            notifyFullScreen(context, pi)
            markLaunchNow()
        }

        // 2) Overlay 兜底（800ms）：已解锁 & 有悬浮窗权限 & 去重
        Handler(Looper.getMainLooper()).postDelayed({
            val unlocked = (km?.isKeyguardLocked == false) && (km?.isDeviceLocked == false)
            if (unlocked && Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(context)) {
                if (shouldLaunch()) {
                    OverlayLockService.show(context)
                    markLaunchNow()
                }
            }
        }, 800)

        // 3) 1.5s FSI 兜底：仍锁 & 不可见 & 去重
        Handler(Looper.getMainLooper()).postDelayed({
            val lockedNow = (km?.isKeyguardLocked == true) || (km?.isDeviceLocked == true)
            if (!LockVisibilityTracker.visible && lockedNow && shouldLaunch()) {
                notifyFullScreen(context, pi)
                markLaunchNow()
            }
        }, 1500)
    }

    private fun notifyFullScreen(context: Context, pendingIntent: PendingIntent) {
        val chId = "gatekeeper_alert_v3"
        val nm = context.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(chId) == null) {
            nm.createNotificationChannel(
                NotificationChannel(chId, "Gate prompt", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Wake and present lock screen"
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                    setBypassDnd(true)
                }
            )
        }
        val n = NotificationCompat.Builder(context, chId)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("需要解锁")
            .setContentText("点击或自动弹出解锁界面")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setDefaults(Notification.DEFAULT_ALL)
            .setCategory(Notification.CATEGORY_CALL)
            .setFullScreenIntent(pendingIntent, true)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(context).notify(20001, n)
    }
}
