package com.example.lockapp.setup
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.lockapp.ui.theme.LockScreenAppTheme

class SetupActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LockScreenAppTheme {
                GuardSetupScreen(onAllDone = {
                    getSharedPreferences("onboarding", MODE_PRIVATE).edit().putBoolean("done", true).apply()
                    finish()
                })
            }
        }
    }
}
