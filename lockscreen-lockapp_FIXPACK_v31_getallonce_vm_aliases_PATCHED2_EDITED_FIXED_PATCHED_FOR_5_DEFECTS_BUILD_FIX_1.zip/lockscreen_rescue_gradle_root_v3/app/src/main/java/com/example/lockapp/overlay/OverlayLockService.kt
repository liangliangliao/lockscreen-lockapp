package com.example.lockapp.overlay

import android.content.Context

/** Minimal no-op overlay service to satisfy references during build. */
object OverlayLockService {
    @JvmStatic fun show(ctx: Context) { /* no-op */ }
    @JvmStatic fun stop(ctx: Context) { /* no-op */ }
}
