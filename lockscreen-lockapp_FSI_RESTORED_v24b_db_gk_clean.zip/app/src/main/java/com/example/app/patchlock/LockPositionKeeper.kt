// BUILD TAG: LOCKAPP-FSI-FIX-CI-20250907T021838Z
package com.example.app.patchlock
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.content.Context
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R

import android.app.Activity
import android.content.Intent
import java.lang.ref.WeakReference

/**
 * Remembers the top activity and a lightweight intent so we can restore the exact place after unlock.
 */
object LockPositionKeeper {
    @Volatile private var lastTopRef: WeakReference<Activity>? = null
    @Volatile private var lastIntent: Intent? = null
    @Volatile private var lastClassName: String? = null

    /** Call from Activity.onResume to capture current top. */
    fun capture(activity: Activity) {
        lastTopRef = WeakReference(activity)
        lastClassName = activity.javaClass.name
        lastIntent = Intent(activity.intent).apply {
            // Keep only component and essential flags; extras trimmed to avoid large transactions.
            replaceExtras(android.os.Bundle())
            addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
    }

    fun clear() {
        lastTopRef = null
        lastIntent = null
        lastClassName = null
    }

    /** Bring the locked page to front if current activity is different. */
    fun restoreIfNeeded(current: Activity) {
        val target = lastClassName ?: return
        val intent = lastIntent ?: return
        if (current.javaClass.name == target) return
        try {
            current.startActivity(intent)
        } catch (_: Throwable) {
            // no-op
        }
    }
}