package com.example.lockapp.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ScreenEventsReceiver(private val onOn: () -> Unit) : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_SCREEN_ON,
            Intent.ACTION_USER_PRESENT -> onOn()
        }
    }
}