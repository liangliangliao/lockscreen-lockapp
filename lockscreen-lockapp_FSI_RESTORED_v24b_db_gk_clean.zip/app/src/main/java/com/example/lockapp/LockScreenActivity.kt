package com.example.lockapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import com.example.lockapp.data.AppDatabase
import com.example.lockapp.data.ImagePasswordRepository
import com.example.lockapp.data.RotationPrefs
import com.example.lockapp.ui.LockScreen
import com.example.lockapp.ui.theme.LockScreenAppTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random

class LockScreenActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        lifecycleScope.launch {
            val db = AppDatabase.get(this@LockScreenActivity)
            val repo = ImagePasswordRepository(db.imagePasswordDao())
            val images = withContext(Dispatchers.IO) { repo.getAllOnce() }

            var pendingIndex = 0
            if (images.isNotEmpty()) {
                val awaiting = RotationPrefs.isAwaiting(this@LockScreenActivity)
                val saved = RotationPrefs.getIndex(this@LockScreenActivity).coerceIn(0, images.size - 1)
                pendingIndex = if (awaiting) {
                    saved
                } else {
                    when (RotationPrefs.getMode(this@LockScreenActivity)) {
                        "rand" -> Random.nextInt(images.size)
                        else -> (saved + 1) % images.size
                    }
                }
            }

            val bgUri = images.getOrNull(pendingIndex)?.uri

            setContent {
                LockScreenAppTheme {
                    LockScreen(
                        backgroundUri = bgUri,
                        onUnlock = {
                            // advance only upon successful unlock
                            lifecycleScope.launch {
                                RotationPrefs.setIndex(this@LockScreenActivity, pendingIndex)
                                RotationPrefs.setAwaiting(this@LockScreenActivity, false)
                            }
                            finish()
                        }
                    )
                }
            }
        }
    }
}