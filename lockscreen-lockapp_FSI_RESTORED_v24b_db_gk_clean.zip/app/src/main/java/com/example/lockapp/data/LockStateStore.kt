package com.example.lockapp.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.lockStateStore by preferencesDataStore("lock_state")

object LockStateStore {
    private val KEY_AWAIT = booleanPreferencesKey("awaiting_unlock")

    fun awaiting(context: Context): Flow<Boolean> =
        context.lockStateStore.data.map { it[KEY_AWAIT] ?: false }

    suspend fun setAwaiting(context: Context, v: Boolean) {
        context.lockStateStore.edit { it[KEY_AWAIT] = v }
    }
}