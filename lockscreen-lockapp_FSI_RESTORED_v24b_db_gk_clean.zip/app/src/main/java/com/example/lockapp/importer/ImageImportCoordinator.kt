// BUILD TAG: LOCKAPP-FSI-FIX-CI-20250907T021838Z

package com.example.lockapp.importer
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.example.lockapp.util.DebugLog
import java.io.File

object ImageImportCoordinator {
    private const val PREFS = "lockapp_prefs"
    @JvmStatic
    fun handlePickedImage(context: Context, uri: Uri): Boolean {
        val appCtx = context.applicationContext
        try {
            try {
                appCtx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                DebugLog.w("Img", "persist uri ok: $uri")
            } catch (t: Throwable) {
                DebugLog.w("Img", "persist uri skipped: ${t.message}")
            }
            val cache = File(appCtx.filesDir, "lock_bg.jpg")
            appCtx.contentResolver.openInputStream(uri)?.use { ins ->
                cache.outputStream().use { outs -> ins.copyTo(outs) }
            }
            val sp = appCtx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            sp.edit()
                .putString("bg_cache_path", cache.absolutePath)
                .putString("bg_uri", uri.toString())
                .putBoolean("lock_enabled", true)
                .apply()
            DebugLog.w("Img", "import ok → cache=${cache.absolutePath}")
            Toast.makeText(appCtx, "图片已导入，伪锁屏已启用", Toast.LENGTH_SHORT).show()
            return true
        } catch (t: Throwable) {
            DebugLog.e("Img", "import failed: ${t.message}", t)
            Toast.makeText(appCtx, "导入失败：${t.message}", Toast.LENGTH_LONG).show()
            return false
        }
    }
}