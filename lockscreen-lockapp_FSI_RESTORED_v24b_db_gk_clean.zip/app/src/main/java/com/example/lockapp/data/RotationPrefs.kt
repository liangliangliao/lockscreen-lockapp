package com.example.lockapp.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first

private val Context.ds by preferencesDataStore("lock_rotation")

object RotationPrefs {
    private val KEY_MODE = stringPreferencesKey("mode")            // "seq" or "rand"
    private val KEY_INDEX = intPreferencesKey("current_index")     // >= 0
    private val KEY_AWAIT = booleanPreferencesKey("awaiting_unlock")

    suspend fun getMode(ctx: Context): String {
        val p = ctx.ds.data.first()
        return p[KEY_MODE] ?: "seq"
    }
    suspend fun setMode(ctx: Context, mode: String) {
        ctx.ds.edit { it[KEY_MODE] = if (mode == "rand") "rand" else "seq" }
    }

    suspend fun getIndex(ctx: Context): Int {
        val p = ctx.ds.data.first(); return p[KEY_INDEX] ?: 0
    }
    suspend fun setIndex(ctx: Context, idx: Int) {
        ctx.ds.edit { it[KEY_INDEX] = idx.coerceAtLeast(0) }
    }

    suspend fun isAwaiting(ctx: Context): Boolean {
        val p = ctx.ds.data.first(); return p[KEY_AWAIT] ?: false
    }
    suspend fun setAwaiting(ctx: Context, v: Boolean) {
        ctx.ds.edit { it[KEY_AWAIT] = v }
    }
}