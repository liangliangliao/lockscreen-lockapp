// Auto-cleaned minimal repository
package com.example.lockapp.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ImagePasswordRepository(private val dao: ImagePasswordDao) {
    suspend fun getAllOnce(): List<ImagePassword> = withContext(Dispatchers.IO) { dao.getAllOnce() }

    suspend fun validatePassword(pass: String): Boolean = withContext(Dispatchers.IO) {
        dao.getAllOnce().any { it.password == pass }
    }
}