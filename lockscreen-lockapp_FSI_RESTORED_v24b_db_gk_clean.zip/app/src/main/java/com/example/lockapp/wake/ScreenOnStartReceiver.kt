// BUILD TAG: LOCKAPP-FSI-FIX-CI-20250907T021838Z
package com.example.lockapp.wake
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R
import com.example.lockapp.util.Toaster

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import android.os.Build
import com.example.lockapp.service.GatekeeperService
import com.example.lockapp.util.DebugTracer

class ScreenOnStartReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        
        Toaster.show5s(context, "检测到亮屏/解锁广播：准备调度全屏弹窗")
DebugTracer.w("ScreenOnStartReceiver", "onReceive action="+(intent?.action ?: ""))
        try { DebugTracer.notify(context, "Trace", "ScreenOnStartReceiver onReceive") } catch (t: Throwable) { }
try {
            ContextCompat.startForegroundService(
                context,
                Intent(context, GatekeeperService::class.java)
                        .setAction("com.example.lockapp.action.BOOST")
                        .addFlags(Intent.FLAG_RECEIVER_FOREGROUND)
            )
        } catch (_: Throwable) {
            try { context.startService(Intent(context, GatekeeperService::class.java)) } catch (_: Throwable) {}
        }
    }
}