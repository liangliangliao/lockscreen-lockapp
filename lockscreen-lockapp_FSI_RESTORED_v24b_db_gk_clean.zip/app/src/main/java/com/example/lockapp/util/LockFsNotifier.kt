package com.example.lockapp.util

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.LockScreenActivity

object LockFsNotifier {
    private const val CH_HEADS_UP_ID = "lockapp_debug_heads_up"
    private const val CH_HEADS_UP_NAME = "LockApp HeadsUp"
    private const val CH_FSI_ID = "lockapp_fsi"
    private const val CH_FSI_NAME = "LockApp FullScreen"

    private fun ensureChannel(ctx: Context, id: String, name: String, importance: Int) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm?.getNotificationChannel(id) == null) {
                nm?.createNotificationChannel(NotificationChannel(id, name, importance))
            }
        }
    }

    private fun defaultContentIntent(ctx: Context): PendingIntent {
        return PendingIntent.getActivity(
            ctx, 1000,
            Intent(ctx, LockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0) or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    fun showDebugHeadsUp(ctx: Context, title: String, text: String) {
        ensureChannel(ctx, CH_HEADS_UP_ID, CH_HEADS_UP_NAME, NotificationManager.IMPORTANCE_HIGH)
        val pi = defaultContentIntent(ctx)
        val n: Notification = NotificationCompat.Builder(ctx, CH_HEADS_UP_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        NotificationManagerCompat.from(ctx).notify(1002, n)
    }

    fun showFullScreen(ctx: Context, title: String, text: String) {
        ensureChannel(ctx, CH_FSI_ID, CH_FSI_NAME, NotificationManager.IMPORTANCE_HIGH)
        val fullPi = defaultContentIntent(ctx)
        val n: Notification = NotificationCompat.Builder(ctx, CH_FSI_ID)
            .setSmallIcon(android.R.drawable.sym_def_app_icon)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(Notification.CATEGORY_CALL)
            .setAutoCancel(true)
            .setFullScreenIntent(fullPi, true)
            .build()
        NotificationManagerCompat.from(ctx).notify(1003, n)
    }
}