// BUILD TAG: LOCKAPP-FSI-FIX-CI-20250907T021838Z
package com.example.app.patchlock
import com.example.lockapp.util.setFullScreenIntent
import android.content.Context
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.util.Toaster
import com.example.lockapp.R

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.lockapp.util.DebugTracer

class LockGuardService : Service() {
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        
        DebugTracer.w("LockGuardService", "LockGuardService onStartCommand")
ensureChannel()
        startForeground(1001, buildOngoing())
        if (AppLockState.shouldLockNow()) notifyFullscreen()
        stopForeground(STOP_FOREGROUND_DETACH)
        stopSelf()
        return START_NOT_STICKY
    }

    private fun notifyFullscreen() {
        val pi = PendingIntent.getActivity(
            this, 100,
            Intent(this, FullscreenLockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, "lock")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.lock_tap_to_unlock))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(Notification.CATEGORY_CALL)
            
Toaster.show5s(this, "正在发送全屏弹窗（FSI）")
.build()er.n.n.setFullScreenIntent(pi, true)
            .setOngoing(true)
            .build()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(2001, n)
    }

    private fun ensureChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel("lock") == null) {
            nm.createNotificationChannel(NotificationChannel("lock", "Lock", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    private fun buildOngoing(): Notification =
        NotificationCompat.Builder(this, "lock")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.lock_guard_running))
            .build()

    override fun onBind(intent: Intent?): IBinder? = null
}