#!/usr/bin/env bash
set -e
echo "BUILD_TAG:"
cat BUILD_TAG.txt || true
echo "List legacy package files:"
find app/src/main/java/com/example/app -type f -name '*.kt' -print 2>/dev/null | sort || true
echo "List active package files:"
find app/src/main/java/com/example/lockapp -type f -name '*.kt' -print 2>/dev/null | sort || true
echo "Search setFullScreenIntent:"
grep -RIn "setFullScreenIntent(" app/src/main/java || true
