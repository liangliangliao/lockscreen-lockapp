import 'package:workmanager/workmanager.dart';
import 'openai_service.dart';

class SchedulerService {
  static Future<void> initBackground() async {
    await Workmanager().initialize(callbackDispatcher, isInDebugMode: false);
  }

  static Future<void> registerPeriodic() async {
    try {
      await Workmanager().registerPeriodicTask(
        'quoteTask',
        'fetchQuoteTask',
        frequency: const Duration(minutes: 15),
        existingWorkPolicy: ExistingWorkPolicy.keep,
        constraints: Constraints(networkType: NetworkType.connected),
      );
    } catch (_) {}
  }
}

@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, input) async {
    await OpenAIService.fetchAndStoreQuote();
    return Future.value(true);
  });
}
