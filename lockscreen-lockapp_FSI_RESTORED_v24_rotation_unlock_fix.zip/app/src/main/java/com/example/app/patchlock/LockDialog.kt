// BUILD TAG: LOCKAPP-FSI-FIX-CI-20250907T021838Z
package com.example.app.patchlock
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.content.Context
import android.content.Intent
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R

import android.app.Activity
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.first
import com.example.lockapp.LockScreenApp
import com.example.lockapp.data.ImagePasswordRepository
import com.example.lockapp.data.RotationManager
import com.example.lockapp.data.RotationMode

object LockDialog {
    private const val TAG = "PatchLockDialog"
    @Volatile private var isShowing = false

    fun show(activity: Activity) {
        val fa = activity as? FragmentActivity ?: return
        if (isShowing || fa.supportFragmentManager.findFragmentByTag(TAG) != null) return

        val dialog = object: DialogFragment() {
            private var ivBg: ImageView? = null

            override fun onCreate(savedInstanceState: Bundle?) {
                super.onCreate(savedInstanceState)
                setStyle(STYLE_NORMAL, android.R.style.Theme_DeviceDefault_Light_NoActionBar_Fullscreen)
                isCancelable = false
            }

            override fun onCreateView(
                inflater: LayoutInflater,
                container: ViewGroup?,
                savedInstanceState: Bundle?
            ): View? {
                val view = inflater.inflate(R.layout.patch_fragment_password_dialog, container, false)
                ivBg = view.findViewById(R.id.ivLockBg)
                val et = view.findViewById<EditText>(R.id.etPassword)
                val btn = view.findViewById<Button>(R.id.btnUnlock)

                // Load next background on show
                viewLifecycleOwner.lifecycleScope.launch {
                    val app = requireContext().applicationContext as LockScreenApp
                    val dao = app.database.imagePasswordDao()
                    val repo = ImagePasswordRepository(dao)
                    val rotation = RotationManager(requireContext().applicationContext)

                    val entries = withContext(Dispatchers.IO) { repo.getAllOnce() }
                    if (entries.isNotEmpty()) {
                        val mode = rotation.rotationMode.first()
                        val lastIndex = rotation.lastIndex.first()
                        val nextIndex = when (mode) {
                            RotationMode.SEQUENTIAL -> (lastIndex + 1).mod(entries.size)
                            RotationMode.SHUFFLE -> {
                                if (entries.size == 1) 0 else {
                                    val indices = entries.indices.toMutableList()
                                    if (lastIndex in indices && indices.size > 1) indices.remove(lastIndex)
                                    indices.random()
                                }
                            }
                        }
                        withContext(Dispatchers.IO) { rotation.setLastIndex(nextIndex) }
                        val uri = Uri.parse(entries[nextIndex].uri)
                        ivBg?.setImageURI(uri)
                    }
                }

                btn.setOnClickListener {
                    val input = et.text?.toString()?.trim() ?: ""
                    val expected = com.example.lockapp.data.ActiveLockStore.getActivePassword(requireContext())
                    if (expected != null && input == expected) {
                        com.example.lockapp.util.LockCoordinator.markUnlocked(requireContext())
                        activity?.let { LockPositionKeeper.restoreIfNeeded(it) }
                        com.example.lockapp.util.LockCoordinator.leaveShowing(); dismissAllowingStateLoss()
                        parentFragmentManager.setFragmentResult("unlock", Bundle())
                    } else {
                        Toast.makeText(requireContext(), getString(R.string.wrong_password), Toast.LENGTH_SHORT).show()
                    }
                }
                return view
            }

            override fun onStart() { super.onStart(); isShowing = true }
            override fun onDestroyView() { super.onDestroyView(); isShowing = false; ivBg = null }
        }
        dialog.show(fa.supportFragmentManager, TAG)
    }
}