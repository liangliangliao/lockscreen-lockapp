// BUILD TAG: LOCKAPP-FIX-DEBUGLOG-20250907
package com.example.lockapp.util

import android.util.Log

object DebugLog {
    private const val TAG_BASE = "LockApp"

    @JvmStatic fun w(tag: String, msg: String, tr: Throwable? = null) {
        if (tr != null) Log.w("$TAG_BASE/$tag", msg, tr) else Log.w("$TAG_BASE/$tag", msg)
    }

    @JvmStatic fun i(tag: String, msg: String) {
        Log.i("$TAG_BASE/$tag", msg)
    }

    @JvmStatic fun e(tag: String, msg: String, tr: Throwable? = null) {
        if (tr != null) Log.e("$TAG_BASE/$tag", msg, tr) else Log.e("$TAG_BASE/$tag", msg)
    }
}