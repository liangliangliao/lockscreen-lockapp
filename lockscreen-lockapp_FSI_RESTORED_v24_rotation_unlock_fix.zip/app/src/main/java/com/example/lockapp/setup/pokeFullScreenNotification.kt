
package com.example.lockapp.setup

import android.content.Context
import com.example.lockapp.util.LockFsNotifier

/**
 * Small helper used in setup to nudge a full-screen notification once.
 */
fun pokeFullScreenNotification(context: Context) {
    LockFsNotifier.showFullScreen(context, title = "Lock Screen Ready", text = "Tap to preview the lock screen")
}