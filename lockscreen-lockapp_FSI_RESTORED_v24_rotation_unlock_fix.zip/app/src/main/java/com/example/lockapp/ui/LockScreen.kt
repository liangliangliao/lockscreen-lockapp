package com.example.lockapp.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.lockapp.data.AppDatabase
import com.example.lockapp.data.ImagePasswordRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun LockScreen(
    backgroundUri: String?,
    onUnlock: () -> Unit
) {
    val ctx = LocalContext.current
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Box(Modifier.fillMaxSize()) {
        AsyncImage(
            model = backgroundUri ?: "",
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Column(
            Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("输入密码") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation()
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = {
                scope.launch {
                    val db = AppDatabase.get(ctx)
                    val repo = ImagePasswordRepository(db.imagePasswordDao())
                    val ok = withContext(Dispatchers.IO) { repo.validatePassword(password) }
                    if (ok) {
                        onUnlock()
                    } else {
                        error = "密码错误"
                    }
                }
            }) { Text("解锁") }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }
}