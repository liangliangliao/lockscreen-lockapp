package com.example.lockapp.util

object CompatIcons {
    // Use platform drawable to avoid app mipmap dependency in CI
    val LAUNCHER_ICON = android.R.drawable.sym_def_app_icon
}