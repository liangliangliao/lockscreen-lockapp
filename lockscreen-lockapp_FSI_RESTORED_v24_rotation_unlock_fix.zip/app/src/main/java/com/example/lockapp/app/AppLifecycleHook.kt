package com.example.lockapp.app

interface AppLifecycleHook {
    fun onAppForeground() {}
    fun onAppBackground() {}
}