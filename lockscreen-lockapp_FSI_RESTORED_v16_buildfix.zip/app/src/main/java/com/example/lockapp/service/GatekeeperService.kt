// BUILD TAG: LOCKAPP-FSI-RUNTIME-RECEIVER-20250907-REWRITE
package com.example.lockapp.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.util.DebugLog
import com.example.lockapp.util.Toaster

class GatekeeperService : Service() {

    private var registered = false

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.action
            DebugLog.i("GatekeeperService", "onReceive action=$action")
            if (Intent.ACTION_SCREEN_ON == action) {
                try { Toaster.show5s(this@GatekeeperService, "收到亮屏广播") } catch (_: Throwable) {}
                showFullScreenLock(context)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForeground(1902, buildOngoingNotification(this))
        registerScreenReceivers()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val reason = intent?.getStringExtra("reason")
        DebugLog.i("GatekeeperService", "onStartCommand reason=$reason")
        if (reason == "screen_on") {
            showFullScreenLock(this)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        if (registered) {
            try { unregisterReceiver(screenReceiver) } catch (_: Throwable) {}
            registered = false
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun registerScreenReceivers() {
        if (registered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        registerReceiver(screenReceiver, filter)
        registered = true
        try { Toaster.show5s(this, "已注册亮屏监听（运行时）") } catch (_: Throwable) {}
    }

    private fun buildOngoingNotification(ctx: Context): Notification {
        val channelId = "lock_keepalive"
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            if (nm.getNotificationChannel(channelId) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(channelId, "Lock keepalive", NotificationManager.IMPORTANCE_MIN).apply {
                        description = "Keeps lock service running"
                        setShowBadge(false)
                        lockscreenVisibility = Notification.VISIBILITY_SECRET
                    }
                )
            }
        }
        val pi = PendingIntent.getActivity(
            ctx, 1903,
            Intent(ctx, LockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0) or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(ctx, channelId)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("Lock service active")
            .setContentText("Improving reliability")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(pi)
            .build()
    }

    private fun showFullScreenLock(ctx: Context) {
        val channelId = "lock_fsi"
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            if (nm.getNotificationChannel(channelId) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(channelId, "Lock FSI", NotificationManager.IMPORTANCE_HIGH).apply {
                        description = "Full-screen lock prompt"
                        setBypassDnd(true)
                        lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                    }
                )
            }
        }
        val pi = PendingIntent.getActivity(
            ctx, 2102,
            Intent(ctx, LockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0) or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("需要解锁")
            .setContentText("点击以打开解锁界面")
            .setCategory(Notification.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setFullScreenIntent(pi, true)
            .build()
        NotificationManagerCompat.from(ctx).notify(2101, n)
        try { Toaster.show5s(this, "已发出全屏解锁通知") } catch (_: Throwable) {}
    }
}
