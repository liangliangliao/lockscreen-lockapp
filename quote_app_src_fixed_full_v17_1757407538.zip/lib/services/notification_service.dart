import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    const android = AndroidInitializationSettings('@android:drawable/sym_def_app_icon');
    const init = InitializationSettings(android: android);
    await _plugin.initialize(init);
    const channel = AndroidNotificationChannel(
      'quote_channel', 'Quote Updates',
      description: 'Notifications for new quotes',
      importance: Importance.defaultImportance,
    );
    final an = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await an?.createNotificationChannel(channel);
  }

  static Future<void> showQuote(String text) async {
    const androidDetails = AndroidNotificationDetails(
      'quote_channel', 'Quote Updates',
      channelDescription: 'Notifications for new quotes',
      importance: Importance.defaultImportance,
      priority: Priority.defaultPriority,
      icon: '@android:drawable/sym_def_app_icon',
    );
    const details = NotificationDetails(android: androidDetails);
    await _plugin.show(1, '新的名人名言', text, details);
  }
}


import 'dart:convert';
import '../data/dao.dart';

class NotificationOrchestrator {
  static Future<void> checkAndNotifyNewQuotes() async {
    final dao = QuoteDao();
    final sdao = ScheduleDao();
    final quotes = await dao.fetchUnnotified();
    if (quotes.isEmpty) return;
    final schedules = await sdao.all();
    final now = DateTime.now();
    for (final q in quotes) {
      final createdAt = DateTime.fromMillisecondsSinceEpoch((q['created_at'] as int));
      final should = _shouldNotifyNow(now, schedules, createdAt);
      if (should) {
        final text = q['text'] as String;
        await NotificationService.showQuote(text);
        await dao.markNotified(q['id'] as int);
      }
    }
  }

  static bool _shouldNotifyNow(DateTime now, List<Map<String,dynamic>> schedules, DateTime createdAt) {
    if (schedules.isEmpty) return false;
    for (final s in schedules) {
      if ((s['enabled'] ?? 1) == 0) continue;
      final type = s['type'] as String;
      final payloadRaw = s['payload'];
      final Map<String,dynamic> payload = payloadRaw is String ? jsonDecode(payloadRaw) : (payloadRaw as Map<String,dynamic>);
      if (type == 'daily') {
        final t = payload['time'] as String? ?? '00:00:00';
        final parts = t.split(':');
        if (parts.length >= 2) {
          final h = int.tryParse(parts[0]) ?? 0;
          final m = int.tryParse(parts[1]) ?? 0;
          final sec = parts.length > 2 ? int.tryParse(parts[2]) ?? 0 : 0;
          final todayT = DateTime(now.year, now.month, now.day, h, m, sec);
          if (now.isAfter(todayT) || now.isAtSameMomentAs(todayT)) return true;
        }
      } else if (type == 'weekly') {
        final weekday = (payload['weekday'] ?? 1) as int; // 1-7 Mon-Sun
        final t = (payload['time'] ?? '00:00:00') as String;
        final parts = t.split(':');
        final h = int.tryParse(parts[0]) ?? 0;
        final m = int.tryParse(parts[1]) ?? 0;
        final sec = parts.length > 2 ? int.tryParse(parts[2]) ?? 0 : 0;
        if (now.weekday == weekday) {
          final todayT = DateTime(now.year, now.month, now.day, h, m, sec);
          if (now.isAfter(todayT) || now.isAtSameMomentAs(todayT)) return true;
        }
      } else if (type == 'custom') {
        final date = (payload['date'] ?? '') as String; // yyyy-MM-dd
        final time = (payload['time'] ?? '00:00:00') as String;
        try {
          final dt = DateTime.parse('$date ${time.split('.').first}');
          if (now.isAfter(dt) || now.isAtSameMomentAs(dt)) return true;
        } catch (_) {}
      }
    }
    return false;
  }
}
