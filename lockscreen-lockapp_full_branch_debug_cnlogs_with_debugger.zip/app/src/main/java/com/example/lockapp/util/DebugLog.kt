package com.example.lockapp.util

import android.util.Log

object DebugLog {
    private const val BASE = "LOCKAPP/调试"
    @JvmStatic fun i(tag: String, msg: String) { Log.i("$BASE/$tag", msg) }
    @JvmStatic fun d(tag: String, msg: String) { Log.d("$BASE/$tag", msg) }
    @JvmStatic fun w(tag: String, msg: String, tr: Throwable? = null) { if (tr!=null) Log.w("$BASE/$tag", msg, tr) else Log.w("$BASE/$tag", msg) }
    @JvmStatic fun e(tag: String, msg: String, tr: Throwable? = null) { if (tr!=null) Log.e("$BASE/$tag", msg, tr) else Log.e("$BASE/$tag", msg) }
}