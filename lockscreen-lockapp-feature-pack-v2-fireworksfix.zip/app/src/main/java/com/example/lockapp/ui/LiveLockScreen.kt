
package com.example.lockapp.ui

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.lockapp.data.ActiveLockStore
import com.example.lockapp.data.AppDatabase
import androidx.room.Room
import com.example.lockapp.data.ImagePassword
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun LiveLockScreen(onUnlock: () -> Unit = {}) {
    val ctx = LocalContext.current
    val dao = remember { Room.databaseBuilder(ctx, AppDatabase::class.java, "lockapp.db").allowMainThreadQueries().build().imagePasswordDao() }
    var entry by remember { mutableStateOf<ImagePassword?>(null) }
    var showInput by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var isBgLight by remember { mutableStateOf(false) }

    // Load the active entry from storage
    LaunchedEffect(Unit) {
        val uri = ActiveLockStore.getActiveUri(ctx)
        val all = withContext(Dispatchers.IO) { dao.getAllOnce() }
        entry = all.firstOrNull { it.uri == uri } ?: all.firstOrNull()
        // Rough luminance estimation from a small sample to adapt colors
        entry?.let { e ->
            withContext(Dispatchers.IO) {
                ctx.contentResolver.openInputStream(Uri.parse(e.uri))?.use { input ->
                    val bmp = BitmapFactory.decodeStream(input)
                    if (bmp != null) {
                        var sum = 0L; var cnt=0
                        val stepX = (bmp.width/8).coerceAtLeast(1)
                        val stepY = (bmp.height/8).coerceAtLeast(1)
                        for (y in 0 until bmp.height step stepY) {
                            for (x in 0 until bmp.width step stepX) {
                                val c = bmp.getPixel(x,y)
                                val r = (c shr 16 and 0xFF)
                                val g = (c shr 8 and 0xFF)
                                val b = (c and 0xFF)
                                val lum = (0.299*r + 0.587*g + 0.114*b).toInt()
                                sum += lum; cnt++
                            }
                        }
                        isBgLight = (sum.toFloat()/cnt) > 140f
                        bmp.recycle()
                    }
                }
            }
        }
    }

    val infinite = rememberInfiniteTransition(label = "live-bounce")
    val scale by infinite.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    val borderColors = listOf(Color.Magenta, Color.Cyan, Color.Yellow, Color.Magenta)
    val textColor = if (isBgLight) Color.Black else Color.White
    val fieldColors = TextFieldDefaults.colors(
        focusedIndicatorColor = Color.Transparent,
        unfocusedIndicatorColor = Color.Transparent,
        focusedContainerColor = if (isBgLight) Color(0xCCFFFFFF) else Color(0x55000000),
        unfocusedContainerColor = if (isBgLight) Color(0xB3FFFFFF) else Color(0x44000000),
        focusedTextColor = textColor,
        unfocusedTextColor = textColor,
        cursorColor = textColor
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectVerticalDragGestures { change, dragAmount ->
                    if (dragAmount < -20) { // upward
                        showInput = true
                    }
                }
            }
            .border(androidx.compose.foundation.BorderStroke(6.dp, Brush.linearGradient(borderColors)))
    ) {
        entry?.let { e ->
            AsyncImage(
                model = ImageRequest.Builder(ctx).data(Uri.parse(e.uri)).crossfade(true).build(),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = scale; scaleY = scale
                    },
                contentScale = androidx.compose.ui.layout.ContentScale.Crop
            )
        }
        FireworksOverlay()

        // Center input when requested
        if (showInput) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it.take(100) },
                    label = { Text("Password", color = textColor) },
                    placeholder = { Text("Enter password", color = textColor.copy(alpha=0.7f)) },
                    singleLine = true,
                    visualTransformation = VisualTransformation.None,
                    colors = fieldColors
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = {
                    if (input == entry?.password) {
                        onUnlock()
                    } else {
                        // shake/error - for now snackbar
                        // (Compose Material3 snackbar needs Scaffold; use simple text)
                        // Keep screen blocked.
                    }
                }) {
                    Text("解锁", color = Color.White)
                }
                if (entry != null && input.isNotEmpty() && input != entry!!.password) {
                    Spacer(Modifier.height(8.dp))
                    Text("密码不正确", color = Color.Red)
                }
            }
        }
    }
}

}
}
