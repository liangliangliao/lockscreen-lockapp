package com.example.lockapp.setup

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.LockScreenActivity

fun pokeFullScreenNotification(ctx: Context) {
    val chId = "lock_fullscreen_test"
    if (Build.VERSION.SDK_INT >= 26) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(chId) == null) {
            val ch = NotificationChannel(chId, "Lock Test FS", NotificationManager.IMPORTANCE_HIGH).apply {
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            nm.createNotificationChannel(ch)
        }
    }
    val i = Intent(ctx, LockScreenActivity::class.java)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        .setAction("com.example.lockapp.SHOW_LOCK")
    val piFlags = if (Build.VERSION.SDK_INT >= 23)
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT else 0
    val pi = PendingIntent.getActivity(ctx, 992, i, piFlags)

    val n = NotificationCompat.Builder(ctx, chId)
        .setSmallIcon(android.R.drawable.ic_lock_lock)
        .setContentTitle("测试全屏唤醒")
        .setContentText("点击或自动弹出解锁界面")
        .setCategory(Notification.CATEGORY_CALL)
        .setDefaults(Notification.DEFAULT_ALL)
        .setOngoing(false)
        .setFullScreenIntent(pi, true)
        .apply { if (Build.VERSION.SDK_INT < 26) priority = NotificationCompat.PRIORITY_MAX }
        .build()

    NotificationManagerCompat.from(ctx).notify(10086, n)
}