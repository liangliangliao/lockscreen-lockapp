package com.example.lockapp.util

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.R

object LockFsNotifier {
    private const val CHANNEL_ID = "lock_fullscreen"
    private const val CHANNEL_NAME = "Lock FullScreen"
    private const val NOTIFY_ID = 0xD00D

    fun showFullScreen(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            val existing = nm.getNotificationChannel(CHANNEL_ID)
            if (existing == null) {
                val ch = NotificationChannel(
                    CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Show lock screen over keyguard"
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
                nm.createNotificationChannel(ch)
            }
        }

        val intent = Intent(context, LockScreenActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
            .setAction("com.example.lockapp.SHOW_LOCK")

        val piFlags = if (Build.VERSION.SDK_INT >= 23)
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT else 0
        val pi = PendingIntent.getActivity(context, 991, intent, piFlags)

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_lock_patch)
            .setContentTitle(context.getString(R.string.app_name))
            .setContentText(context.getString(R.string.lock_guard_running))
            .setCategory(Notification.CATEGORY_CALL)
            .setDefaults(Notification.DEFAULT_ALL)
            .setOngoing(true)
            .setAutoCancel(true)
            .setFullScreenIntent(pi, true)

        if (Build.VERSION.SDK_INT < 26) {
            builder.priority = NotificationCompat.PRIORITY_MAX
        }

        val n = builder.build()
        nm.notify(NOTIFY_ID, n)

        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            try { nm.cancel(NOTIFY_ID) } catch (_: Throwable) {}
        }, 2000)
    }
}