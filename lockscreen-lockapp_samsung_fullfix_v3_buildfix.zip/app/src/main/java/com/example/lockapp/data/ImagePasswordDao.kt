package com.example.lockapp.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * Data access object (DAO) exposing methods to read and write [ImagePassword] records.
 */
@Dao
interface ImagePasswordDao {
    /**
     * Observes all image/password entries as a Flow, ordered by their [orderIndex].
     */
    @Query("SELECT * FROM image_password ORDER BY orderIndex ASC")
    fun getAll(): Flow<List<ImagePassword>>

    /**
     * Synchronously retrieves all entries in one shot. Useful for non-reactive reads.
     */
    @Query("SELECT * FROM image_password ORDER BY orderIndex ASC")
    suspend fun getAllOnce(): List<ImagePassword>

    /**
     * Inserts or replaces an [ImagePassword] entry. When [id] matches an existing record
     * the record is replaced. Otherwise a new entry is created.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: ImagePassword)

    /** Deletes the given [item]. */
    @Delete
    suspend fun delete(item: ImagePassword)

    /**
     * Updates one or more [items]. This is useful when adjusting order indices or
     * modifying the password associated with an image.
     */
    @Update
    suspend fun update(vararg items: ImagePassword)
}