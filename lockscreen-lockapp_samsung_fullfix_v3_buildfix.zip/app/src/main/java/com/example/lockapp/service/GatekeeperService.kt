package com.example.lockapp.service

import android.app.*
import android.content.*
import android.os.*
import android.view.Display
import android.hardware.display.DisplayManager
import androidx.core.app.NotificationCompat
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.R
import com.example.lockapp.util.LockCoordinator
import com.example.lockapp.util.LockFsNotifier
import com.example.lockapp.util.LockVisibilityTracker

class GatekeeperService : Service() {

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    LockVisibilityTracker.visible = false
                    LockCoordinator.markLocked(context)
                    LockCoordinator.leaveShowing()
                }
                Intent.ACTION_SCREEN_ON -> {
                    // Safety timeout: release gating if UI still not visible
                    Handler(Looper.getMainLooper()).postDelayed({
                        if (!LockVisibilityTracker.visible && LockCoordinator.isLocked(context)) {
                            try { LockCoordinator.releaseShowOnce() } catch (_: Throwable) {}
                        }
                    }, 900)

                    if (!LockCoordinator.isLocked(context)) return

                    // Short wakelock to keep CPU
                    try {
                        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
                        pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lockapp:screenon").apply {
                            acquire(2000)
                        }
                    } catch (_: Throwable) {}

                    // Slight delay for interactivity
                    Handler(Looper.getMainLooper()).postDelayed({
                        if (!LockCoordinator.isLocked(context) || LockVisibilityTracker.visible) return@postDelayed
                        try {
                            val i = Intent(context, LockScreenActivity::class.java)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or
                                          Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS or
                                          Intent.FLAG_ACTIVITY_NO_USER_ACTION or
                                          Intent.FLAG_ACTIVITY_SINGLE_TOP)
                                .setAction("com.example.lockapp.SHOW_LOCK")
                            context.startActivity(i)
                        } catch (_: Throwable) {
                            try { LockFsNotifier.showFullScreen(context) } catch (_: Throwable) {}
                        }
                        // Fallback after 200ms
                        Handler(Looper.getMainLooper()).postDelayed({
                            if (!LockVisibilityTracker.visible && LockCoordinator.isLocked(context)) {
                                try { LockFsNotifier.showFullScreen(context) } catch (_: Throwable) {}
                            }
                        }, 200)
                    }, 150)
                }
            }
        }
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {}
    }

    override fun onCreate() {
        super.onCreate()
        ensureFgChannel(this)
        startForeground(7, fgNotification())
        // dynamic register screen intents
        registerReceiver(screenReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        })
        (getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager)?.registerDisplayListener(displayListener, null)
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(screenReceiver) } catch (_: Throwable) {}
        try { (getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager)?.unregisterDisplayListener(displayListener) } catch (_: Throwable) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun fgNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 100,
            Intent(this, LockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT else 0
        )
        return NotificationCompat.Builder(this, FG_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_lock_patch)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.lock_guard_running))
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val FG_CHANNEL_ID = "gatekeeper_fg"
        private fun ensureFgChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= 26) {
                val nm = context.getSystemService(NotificationManager::class.java)
                if (nm.getNotificationChannel(FG_CHANNEL_ID) == null) {
                    val ch = NotificationChannel(FG_CHANNEL_ID, "Gatekeeper", NotificationManager.IMPORTANCE_MIN).apply {
                        setShowBadge(false)
                        lockscreenVisibility = Notification.VISIBILITY_SECRET
                    }
                    nm.createNotificationChannel(ch)
                }
            }
        }
    }
}