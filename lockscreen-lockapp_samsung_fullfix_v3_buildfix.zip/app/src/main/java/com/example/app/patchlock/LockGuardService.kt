package com.example.app.patchlock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.lockapp.R

class LockGuardService : Service() {
    override fun onCreate() {
        super.onCreate()
        ensureChannel(this)
        startForeground(1001, buildOngoing())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildOngoing(): Notification =
        NotificationCompat.Builder(this, "lock_guard_fg")
            .setSmallIcon(R.drawable.ic_lock_patch)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.lock_guard_running))
            .setOngoing(true)
            .build()

    companion object {
        private const val CHANNEL_ID = "lock_guard_fg"
        private fun ensureChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= 26) {
                val nm = context.getSystemService(NotificationManager::class.java)
                if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                    nm.createNotificationChannel(
                        NotificationChannel(CHANNEL_ID, "Lock Guard", NotificationManager.IMPORTANCE_MIN).apply {
                            setShowBadge(false)
                            lockscreenVisibility = Notification.VISIBILITY_SECRET
                        }
                    )
                }
            }
        }
    }
}