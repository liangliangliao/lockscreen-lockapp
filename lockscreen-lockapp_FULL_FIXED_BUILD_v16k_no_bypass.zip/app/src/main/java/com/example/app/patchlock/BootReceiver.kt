package com.example.app.patchlock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.lockapp.util.DebugTracer

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        
        DebugTracer.w("BootReceiver", "onReceive action="+(intent?.action ?: ""))
        try { DebugTracer.notify(context, "Trace", "BootReceiver onReceive") } catch (t: Throwable) { }
try {
            context.startForegroundService(Intent(context, LockGuardService::class.java))
        } catch (_: Throwable) {}
    }
}