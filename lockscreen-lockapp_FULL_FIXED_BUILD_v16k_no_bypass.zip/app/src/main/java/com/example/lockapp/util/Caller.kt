package com.example.lockapp.util

object Caller {
    @JvmStatic
    fun tag(skip: Int = 3): String {
        return try {
            val st = Throwable().stackTrace
            if (st.size > skip) {
                val el = st[skip]
                val cls = el.className.substringAfterLast('.')
                "${'$'}cls.${'$'}{el.methodName}:${'$'}{el.lineNumber}"
            } else {
                "unknown"
            }
        } catch (_: Throwable) {
            "unknown"
        }
    }
}