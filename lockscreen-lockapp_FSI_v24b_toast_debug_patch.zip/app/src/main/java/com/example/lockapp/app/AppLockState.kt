package com.example.lockapp.app

enum class AppLockState { FOREGROUND, BACKGROUND, UNKNOWN }