package com.example.lockapp.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.R
import com.example.lockapp.data.RotationPrefs
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class GatekeeperService : Service() {

    private val channelId = "lock_gatekeeper"
    private var registered = false
    private val screenReceiver = ScreenEventsReceiver { onScreenOn() }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(2100, buildOngoingNotification())
        registerReceivers()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        if (registered) {
            try { unregisterReceiver(screenReceiver) } catch (_: Throwable) {}
            registered = false
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(channelId, "Lock Gatekeeper", NotificationManager.IMPORTANCE_HIGH)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun buildOngoingNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 2001,
            Intent(this, LockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0) or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("锁屏守护运行中")
            .setContentText("监听亮屏，保护锁屏")
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
    }

    private fun registerReceivers() {
        if (registered) return
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        registerReceiver(screenReceiver, f)
        registered = true
    }

    private fun onScreenOn() {
        // 标记等待解锁，并发出全屏通知以拉起锁屏界面
        GlobalScope.launch { RotationPrefs.setAwaiting(this@GatekeeperService, true) }
        showFullScreenLock()
    }

    private fun showFullScreenLock() {
        val pi = PendingIntent.getActivity(
            this, 2102,
            Intent(this, LockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0) or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("解锁")
            .setContentText("点击以解锁")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(Notification.CATEGORY_CALL)
            .setAutoCancel(true)
            .setFullScreenIntent(pi, true)
            .build()
        NotificationManagerCompat.from(this).notify(2101, n)
    }
}