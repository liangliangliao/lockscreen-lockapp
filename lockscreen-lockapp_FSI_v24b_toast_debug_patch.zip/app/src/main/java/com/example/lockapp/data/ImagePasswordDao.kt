// Auto-cleaned minimal DAO
package com.example.lockapp.data

import androidx.room.*

@Dao
interface ImagePasswordDao {
    @Query("SELECT * FROM image_password ORDER BY orderIndex ASC, id ASC")
    suspend fun getAllOnce(): List<ImagePassword>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: ImagePassword): Long

    @Delete
    suspend fun delete(item: ImagePassword)
}