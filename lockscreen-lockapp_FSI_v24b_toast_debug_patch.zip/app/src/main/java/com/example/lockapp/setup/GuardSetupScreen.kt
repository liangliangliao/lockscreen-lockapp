// BUILD TAG: LOCKAPP-FSI-FIX-CI-20250907T021838Z
package com.example.lockapp.setup
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.content.Intent
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R

import android.Manifest
import android.content.Context
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts.RequestPermission
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

@Composable
fun GuardSetupScreen(
    modifier: Modifier = Modifier,
    onAllDone: (() -> Unit)? = null
) {
    val ctx = LocalContext.current
    var notifGranted by remember { mutableStateOf(SetupChecks.hasPostNotificationsPermission(ctx)) }
    var notifEnabled by remember { mutableStateOf(SetupChecks.areNotificationsEnabled(ctx)) }
    var ignoringDoze by remember { mutableStateOf(SetupChecks.isIgnoringBatteryOptimizations(ctx)) }
    var overlayOk by remember { mutableStateOf(SetupChecks.canDrawOverlays(ctx)) }

    val reqNotifPerm = rememberLauncherForActivityResult(RequestPermission()) { granted ->
        notifGranted = granted
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && !notifGranted) {
            reqNotifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val scroll = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("锁屏守护·必备设置", style = MaterialTheme.typography.titleLarge)

        SettingRow(
            title = "通知权限（Android 13+）",
            status = if (notifGranted) "已授予" else "未授予",
            ok = notifGranted
        ) {
            if (Build.VERSION.SDK_INT >= 33) {
                reqNotifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                ctx.startActivity(SetupNavigator.notificationSettings(ctx))
            }
        }

        SettingRow(
            title = "通知开关与锁屏显示",
            status = if (notifEnabled) "已开启" else "未开启",
            ok = notifEnabled
        ) {
            ctx.startActivity(SetupNavigator.notificationSettings(ctx))
        }

        SettingRow(
            title = "忽略电池优化（防止Doze影响）",
            status = if (ignoringDoze) "已忽略" else "未忽略",
            ok = ignoringDoze
        ) {
            ctx.startActivity(SetupNavigator.requestIgnoreBatteryOptimizations(ctx))
        }

        SettingRow(
            title = "在其他应用上层显示（后台自动顶起必需）",
            status = if (overlayOk) "已允许" else "未允许",
            ok = overlayOk
        ) {
            ctx.startActivity(SetupNavigator.overlayPermission(ctx))
        }

        OutlinedButton(onClick = {
            ctx.startActivity(SetupNavigator.appDetails(ctx))
        }, modifier = Modifier.fillMaxWidth()) { Text("打开本应用信息（电池 → 不受限）") }

        Button(onClick = {
            if (Build.VERSION.SDK_INT >= 23 && SetupChecks.canDrawOverlays(ctx)) {
                com.example.lockapp.overlay.OverlayLockService.show(ctx)
            } else {
                ctx.startActivity(SetupNavigator.overlayPermission(ctx))
            }
        }, modifier = Modifier.fillMaxWidth()) {
            Text("测试 Overlay 遮罩（用于后台自动顶起）")
        }

        if (onAllDone != null) {
            Button(onClick = onAllDone, modifier = Modifier.fillMaxWidth()) {
                Text("我已完成以上设置")
            }
        }
    }
}

@Composable
private fun SettingRow(title: String, status: String, ok: Boolean, onClick: () -> Unit) {
    ElevatedCard {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(status, style = MaterialTheme.typography.bodyMedium,
                    color = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.width(12.dp))
            TextButton(onClick = onClick) { Text("去设置") }
        }
    }
}