package com.example.lockapp.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlin.random.Random

private val Context.rotationStore by preferencesDataStore("rotation")

object RotationManager {
    private val KEY_MODE = stringPreferencesKey("mode") // "seq" | "rand"
    private val KEY_INDEX = intPreferencesKey("index")

    suspend fun nextIndex(ctx: Context, size: Int, advance: Boolean): Int {
        if (size <= 0) return 0
        val prefs = ctx.rotationStore.data.first()
        val saved = prefs[KEY_INDEX] ?: 0
        val mode  = prefs[KEY_MODE] ?: "seq"
        val next  = if (advance) {
            if (mode == "rand") Random.nextInt(size) else (saved + 1) % size
        } else saved
        if (advance) ctx.rotationStore.edit { it[KEY_INDEX] = next }
        return next
    }

    suspend fun setMode(ctx: Context, mode: String) {
        ctx.rotationStore.edit { it[KEY_MODE] = if (mode == "rand") "rand" else "seq" }
    }
}