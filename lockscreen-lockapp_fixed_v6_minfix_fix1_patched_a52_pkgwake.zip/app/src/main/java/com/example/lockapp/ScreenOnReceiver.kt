package com.example.lockapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.app.KeyguardManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.util.LockCoordinator
import com.example.lockapp.util.LockVisibilityTracker
import com.example.lockapp.util.LockFsNotifier

class ScreenOnReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_SCREEN_OFF -> {
                try { com.example.lockapp.util.LockCoordinator.releaseShowOnce() } catch (_: Throwable) {}

                // 息屏：置锁 + 复位闸门
                LockCoordinator.markLocked(context)
                LockCoordinator.leaveShowing()
                LockVisibilityTracker.visible = false
                return
            }
            Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> {
                // Second-stage fallback for Samsung (One UI): wait a bit for Keyguard to be fully locked, then FSI
                run {
                    val km = context.getSystemService(KeyguardManager::class.java)
                    android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                        if (!com.example.lockapp.util.LockVisibilityTracker.visible
                            && com.example.lockapp.util.LockCoordinator.isLocked(context)
                            && (km?.isKeyguardLocked == true)
                        ) {
                            try { com.example.lockapp.util.LockCoordinator.releaseShowOnce() } catch (_: Throwable) {}
                            try { com.example.lockapp.util.LockCoordinator.leaveShowing() } catch (_: Throwable) {}
                            try { com.example.lockapp.util.LockFsNotifier.showFullScreen(context) } catch (_: Throwable) {}
                        }
                    }, 700)
                }

                
                // Ensure locked even if SCREEN_OFF missed
                com.example.lockapp.util.LockCoordinator.markLocked(context)
// 兜底：即便 OFF 漏到，也在亮屏处确保锁态为 true
                LockCoordinator.markLocked(context)

                val i = Intent(context, LockScreenActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)

                if (LockCoordinator.isLocked(context)
                    && !LockVisibilityTracker.visible
                    && LockCoordinator.requestShowOnce()
                    && LockCoordinator.tryEnterShowing()
                ) {
                    try {
                        context.startActivity(i)
                    } catch (_: Throwable) { }
                }

                // 兜底：如果未显示则用全屏通知拉起
                Handler(Looper.getMainLooper()).postDelayed({
                    if (!LockVisibilityTracker.visible && LockCoordinator.isLocked(context)) {
                        try { LockFsNotifier.showFullScreen(context) } catch (_: Throwable) { }
                    }
                }, 120)
            }
        }
    }
}
