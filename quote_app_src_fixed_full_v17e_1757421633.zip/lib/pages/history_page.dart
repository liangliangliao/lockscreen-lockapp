import 'package:flutter/material.dart';
import '../data/dao.dart';

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});
  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  final QuoteDao _dao = QuoteDao();
  final ScrollController _scroll = ScrollController();
  final TextEditingController _search = TextEditingController();
  final List<Map<String,dynamic>> _data = [];
  bool _loading = false;
  bool _hasMore = true;
  String _keyword = '';

  @override
  void initState() {
    super.initState();
    _loadMore();
    _scroll.addListener(() {
      if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 100 && !_loading && _hasMore) {
        _loadMore();
      }
    });
    _search.addListener(() {
      _keyword = _search.text;
      _data.clear();
      _hasMore = true;
      _loadMore(reset: true);
      setState((){});
    });
  }

  Future<void> _loadMore({bool reset=false}) async {
    if (_loading) return;
    _loading = true;
    final rows = await _dao.fetchPaged(offset: _data.length, limit: 100, keyword: _keyword);
    _data.addAll(rows);
    if (rows.length < 100) _hasMore = false;
    _loading = false;
    if (mounted) setState((){});
  }

  @override
  void dispose() {
    _scroll.dispose();
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('历史记录')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _search,
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: '模糊搜索内容/作者/来源'),
            ),
          ),
          Expanded(
            child: ListView.separated(
              controller: _scroll,
              itemCount: _data.length + (_hasMore ? 1 : 0),
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) {
                if (i >= _data.length) return const Padding(
                  padding: EdgeInsets.all(16),
                  child: Center(child: CircularProgressIndicator()),
                );
                final r = _data[i];
                return ListTile(
                  title: Text(r['text'] as String),
                  subtitle: Text('—— ${r['author'] ?? ''}  ${r['source'] ?? ''}'),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
