package com.example.lockapp.ui

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import com.example.lockapp.LockScreenApp
import com.example.lockapp.data.ImagePassword
import com.example.lockapp.data.ImagePasswordRepository
import com.example.lockapp.data.RotationManager
import com.example.lockapp.data.RotationMode
import com.example.lockapp.data.ActiveLockStore

@Composable
fun LiveLockScreen(
    onUnlock: () -> Unit,
    onEmergency: () -> Unit = {}
) {
    val ctx = LocalContext.current
    var entry by remember { mutableStateOf<ImagePassword?>(null) }
    var pwd by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    // 选择下一张背景 + 设置当前密码（顺序/随机）
    LaunchedEffect(Unit) {
        val db = (ctx.applicationContext as LockScreenApp).database
        val repo = ImagePasswordRepository(db.imagePasswordDao())
        val rotation = RotationManager(ctx)
        val all = withContext(Dispatchers.IO) { repo.getAllOnce() }
        if (all.isNotEmpty()) {
            val mode = rotation.rotationMode.first()
            val last = rotation.lastIndex.first()
            val next = when (mode) {
                RotationMode.SEQUENTIAL -> (last + 1).mod(all.size)
                RotationMode.SHUFFLE -> if (all.size == 1) 0 else {
                    val pool = all.indices.toMutableList()
                    if (last in pool && pool.size > 1) pool.remove(last)
                    pool.random()
                }
            }
            withContext(Dispatchers.IO) { rotation.setLastIndex(next) }
            entry = all[next]
            ActiveLockStore.set(ctx, entry!!.uri, entry!!.password)
        } else {
            entry = null
        }
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        // 简化：暂不加载真实图片，避免依赖冲突；可改为 Coil 显示 entry?.uri
        Box(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Bottom,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                OutlinedTextField(
                    value = pwd,
                    onValueChange = { pwd = it; error = null },
                    label = { Text("请输入密码") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = {
                    val expected = entry?.password ?: ActiveLockStore.getPwd(ctx)
                    if (expected != null && pwd == expected) {
                        onUnlock()
                    } else {
                        error = "密码错误"
                    }
                }) {
                    Text("解锁")
                }
                error?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }

    BackHandler(enabled = false) { /* 禁止返回键退出 */ }
}
