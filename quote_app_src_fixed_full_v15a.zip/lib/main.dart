import 'package:flutter/foundation.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'services/notification_service.dart';
import 'services/scheduler_service.dart';
import 'data/dao.dart';
import 'pages/home_page.dart';
const bool kSafeHome = bool.fromEnvironment('SAFE_HOME', defaultValue: false);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.init();
  await SchedulerService.initBackground();
  await SchedulerService.registerPeriodic();

  // Seed a default quote for testing
  await QuoteDao().seedDefaultQuote();

    // --- Startup guards ---
  FlutterError.onError = (details) {
    FlutterError.presentError(details);
    debugPrint('FlutterError: ${details.exceptionAsString()}\n${details.stack}');
  };
  PlatformDispatcher.instance.onError = (e, st) {
    debugPrint('Platform error: $e\n$st');
    return true;
  };
  bool _firstFrame = false;
  WidgetsBinding.instance.addTimingsCallback((_) { _firstFrame = true; });
  Future<void>.delayed(const Duration(seconds: 3), () { if (!_firstFrame) debugPrint('⚠️ 首帧>3s仍未绘制'); });
  ErrorWidget.builder = (e) => MaterialApp(home: Scaffold(body: Center(child: Text('渲染失败：${e.exception}'))));
  runApp(const _BootstrapShell());
  // Two-phase bootstrap to guarantee first frame
  Future.microtask(() { runApp(const MyApp()); });
// Non-blocking bootstrap to avoid blocking first frame
  Future.microtask(() async {
    try {
      // Keep heavy inits out of the critical path
      // e.g. await initDatabase(); await initNotifications(); await initWorkmanager();
    } catch (e, st) {
      // debugPrint('Bootstrap error: $e\n$st');
    }
  });
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '名人名言',
      theme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}


class _BootstrapShell extends StatelessWidget {
  const _BootstrapShell({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      ),
      debugShowCheckedModeBanner: false,
    );
  }
}

class _SafeHome extends StatelessWidget {
  const _SafeHome({super.key});
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(body: Center(child: Text('Engine OK'))),
    );
  }
}
