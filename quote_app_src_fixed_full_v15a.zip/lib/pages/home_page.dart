import 'dart:async';
import 'package:flutter/material.dart';
import '../data/dao.dart';
import '../services/scheduler_service.dart';
import 'settings_page.dart';
import 'history_page.dart';
import '../widgets/quote_card.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Map<String, dynamic>? latest;
  Timer? _refresh;

  @override
  void initState() {
    super.initState();
    _load();
    SchedulerService.start15sTicker(() => _load());
  }

  @override
  void dispose() {
    SchedulerService.stop15sTicker();
    _refresh?.cancel();
    super.dispose();
  }

  Future _load() async {
    final q = await QuoteDao().latest();
    setState(() => latest = q);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('名人名言'),
        leading: IconButton(
          icon: const Icon(Icons.history),
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HistoryPage())),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsPage())),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: latest == null
            ? const Center(child: Text('暂无数据！'))
            : QuoteCard(text: latest!['text'] as String, author: latest!['author'] as String, source: latest!['source'] as String),
      ),
    );
  }
}
