package com.example.lockapp.wake
import com.example.lockapp.util.Toaster

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.lockapp.util.DebugLog

/**
 * 闹钟兜底接收器：不依赖 ScreenOnBinder，直接发送一次 FSI 全屏通知。
 */
class FsiAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        Toaster.show5s(ctx, "兜底闹钟触发：尝试发送全屏弹窗")
        if ("com.example.lockapp.ACTION_FSI_ALARM" != intent.action) return
                .setFullScreenIntent(pi, true)
            .build()

        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(2101, n)
        DebugLog.w("FSI", "FSI sent from FsiAlarmReceiver (fallback)")
    }

    private fun ensureFsiChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(FSI_CHANNEL_ID) == null) {
                val ch = NotificationChannel(
                    FSI_CHANNEL_ID,
                    "LockApp 全屏通知（FSI）",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "用于锁屏场景的全屏弹窗测试"
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
                nm.createNotificationChannel(ch)
            }
        }
    }

    companion object {
        private const val FSI_CHANNEL_ID = "lock_guard_fsi_v2"
    }
}