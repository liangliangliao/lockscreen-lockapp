package com.example.lockapp.util
import com.example.lockapp.util.Toaster

import android.app.Notification
import android.app.PendingIntent
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/**
 * 通知工具：确保渠道 + 发送 heads-up（锁屏可见）。
 * 依赖仅保留 NotificationCompat（大多数工程已有）。发送使用框架 NotificationManager。
 */
object LockFsNotifier {
    private const val CHANNEL_ID_FG = "lock_guard_fg"
    private const val CHANNEL_NAME_FG = "LockApp 调试/前台"

    /** 确保高优先级渠道存在（Android 8.0+ 必须） */
    private fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = context.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL_ID_FG) == null) {
                val ch = NotificationChannel(
                    CHANNEL_ID_FG,
                    CHANNEL_NAME_FG,
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "用于锁屏弹窗与调试 heads-up 的高优先级渠道"
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
                nm.createNotificationChannel(ch)
            }
        }
    }

    /** 调试：快捷显示一个高优先级 heads-up 通知（锁屏也可见） */
    @JvmStatic
    fun showDebugHeadsUp(context: Context, title: String, text: String) {
        try {
            ensureChannels(context)
            Toaster.show5s(this, "正在发送全屏弹窗（FSI）[auto]")
val n = NotificationCompat.Builder(context, CHANNEL_ID_FG)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(text)
                .setPriority(if (Build.VERSION.SDK_INT < 26) NotificationCompat.PRIORITY_HIGH else 0)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setAutoCancel(true)
                .build()

            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify((System.currentTimeMillis() % 100000).toInt(), n)
        } catch (t: Throwable) {
            DebugLog.w("LockFsNotifier", "showDebugHeadsUp 失败: ${t.message}", t)
        }
    }

    /** 兜底：显示全屏通知（如果你的工程里有该方法体，可继续保留/合并） */
    @JvmStatic
    fun showFullScreen(context: Context) {
        try {
            // Ensure FSI channel
            if (Build.VERSION.SDK_INT >= 26) {
                val nm = context.getSystemService(NotificationManager::class.java)
                val chId = "lock_guard_fsi_v2"
                if (nm.getNotificationChannel(chId) == null) {
                    val ch = NotificationChannel(chId, "LockApp 全屏通知（FSI）", NotificationManager.IMPORTANCE_HIGH).apply {
                        description = "用于锁屏场景的全屏弹窗"
                        lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                    }
                    nm.createNotificationChannel(ch)
                }
            }
            // Trampoline pending intent
            val intent = Intent().apply {
                setClassName(context, "com.example.lockapp.launcher.TransparentTrampolineActivity")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                action = "com.example.lockapp.SHOW_LOCK_FROM_FSI"
                putExtra("from_fsi", true)
            }
            val pi = PendingIntent.getActivity(context, 2102, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            // Toast (5s)
            Toaster.show5s(context, "正在发送全屏弹窗（FSI）[LockFsNotifier]")
            val n = NotificationCompat.Builder(context, "lock_guard_fsi_v2")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("锁屏唤起")
                .setContentText("触发全屏通知兜底")
                .setCategory(Notification.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setFullScreenIntent(pi, true)
                .build()
            NotificationManagerCompat.from(context).notify(2102, n)
        } catch (t: Throwable) {
            DebugLog.w("LockFsNotifier", "showFullScreen 失败: ${t.message}", t)
        }
        }
    }
