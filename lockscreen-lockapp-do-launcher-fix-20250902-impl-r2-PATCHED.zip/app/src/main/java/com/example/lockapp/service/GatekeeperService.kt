package com.example.lockapp.service

import android.app.*
import android.content.*
import android.os.Build
import android.os.IBinder
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import com.example.lockapp.ui.LockActivity
import com.example.lockapp.AppVisibilityTracker
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.data.LockConfigStore

class GatekeeperService : Service() {

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    if (LockConfigStore.isArmed(context)) {
                        LockStateStore.setRequireUnlock(context, true)
                        cancelHeadsUp()
                    }
                }
                Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> {
                    maybePrompt()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundWithNotification()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        registerReceiver(screenReceiver, filter)
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(screenReceiver) } catch (_: Throwable) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun maybePrompt() {
        if (!LockConfigStore.isArmed(this) || !LockStateStore.isRequireUnlock(this)) return

        if (AppVisibilityTracker.isInForeground()) {
            // App在前台：直接拉起锁屏Activity
            val i = Intent(this, LockActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(i)
        } else {
            // App在后台/或刚被唤醒：用全屏通知合法拉起界面
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channelId = ensureChannel(this, nm)
            val pi = PendingIntent.getActivity(
                this, 1001,
                Intent(this, LockActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                (PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0))
            )
            val nb = NotificationCompat.Builder(this, channelId)
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentTitle("解锁")
                .setContentText("点击以输入密码")
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setFullScreenIntent(pi, true)
                .build()
            nm.notify(1002, nb)
        }
    }
