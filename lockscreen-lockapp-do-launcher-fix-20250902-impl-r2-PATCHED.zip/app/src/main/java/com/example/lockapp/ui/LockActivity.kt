package com.example.lockapp.ui

import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.example.lockapp.data.LockStateStore

class LockActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true); setTurnScreenOn(true)
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        enterImmersive()
        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { /* blocked */ }
        })

        setContent {
            MaterialTheme {
                LockScreen(
                    onUnlock = {
                        LockStateStore.setRequireUnlock(this@LockActivity, false)
                        try { stopLockTask() } catch (_: Throwable) {}
                        finish()
                    },
                    showEmergencyOnly = true,
                    plainText = true
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        enterImmersive()
        startLockTaskIfPossible()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersive()
    }

    private fun startLockTaskIfPossible() {
        try { startLockTask() } catch (_: Throwable) {}
    }

    
}