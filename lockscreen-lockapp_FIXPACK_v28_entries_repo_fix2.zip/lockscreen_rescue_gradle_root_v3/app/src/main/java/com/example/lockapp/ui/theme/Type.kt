package com.example.lockapp.ui.theme
import androidx.compose.material3.Typography

val Typography3 = Typography()
