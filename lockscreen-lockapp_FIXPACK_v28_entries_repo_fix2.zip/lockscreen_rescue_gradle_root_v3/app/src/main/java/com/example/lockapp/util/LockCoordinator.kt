package com.example.lockapp.util

import android.content.Context
import android.os.SystemClock
import com.example.lockapp.data.LockStateStore

object LockCoordinator {
    @Volatile private var lastShownAt: Long = 0L
    @Volatile private var isShowing: Boolean = false
    private const val DEBOUNCE_MS = 2000L

    fun isLocked(context: Context): Boolean = LockStateStore(context).isLocked()

    fun setLocked(context: Context, v: Boolean) = LockStateStore(context).setLocked(v)

    @Synchronized
    fun canShowNow(): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (isShowing) return false
        if (now - lastShownAt < DEBOUNCE_MS) return false
        isShowing = true
        lastShownAt = now
        return true
    }

    fun leaveShowing() { isShowing = false }

    @Synchronized
    fun releaseShowOnce() {
        // Reset internal debounce state to allow another show
        isShowing = false
        lastShownAt = 0L
    }
}
