Drop-in AndroidX Fix Patch
==========================

What this is
------------
This patch enables AndroidX + Jetifier at the *project root* so your app
can resolve dependencies like `androidx.core:core-ktx`, `appcompat` and `material`.

Files in this patch
-------------------
- gradle.properties   (put this in your REPO ROOT, next to settings.gradle(.kts))

How to apply
------------
1) Extract this zip to your repository *root* (same folder that contains settings.gradle(.kts)).
   Allow overwrite if a gradle.properties already exists.
2) Ensure your CI workflow does NOT delete gradle.properties.
3) Build again:
   ./gradlew clean assembleDebug   (or 'gradle clean assembleDebug')

If you still see errors
-----------------------
- Make sure no workflow step runs 'rm -rf gradle.properties' or removes build files.
- Run 'grep -R "android.support." -n app/' to check for legacy imports.
- Run './gradlew :app:dependencies --configuration debugRuntimeClasspath' to list deps.

