# CI Autoroot Pack v2

Fixes GitHub Actions error:
  Directory '.../lockscreen-lockapp/lockscreen-lockapp' does not contain a Gradle build.

What it does:
- Searches your repo for the directory that contains `settings.gradle` or `settings.gradle.kts`.
- Runs `./gradlew assembleDebug` from that directory.
- Uploads all debug APKs found under that directory.

How to use:
1) Add `.github/workflows/android-autoroot.yml` to your repository and commit.
2) Ensure Gradle Wrapper files exist alongside your `settings.gradle(.kts)`:
   - gradlew
   - gradlew.bat
   - gradle/wrapper/gradle-wrapper.properties
   If missing, generate locally and commit:
       gradle wrapper --gradle-version 8.4
3) Push and let CI run again.
