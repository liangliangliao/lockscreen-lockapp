
package com.example.lockapp

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.service.GatekeeperService

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Start the gatekeeper foreground service to monitor screen on/off
        startForegroundService(Intent(this, GatekeeperService::class.java))

        // If locked, immediately show lock UI; else show main UI
        if (LockStateStore.isLocked(this)) {
            startActivity(Intent(this, com.example.lockapp.ui.LockActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            // Keep this activity alive underneath to be resumed after unlock
        }

        setContent {
            MaterialTheme {
                // Placeholder content; your existing MainScreen can be wired here.
            }
        }
    }
}
