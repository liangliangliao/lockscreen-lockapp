
package com.example.lockapp.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.lockapp.service.GatekeeperService
import com.example.lockapp.data.LockStateStore

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // After boot, mark locked and start service
        LockStateStore.setLocked(context, true)
        context.startForegroundService(Intent(context, GatekeeperService::class.java))
    }
}
