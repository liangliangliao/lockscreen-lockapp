package com.example.lockapp.refresh

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/** 接收内部 APP_REFRESH 广播；相当于点击图标 bring-to-front */
class AppRefreshReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (ACTION_APP_REFRESH == intent.action) {
            try {
                val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    context.startActivity(launch)
                }
            } catch (e: Throwable) {
                Log.e("AppRefreshReceiver", "start launch activity failed: ${e.message}")
            }
        }
    }
    companion object { const val ACTION_APP_REFRESH = "com.example.lockapp.APP_REFRESH" }
}