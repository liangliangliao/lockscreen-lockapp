
package com.example.lockapp.ui

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

import androidx.activity.OnBackPressedCallback
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.lockapp.data.ActiveLockStore
import com.example.lockapp.data.LockStateStore

class LockActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Fullscreen immersive
        
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        // Show over keyguard & turn screen on (runtime flags)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }

        // Disable back
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { /* no-op */ }
        })

        setContent {
            MaterialTheme {
                LockScreenContent(
                    onUnlock = {
                        // Mark unlocked until next screen off
                        LockStateStore.setLocked(this@LockActivity, false)
                        try { stopLockTaskIfPinned() } catch (_: Exception) {}
                        finish()
                    },
                    onEmergency = { openEmergencyDialer() }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Start LockTask (screen pinning) to block Home/Recents where possible
        startLockTaskIfPossible()
    }

    private fun startLockTaskIfPossible() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (am.lockTaskModeState == ActivityManager.LOCK_TASK_MODE_NONE) {
                try { startLockTask() } catch (_: Exception) {}
            }
        } else {
            try { startLockTask() } catch (_: Exception) {}
        }
    }

    private fun stopLockTaskIfPinned() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (am.lockTaskModeState != ActivityManager.LOCK_TASK_MODE_NONE) {
                stopLockTask()
            }
        } else {
            stopLockTask()
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        // Swallow BACK and APP_SWITCH; HOME isn't delivered to apps, but LockTask will block it.
        if (event.keyCode == KeyEvent.KEYCODE_BACK || event.keyCode == KeyEvent.KEYCODE_APP_SWITCH) {
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun openEmergencyDialer() {
        // Use ACTION_DIAL to avoid CALL permission; user can dial emergency.
        val i = Intent(Intent.ACTION_DIAL).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
        startActivity(i)
    }
}

@Composable
private fun LockScreenContent(onUnlock: () -> Unit, onEmergency: () -> Unit) {
    val ctx = LocalContext.current
    var input by remember { mutableStateOf("") }
    val saved = ActiveLockStore.getPwd(ctx) ?: ""

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("请输入密码解锁", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            Button(
                enabled = input.isNotEmpty() && input == saved,
                onClick = onUnlock,
                modifier = Modifier.fillMaxWidth()
            ) { Text("解锁") }

            if (input.isNotEmpty() && input != saved) {
                Spacer(Modifier.height(8.dp))
                Text("密码不正确", color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(24.dp))
            TextButton(onClick = onEmergency) { Text("紧急呼救") }
        }
    }
}
