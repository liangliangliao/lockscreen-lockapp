
plugins {
    id("com.android.application") version "7.0.4" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}

repositories {
    google()
    mavenCentral()
}

dependencies {
    // Define project dependencies here
}
