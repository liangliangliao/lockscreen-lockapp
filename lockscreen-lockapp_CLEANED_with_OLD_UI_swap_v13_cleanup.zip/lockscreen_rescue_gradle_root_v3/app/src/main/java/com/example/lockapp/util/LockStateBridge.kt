package com.example.lockapp.util
import com.example.lockapp.data.LockStateStore

fun setLocked(v: Boolean) = LockStateStore.setLocked(v)
fun isLocked(): Boolean = LockStateStore.isLocked()
