
这是一个“sources only”补丁包：把 zip 解压后，直接覆盖到你的仓库根目录。
仅包含修复编译错误的 Kotlin 源码（不会修改你的 Gradle/资源/Manifest 逻辑）。
已修复：
- setFullScreenIntent 必须在 NotificationCompat.Builder 链上调用；
- notify(id, builder.build())；
- 统一图标资源引用为 mipmap/ic_launcher（若不存在则退回系统图标）；
- 补齐 O+ 通知渠道；
- 提供 com.example.app.patchlock.* 所需的占位类，避免未解析引用；
- 保证业务不变，只解决语法/调用层面的报错。
覆盖后执行：gradle clean assembleDebug
