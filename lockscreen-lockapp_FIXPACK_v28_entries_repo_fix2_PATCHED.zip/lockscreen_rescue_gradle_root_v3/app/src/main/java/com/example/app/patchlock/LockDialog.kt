package com.example.app.patchlock

import android.app.Activity
import android.app.Dialog
import android.os.Bundle
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import androidx.appcompat.app.AlertDialog

/**
 * Minimal lock dialog used by the app. It exposes a very small API surface so that
 * the rest of the codebase can remain decoupled from the actual dialog implementation.
 */
object LockDialog {

    private const val TAG = "LockDialog"
    private var onResult: ((ok: Boolean) -> Unit)? = null

    fun setResultListener(listener: (ok: Boolean) -> Unit) {
        onResult = listener
    }

    private fun notifyResult(ok: Boolean) {
        val cb = onResult
        onResult = null
        cb?.invoke(ok)
    }

    fun show(activity: Activity) {
        val fa = activity as? FragmentActivity ?: return
        val fm: FragmentManager = fa.supportFragmentManager
        val existing = fm.findFragmentByTag(TAG)
        if (existing == null) {
            LockDialogFragment().show(fm, TAG)
        }
    }

    class LockDialogFragment : DialogFragment() {
        override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
            val ctx = requireContext()
            return AlertDialog.Builder(ctx)
                .setTitle("Unlock")
                .setMessage("Enter to unlock?")
                .setPositiveButton(android.R.string.ok) { _, _ -> notifyResult(true) }
                .setNegativeButton(android.R.string.cancel) { _, _ -> notifyResult(false) }
                .create()
        }
    }
}

/**
 * Helper functions that integrate the dialog with the surrounding coordination code.
 */
object LockDialogHelpers {

    fun show(activity: Activity) {
        LockDialog.show(activity)
    }

    fun setOnLockDialogResult(
        activity: Activity,
        ok: () -> Unit,
        cancel: () -> Unit
    ) {
        // Bridge the single boolean result into two callbacks.
        LockDialog.setResultListener { accepted ->
            if (accepted) ok() else cancel()
        }
    }
}
