package com.example.lockapp.data
import android.content.Context

fun database(context: Context): AppDatabase = AppDatabase.get(context)
