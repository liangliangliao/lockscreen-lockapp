
package com.example.lockapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.lockapp.data.LockStateStore

class ScreenOnReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (LockStateStore.isLocked(context)) {
            val i = Intent(context, ui.LockActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            context.startActivity(i)
        }
    }
}
