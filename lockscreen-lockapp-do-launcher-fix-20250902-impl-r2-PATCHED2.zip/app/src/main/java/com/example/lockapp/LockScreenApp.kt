package com.example.lockapp

import android.app.Application
import androidx.room.Room
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ProcessLifecycleOwner
import com.example.lockapp.data.AppDatabase

/**
 * Custom [Application] that holds a reference to the Room database. This allows the database
 * to be accessed throughout the app without repeatedly creating new instances.
 */
class LockScreenApp : Application() {
    // Singleton instance of the Room database.
    lateinit var database: AppDatabase
        private set

    override fun onCreate() {
        super.onCreate()
        // Build the database once when the application is created.
        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "image_password.db"
        ).build()
        // observe app foreground/background
        val lifecycle = ProcessLifecycleOwner.get().lifecycle
        lifecycle.addObserver(LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> AppVisibilityTracker.setForeground(true)
                Lifecycle.Event.ON_STOP -> AppVisibilityTracker.setForeground(false)
                else -> {}
            }
        })
    }
}