package com.example.lockapp.ui

import android.net.Uri
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.lockapp.data.ImagePassword
import com.example.lockapp.data.ImagePasswordDao
import com.example.lockapp.data.AppDatabase
import kotlinx.coroutines.runBlocking
import androidx.room.Room

@Composable
fun LockScreen(
    onUnlock: () -> Unit = {}
) {
    val context = LocalContext.current
    val dao = remember { Room.databaseBuilder(context, AppDatabase::class.java, "lockapp.db").allowMainThreadQueries().build().imagePasswordDao() }
    val current: ImagePassword? = remember {
        runBlocking {
            try {
                produceState<com.example.lockapp.data.ImagePassword?>(initialValue = null) {
        value = dao.getAllOnce().firstOrNull()
    }.value
            } catch (_: Throwable) {
                null
            }
        }
    }

    var input by remember { mutableStateOf("") }
    val match = current?.password == input

    Box(modifier = Modifier.fillMaxSize()) {
        if (current != null) {
            AsyncImage(
                model = ImageRequest.Builder(context)
                    .data(Uri.parse(current.uri))
                    .crossfade(true)
                    .build(),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }

        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Bottom,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { if (it.length <= 100) input = it },
                label = { Text("输入该图片的密码") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { if (match) onUnlock() },
                enabled = input.isNotEmpty(),
                modifier = Modifier.fillMaxWidth()
            ) { Text("解锁") }
            if (!match && input.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text("密码不正确", color = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}