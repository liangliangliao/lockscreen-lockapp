package com.example.lockapp.util
import android.content.Context
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.core.app.NotificationManagerCompat

object NotifyUtils {
    const val MAIN_CHANNEL_ID = "lockapp_main"
    fun ensureMainChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val mgr = context.getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(MAIN_CHANNEL_ID, "LockApp", NotificationManager.IMPORTANCE_DEFAULT)
            mgr.createNotificationChannel(ch)
        }
    }
}



fun areNotificationsEnabled(ctx: android.content.Context): Boolean {
    return NotificationManagerCompat.from(ctx).areNotificationsEnabled()
}
