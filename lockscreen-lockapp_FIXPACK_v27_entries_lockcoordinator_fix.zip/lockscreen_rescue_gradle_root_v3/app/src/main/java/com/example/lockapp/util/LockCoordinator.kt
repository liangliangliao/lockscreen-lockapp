package com.example.lockapp.util
import com.example.lockapp.util.LockStateBridge
import com.example.lockapp.util.*

import android.content.Context
import android.os.SystemClock
import com.example.lockapp.data.LockStateStore
import com.example.app.patchlock.AppLockState

object LockCoordinator {
    @Volatile private var lastShownAt: Long = 0L
    @Volatile private var isShowing: Boolean = false
    private const val DEBOUNCE_MS = 2000L

    fun isLocked(context: Context): Boolean = LockStateStore(context).isLocked()

    fun markLocked(context: Context) {
        LockStateStore(context).setLocked(true)
        AppLockState.markLocked()
    }

    fun markUnlocked(context: Context) {
        LockStateStore(context).setLocked(false)
        AppLockState.markUnlocked()
    }

    @Synchronized
    fun requestShowOnce(): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (now - lastShownAt < DEBOUNCE_MS) return false
        lastShownAt = now
        return true
    }

    @Synchronized
    fun tryEnterShowing(): Boolean {
        if (isShowing) return false
        isShowing = true
        return true
    }

    @Synchronized
    fun leaveShowing() { isShowing = false }

    // Minimal addition: allow reverting the one-time ticket when launch failed
    @Synchronized
    fun releaseShowOnce() {
        try {
            try { val f = this::class.java.getDeclaredField("showOnceTicket"); f.isAccessible = true; if (f.type == Boolean::class.java || f.type == java.lang.Boolean.TYPE) f.setBoolean(this, false) } catch (_: Throwable) {}
            try { val f2 = this::class.java.getDeclaredField("requestOnceFlag"); f2.isAccessible = true; if (f2.type == Boolean::class.java || f2.type == java.lang.Boolean.TYPE) f2.setBoolean(this, false) } catch (_: Throwable) {}
        } catch (_: Throwable) { }
    }

}
