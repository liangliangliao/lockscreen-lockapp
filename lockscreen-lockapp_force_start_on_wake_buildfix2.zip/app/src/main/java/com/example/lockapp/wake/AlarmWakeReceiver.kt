package com.example.lockapp.wake

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import com.example.lockapp.service.GatekeeperService

class AlarmWakeReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_LOCK_WAKE = "com.example.lockapp.ACTION_LOCK_WAKE"

        fun scheduleExact(context: Context, triggerAtMillis: Long) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val flags = if (Build.VERSION.SDK_INT >= 23)
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT else 0
            val pi = PendingIntent.getBroadcast(
                context, 3101,
                Intent(context, AlarmWakeReceiver::class.java).setAction(ACTION_LOCK_WAKE),
                flags
            )
            if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_LOCK_WAKE) {
            try {
                ContextCompat.startForegroundService(
                    context,
                    Intent(context, GatekeeperService::class.java)
                )
            } catch (_: Throwable) {}
        }
    }
}