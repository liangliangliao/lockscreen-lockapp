package com.example.lockapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.lockapp.service.GatekeeperService

class ScreenOnReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Intent.ACTION_SCREEN_ON == intent.action) {
            try {
                ContextCompat.startForegroundService(
                    context,
                    Intent(context, GatekeeperService::class.java)
                )
            } catch (_: Throwable) {}
        }
    }
}