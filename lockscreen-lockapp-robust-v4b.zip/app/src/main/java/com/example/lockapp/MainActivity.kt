package com.example.lockapp


import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.core.content.ContextCompat
import com.example.lockapp.setup.SetupActivity
import com.example.lockapp.ui.MainScreen
import com.example.lockapp.ui.MainViewModel
import com.example.lockapp.ui.MainViewModelFactory
import com.example.lockapp.ui.theme.LockScreenAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val prefs = getSharedPreferences("onboarding", MODE_PRIVATE)
        if (!prefs.getBoolean("done", false)) {
            startActivity(android.content.Intent(this, SetupActivity::class.java))
        }
        super.onCreate(savedInstanceState)
        // 动态注册屏幕点亮监听（演示用途）
        val screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (Intent.ACTION_SCREEN_ON == intent.action) {
                    val i = Intent(this@MainActivity, LockScreenActivity::class.java)
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or
                               Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS or
                               Intent.FLAG_ACTIVITY_NO_ANIMATION)
                    startActivity(i)
                }
            }
        }
        val filter = IntentFilter(Intent.ACTION_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(screenReceiver, filter)
        }
        
        // Acquire ViewModel through a factory referencing the custom Application class.
        val viewModel: MainViewModel by viewModels {
            MainViewModelFactory(application as LockScreenApp)
        }
        setContent {
            LockScreenAppTheme {
                MainScreen(viewModel = viewModel)
            }
        }
    }
}