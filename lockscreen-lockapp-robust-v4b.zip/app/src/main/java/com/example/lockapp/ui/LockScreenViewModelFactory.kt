package com.example.lockapp.ui


import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.lockapp.LockScreenApp
import com.example.lockapp.data.ImagePasswordRepository
import com.example.lockapp.data.RotationManager

/**
 * Factory for creating [LockScreenViewModel] instances. Pulls required dependencies
 * (repository and rotation manager) from the [LockScreenApp] context.
 */
class LockScreenViewModelFactory(private val app: LockScreenApp) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        val dao = app.database.imagePasswordDao()
        val repo = ImagePasswordRepository(dao)
        val rotationManager = RotationManager(app)
        return LockScreenViewModel(repo, rotationManager) as T
    }
}