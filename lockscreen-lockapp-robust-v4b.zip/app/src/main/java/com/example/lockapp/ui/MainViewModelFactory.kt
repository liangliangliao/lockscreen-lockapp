package com.example.lockapp.ui


import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.lockapp.LockScreenApp
import com.example.lockapp.data.ImagePasswordRepository
import com.example.lockapp.data.RotationManager

/**
 * Factory for creating [MainViewModel] instances with the dependencies provided by the
 * [LockScreenApp] context (database and DataStore).
 */
class MainViewModelFactory(private val app: LockScreenApp) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        val dao = app.database.imagePasswordDao()
        val repo = ImagePasswordRepository(dao)
        val rotationManager = RotationManager(app)
        return MainViewModel(repo, rotationManager) as T
    }
}