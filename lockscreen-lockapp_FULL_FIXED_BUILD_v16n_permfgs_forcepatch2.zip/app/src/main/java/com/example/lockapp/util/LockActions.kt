package com.example.lockapp.util
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R
import android.content.Context
import android.content.Intent
import com.example.lockapp.data.ActiveLockStore
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.service.GatekeeperService

object LockActions {
    fun afterSetLock(context: Context, imageUri: String?, password: String?) {
        ActiveLockStore.set(context, imageUri, password)
        LockStateStore.setLocked(context, true)
        try { context.startForegroundService(Intent(context, GatekeeperService::class.java)) } catch (_: Throwable) {}
    }
}