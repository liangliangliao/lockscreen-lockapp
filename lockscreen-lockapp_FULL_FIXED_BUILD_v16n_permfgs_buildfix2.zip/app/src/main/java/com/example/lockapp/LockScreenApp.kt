package com.example.lockapp
import com.example.app.patchlock.AppLifecycleHook

import android.app.Application
import androidx.room.Room
import com.example.lockapp.util.DebugTracer
import com.example.lockapp.data.AppDatabase

/**
 * Custom [Application] that holds a reference to the Room database. This allows the database
 * to be accessed throughout the app without repeatedly creating new instances.
 */
class LockScreenApp : Application() {
    // Singleton instance of the Room database.
    lateinit var database: AppDatabase
        private set

    override fun onCreate() {
        DebugTracer.w("App", "App started (Application.onCreate)")
        try { DebugTracer.notify(this, "Trace", "App.onCreate()") } catch (t: Throwable) { }

        super.onCreate()
        
        AppLifecycleHook.install(this)
// Build the database once when the application is created.
        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "image_password.db"
        ).build()
    }
}