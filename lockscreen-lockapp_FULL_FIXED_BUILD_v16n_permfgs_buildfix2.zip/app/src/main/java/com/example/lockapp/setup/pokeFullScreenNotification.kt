package com.example.lockapp.setup
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.util.Toaster

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.lockapp.LockScreenActivity

fun pokeFullScreenNotification(ctx: Context) {
    val chId = "lock_fullscreen_v2"
    val nm = ctx.getSystemService(NotificationManager::class.java)
    if (Build.VERSION.SDK_INT >= 26) {
        if (nm.getNotificationChannel(chId) == null) {
            nm.createNotificationChannel(
                NotificationChannel(
                    chId, "Lock Fullscreen",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Wake lock UI"
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                    setBypassDnd(true)
                }
            )
        }
    }

    val pi = PendingIntent.getActivity(
        ctx, 0,
        Intent().apply { setClassName(ctx, "com.example.lockapp.launcher.TransparentTrampolineActivity"); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP); action = "com.example.lockapp.SHOW_LOCK_FROM_FSI"; putExtra("from_fsi", true) }
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    val n = NotificationCompat.Builder(ctx, chId)
        .setSmallIcon(android.R.mipmap.ic_launcher_lock)
        .setContentTitle("测试全屏唤醒")
        .setContentText("点击或自动弹出解锁界面")
        .setCategory(Notification.CATEGORY_CALL)
        .setPriority(NotificationCompat.PRIORITY_MAX)
        .setDefaults(Notification.DEFAULT_ALL)
        
Toaster.show5s(ctx, "正在发送全屏弹窗（FSI）")
.setFullScreenIntent(pi, true)
        .setOngoing(false)
        .build()

    (run { val __ctx = ctx; val __nm = __ctx.getSystemService(android.content.Context.NOTIFICATION_SERVICE) as android.app.NotificationManager; __nm.notify(10086, n) })
}
