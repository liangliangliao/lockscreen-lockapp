// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    id("org.jetbrains.kotlin.android")
    // No top-level plugins needed here
}

tasks.register<Delete>("clean") {
    delete(rootProject.buildDir)
}
dependencies {
    implementation("androidx.fragment:fragment-ktx:1.8.3")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-process:2.7.0")
}
