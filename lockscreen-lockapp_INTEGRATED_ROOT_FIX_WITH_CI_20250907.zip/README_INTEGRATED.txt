Integrated Gradle Root + AndroidX + CI Workflow Patch
====================================================

What this contains
------------------
- settings.gradle.kts            -> declares root project and includes ':app'
- build.gradle.kts (root)        -> declares plugin versions; clean task
- gradle.properties              -> **android.useAndroidX=true / android.enableJetifier=true**
- .github/workflows/android.yml  -> safe workflow (won't delete your root files)

How to use
----------
1) Extract this zip to your REPO ROOT (same folder as .github/).
2) Commit & push.
3) Run the GitHub Action: "Build Android APK".

Notes
-----
- If your app module is NOT named 'app', edit settings.gradle.kts include(":yourModuleName").
- Make sure your sources live under the ':app' module (or update include accordingly).
