package com.example.lockapp.util

import android.content.Context
import android.widget.Toast

object DebugToasts {
    fun show(context: Context, msg: String) {
        Toast.makeText(context.applicationContext, msg, Toast.LENGTH_SHORT).show()
    }
}