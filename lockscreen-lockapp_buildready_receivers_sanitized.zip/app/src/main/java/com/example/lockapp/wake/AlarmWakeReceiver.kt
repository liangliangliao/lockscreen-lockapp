package com.example.lockapp.wake

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/** 闹钟触发唤醒：仅确保服务在位 */
class AlarmWakeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            ContextCompat.startForegroundService(
                context,
                Intent(context, com.example.lockapp.service.GatekeeperService::class.java)
            )
        } catch (_: Throwable) { /* ignore */ }
    }
}
