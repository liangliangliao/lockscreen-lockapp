package com.example.lockapp.util

import android.content.Context
import android.os.SystemClock
import com.example.lockapp.data.LockStateStore
import com.example.app.patchlock.AppLockState

/**
 * Single coordination point for lock state + debouncing across all entry points.
 * Ensures that lock UI is shown only once at a time and that state is unified
 * between LockStateStore (activity path) and AppLockState (dialog path).
 */
object LockCoordinator {
    @Volatile private var lastShownAt: Long = 0L
    @Volatile private var isShowing: Boolean = false
    private const val DEBOUNCE_MS = 2000L

    fun isLocked(context: Context): Boolean = LockStateStore.isLocked(context)

    fun markLocked(context: Context) {
        LockStateStore.setLocked(context, true)
        AppLockState.markLocked()
    }

    fun markUnlocked(context: Context) {
        LockStateStore.setLocked(context, false)
        AppLockState.markUnlocked()
    }

    /** time-based debounce: allow only the first trigger within a window */
    @Synchronized
    fun requestShowOnce(): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (now - lastShownAt < DEBOUNCE_MS) return false
        lastShownAt = now
        return true
    }

    /** state-based gate: only one lock UI may be showing at a time */
    @Synchronized
    fun tryEnterShowing(): Boolean {
        if (isShowing) return false
        isShowing = true
        return true
    }

    /** call when lock UI is dismissed */
    @Synchronized
    fun leaveShowing() {
        isShowing = false
    }
}
