package com.example.lockapp

import android.app.KeyguardManager
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.lockapp.ui.LiveLockScreen
import com.example.lockapp.util.LockVisibilityTracker

class LockScreenActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Ensure we can appear above the keyguard and wake the screen
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        // Ask system to dismiss keyguard when possible
        getSystemService(KeyguardManager::class.java)
            ?.requestDismissKeyguard(this, null)

        setContent {
            LiveLockScreen(
                onEmergency = { /* no-op or start emergency activity if you have one */ },
                onUnlock = {
                    com.example.lockapp.util.LockCoordinator.markUnlocked(this)
                    com.example.lockapp.util.LockCoordinator.leaveShowing()
                    finish()
                }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        LockVisibilityTracker.visible = true
    }

    override fun onDestroy() { super.onDestroy(); com.example.lockapp.util.LockVisibilityTracker.visible = false }

    override fun onPause() {
        super.onPause()
        LockVisibilityTracker.visible = false
    }
}
