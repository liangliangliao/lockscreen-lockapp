
package com.example.lockapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.lockapp.util.LockCoordinator
import com.example.lockapp.util.LockVisibilityTracker

class ScreenOnReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Intent.ACTION_SCREEN_ON == intent.action || Intent.ACTION_USER_PRESENT == intent.action) {
            val i = Intent(context, LockScreenActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            if (LockCoordinator.isLocked(context) && !LockVisibilityTracker.visible && LockCoordinator.requestShowOnce() && LockCoordinator.tryEnterShowing()) { context.startActivity(i) }
        }
    }
}
