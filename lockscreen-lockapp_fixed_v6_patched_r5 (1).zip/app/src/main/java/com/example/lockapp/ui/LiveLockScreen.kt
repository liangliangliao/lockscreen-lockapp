package com.example.lockapp.ui

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.border
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Spacer
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.room.Room
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.lockapp.data.ActiveLockStore
import com.example.lockapp.data.AppDatabase
import com.example.lockapp.data.ImagePassword
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.example.lockapp.data.RotationManager
import com.example.lockapp.data.RotationMode
import com.example.lockapp.data.ImagePasswordRepository

@Composable
fun LiveLockScreen(
    onEmergency: () -> Unit = {},onUnlock: () -> Unit = {}) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val dao = remember { (ctx.applicationContext as com.example.lockapp.LockScreenApp).database.imagePasswordDao() }
    var entry by remember { mutableStateOf<ImagePassword?>(null) }
    var showInput by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var isBgLight by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val repo = ImagePasswordRepository(dao)
        val rotation = RotationManager(ctx)
        val all = withContext(Dispatchers.IO) { repo.getAllOnce() }
        if (all.isNotEmpty()) {
            val mode = rotation.rotationMode.first()
            val last = rotation.lastIndex.first()
            val next = when (mode) {
                RotationMode.SEQUENTIAL -> (last + 1).mod(all.size)
                RotationMode.SHUFFLE -> if (all.size == 1) 0 else {
                    val pool = all.indices.toMutableList()
                    if (last in pool && pool.size > 1) pool.remove(last)
                    pool.random()
                }
            }
            withContext(Dispatchers.IO) { rotation.setLastIndex(next) }
            entry = all[next]
            com.example.lockapp.data.ActiveLockStore.set(ctx, entry!!.uri, entry!!.password)
        } else {
            entry = null
        }
    }
        entry = all.firstOrNull { it.uri == active } ?: all.firstOrNull()
        if (entry != null && active == null) {
            com.example.lockapp.data.ActiveLockStore.setActive(ctx, entry!!.id, entry!!.uri)
        }
        entry?.let { e ->
            withContext(Dispatchers.IO) {
                ctx.contentResolver.openInputStream(Uri.parse(e.uri))?.use { input ->
                    val bmp = BitmapFactory.decodeStream(input)
                    if (bmp != null) {
                        var sum = 0L; var cnt = 0
                        val sx = (bmp.width / 8).coerceAtLeast(1)
                        val sy = (bmp.height / 8).coerceAtLeast(1)
                        var y=0
                        while (y < bmp.height) {
                            var x=0
                            while (x < bmp.width) {
                                val c = bmp.getPixel(x, y)
                                val r = (c shr 16) and 0xFF
                                val g = (c shr 8) and 0xFF
                                val b = c and 0xFF
                                val lum = (0.299*r + 0.587*g + 0.114*b).toInt()
                                sum += lum; cnt += 1
                                x += sx
                            }
                            y += sy
                        }
                        isBgLight = (sum.toFloat() / cnt) > 140f
                        bmp.recycle()
                    }
                }
            }
        }
    }

    val infinite = rememberInfiniteTransition(label = "bounce")
    val scale by infinite.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scaleAnim"
    )

    val borderColors = listOf(Color.Magenta, Color.Cyan, Color.Yellow, Color.Magenta)
    val textColor = if (isBgLight) Color.Black else Color.White
    val fieldColors = TextFieldDefaults.colors(
        focusedIndicatorColor = Color.Transparent,
        unfocusedIndicatorColor = Color.Transparent,
        focusedContainerColor = if (isBgLight) Color(0xCCFFFFFF) else Color(0x55000000),
        unfocusedContainerColor = if (isBgLight) Color(0xB3FFFFFF) else Color(0x44000000),
        focusedTextColor = textColor,
        unfocusedTextColor = textColor,
        cursorColor = textColor
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectVerticalDragGestures { _, drag -> if (drag < -20f) showInput = true }
            }
            .border(BorderStroke(6.dp, Brush.linearGradient(borderColors)))
    ) {
        // full-screen wallpaper background
        entry?.let { e ->
            AsyncImage(
                model = ImageRequest.Builder(ctx).data(Uri.parse(e.uri)).crossfade(true).build(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .scale(scale)
            )
        }

        if (showInput) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it.take(100); error = null },
                    label = { Text("Password", color = textColor) },
                    placeholder = { Text("Enter password", color = textColor.copy(alpha = 0.7f)) },
                    singleLine = true,
                    visualTransformation = VisualTransformation.None,
                    colors = fieldColors
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = {
                    val ok = input.trim() == (entry?.password?.trim() ?: "")
                    if (ok) onUnlock() else error = "密码错误！"
                }) { Text("解锁", color = Color.White) }
                error?.let { msg ->
                    Spacer(Modifier.height(8.dp))
                    Text(msg, color = Color.Red)
                }
            }
        }

        BackHandler(enabled = showInput) { showInput = false }
    }
}
