package com.example.lockapp

import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.service.GatekeeperService
import com.example.lockapp.util.LockCoordinator
import com.example.lockapp.ui.LiveLockScreen

class LauncherActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            WindowCompat.setDecorFitsSystemWindows(window, false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } catch (_: Throwable) {}

        try { startForegroundService(Intent(this, GatekeeperService::class.java)) } catch (_: Throwable) {}
        tryRequestIgnoreBattery()
        hardenIfDeviceOwner()

        val force = intent.getBooleanExtra("forceLock", false)
        val locked = LockStateStore.isLocked(this)
        if (!force && !locked) {
            startActivity(Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            finish(); return
        }

        setContent {
            LiveLockScreen(onUnlock = {
                    try { getSystemService(android.app.KeyguardManager::class.java)?.requestDismissKeyguard(this, null) } catch (_: Throwable) {}
                    LockCoordinator.markUnlocked(this)
                    LockCoordinator.leaveShowing()
                    finish()
                },
                onEmergency = { startEmergencyDialer() }
            )
        }
    }

    private fun tryRequestIgnoreBattery() {
        try {
            val pm = getSystemService(android.os.PowerManager::class.java)
            if (pm != null && !pm.isIgnoringBatteryOptimizations(packageName)) {
                val it = Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                it.data = Uri.parse("package:$packageName")
                startActivity(it)
            }
        } catch (_: Throwable) {}
    }

    private fun hardenIfDeviceOwner() {
        try {
            val dpm = getSystemService(DevicePolicyManager::class.java)
            val comp = ComponentName(this, com.example.lockapp.admin.MyDeviceAdminReceiver::class.java)
            if (dpm != null && dpm.isDeviceOwnerApp(packageName)) {
                try { dpm.setKeyguardDisabled(comp, true) } catch (_: Throwable) {}
                try { dpm.setStatusBarDisabled(comp, true) } catch (_: Throwable) {}
                try { if (android.os.Build.VERSION.SDK_INT >= 28) dpm.setLockTaskFeatures(comp, 0) } catch (_: Throwable) {}
                try { dpm.setLockTaskPackages(comp, arrayOf(packageName)) } catch (_: Throwable) {}
                try { startLockTask() } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }

    private fun startEmergencyDialer() {
        val intents = listOf(
            Intent("android.intent.action.DIAL_EMERGENCY"),
            Intent("com.android.phone.EmergencyDialer.DIAL"),
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:112"))
        )
        for (it in intents) {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (it.resolveActivity(packageManager) != null) {
                try {
                    try { stopLockTask() } catch (_: Throwable) {}
                    startActivity(it); return
                } catch (_: Throwable) {}
            }
        }
    }
}