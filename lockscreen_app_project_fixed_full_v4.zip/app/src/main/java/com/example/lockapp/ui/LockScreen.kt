package com.example.lockapp.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import com.example.lockapp.data.AppDatabase
import com.example.lockapp.data.Repo
import kotlinx.coroutines.launch
import kotlin.random.Random

@Composable
fun LockScreen(onUnlock: () -> Unit) {
    val ctx = LocalContext.current
    val repo = remember { Repo(ctx) }
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf(listOf<com.example.lockapp.data.ImagePassword>()) }
    var currentIndex by remember { mutableStateOf(0) }
    var pwd by remember { mutableStateOf("") }
    var neonScale by remember { mutableStateOf(1f) }

    LaunchedEffect(Unit) {
        items = repo.all()
        if (items.isNotEmpty()) {
            currentIndex = Random.nextInt(items.size) // 支持随机，后续可换顺序模式
        }
        // 简单的霓虹跳动效果
        while (true) {
            neonScale = 1.0f
            kotlinx.coroutines.delay(450)
            neonScale = 1.06f
            kotlinx.coroutines.delay(450)
        }
    }

    if (items.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("尚未添加图片。请回主界面添加后再试。")
        }
        return
    }

    val cur = items[currentIndex]

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = rememberAsyncImagePainter(model = cur.uri),
            contentDescription = null,
            modifier = Modifier
                .size(280.dp)
                .scale(neonScale)
        )
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = pwd,
            onValueChange = { if (it.length <= 100) pwd = it },
            label = { Text("输入密码解锁") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation()
        )
        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            scope.launch {
                if (repo.hash(pwd) == cur.passwordHash) {
                    onUnlock()
                } else {
                    pwd = ""
                }
            }
        }) { Text("解锁") }
    }
}