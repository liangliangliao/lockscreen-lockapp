
package com.example.lockapp.data

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest

class Repo(private val context: Context) {
    private val dao = AppDatabase.get(context).dao()

    suspend fun addImageWithPassword(uri: Uri, passwordText: String) = withContext(Dispatchers.IO) {
        val list = dao.getAllOnce()
        if (list.size >= 50) return@withContext
        persistUriPermission(uri)
        val index = list.size
        dao.upsert(ImagePassword(uri = uri.toString(), passwordHash = hash(passwordText), orderIndex = index))
    }

    suspend fun all(): List<ImagePassword> = withContext(Dispatchers.IO) { dao.getAllOnce() }
    suspend fun count(): Int = withContext(Dispatchers.IO) { dao.count() }

    fun hash(text: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val bytes = md.digest(text.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun persistUriPermission(uri: Uri) {
        try {
            context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {}
    }
}
