package com.example.lockapp.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.lockapp.R

private const val CH_DEBUG = "lock_debug"
private const val CH_FULL = "lock_full"

fun showDebugHeadsUp(ctx: Context, title: String, text: String, contentIntent: PendingIntent? = null, id: Int = 1500) {
    ensureChannels(ctx)
    val builder = NotificationCompat.Builder(ctx, CH_DEBUG)
        .setSmallIcon(R.mipmap.ic_launcher)
        .setContentTitle(title)
        .setContentText(text)
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setDefaults(NotificationCompat.DEFAULT_ALL)
        .setAutoCancel(true)
    contentIntent?.let { builder.setContentIntent(it) }
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    nm.notify(id, builder.build())
}

fun showFullScreen(ctx: Context, title: String, text: String, fullScreenPi: PendingIntent, id: Int = 1600) {
    ensureChannels(ctx)
    val builder = NotificationCompat.Builder(ctx, CH_FULL)
        .setSmallIcon(R.mipmap.ic_launcher)
        .setContentTitle(title)
        .setContentText(text)
        .setPriority(NotificationCompat.PRIORITY_MAX)
        .setDefaults(NotificationCompat.DEFAULT_ALL)
        .setAutoCancel(true)
    val notif = setFullScreenIntent(builder, fullScreenPi)
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    nm.notify(id, notif)
}

private fun ensureChannels(ctx: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CH_DEBUG) == null) {
            nm.createNotificationChannel(NotificationChannel(CH_DEBUG, "Debug", NotificationManager.IMPORTANCE_HIGH))
        }
        if (nm.getNotificationChannel(CH_FULL) == null) {
            nm.createNotificationChannel(NotificationChannel(CH_FULL, "Full Screen", NotificationManager.IMPORTANCE_HIGH))
        }
    }
}
