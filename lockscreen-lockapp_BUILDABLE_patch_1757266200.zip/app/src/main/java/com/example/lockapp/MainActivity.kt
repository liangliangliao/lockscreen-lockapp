package com.example.lockapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.util.CompatIcons
import com.example.lockapp.util.NotifCompatShims

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Activity content not required for build; UI provided elsewhere.
    }

    fun showFullScreenHint() {
        val chId = "lockapp_fsi"
        ensureChannel(chId)

        val piFlags = PendingIntent.FLAG_UPDATE_CURRENT or (if (android.os.Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val contentPi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            piFlags
        )

        val builder = NotificationCompat.Builder(this, chId)
            .setSmallIcon(CompatIcons.LAUNCHER_ICON)
            .setContentTitle(getString(R.string.app_name))
            .setContentText("Tap to open")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(Notification.CATEGORY_CALL)
            .setAutoCancel(true)
            .setContentIntent(contentPi)

        val n: Notification = NotifCompatShims.setFullScreenIntent(builder, contentPi, true)
        NotificationManagerCompat.from(this).notify(2001, n)
    }

    private fun ensureChannel(id: String) {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(id, "Full Screen Intent", NotificationManager.IMPORTANCE_HIGH))
        }
    }
}
