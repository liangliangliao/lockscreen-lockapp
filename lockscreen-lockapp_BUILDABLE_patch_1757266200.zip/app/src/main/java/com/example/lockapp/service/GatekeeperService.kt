package com.example.lockapp.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.lockapp.MainActivity
import com.example.lockapp.R
import com.example.lockapp.util.setFullScreenIntent

class GatekeeperService : Service() {

    companion object {
        private const val CH_GUARD = "gatekeeper_guard"
        private const val CH_FULL = "gatekeeper_full"
        private const val ID_GUARD = 2100
    }

    override fun onCreate() {
        super.onCreate()
        ensureChannels()
        startForeground(ID_GUARD, guardNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Could react to intents here (omitted for compile safety).
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun ensureChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CH_GUARD) == null) {
                nm.createNotificationChannel(NotificationChannel(CH_GUARD, "Lock Guard", NotificationManager.IMPORTANCE_LOW))
            }
            if (nm.getNotificationChannel(CH_FULL) == null) {
                nm.createNotificationChannel(NotificationChannel(CH_FULL, "FSI", NotificationManager.IMPORTANCE_HIGH))
            }
        }
    }

    private fun guardNotification(): Notification {
        val contentPi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        return NotificationCompat.Builder(this, CH_GUARD)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("LockApp running")
            .setContentText("Guarding lock state")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(contentPi)
            .build()
    }

    private fun postFullScreen() {
        val fullPi = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        val builder = NotificationCompat.Builder(this, CH_FULL)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Unlock required")
            .setContentText("Tap to proceed")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
        val notif = setFullScreenIntent(builder, fullPi)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(2101, notif)
    }
}
