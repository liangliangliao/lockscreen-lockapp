package com.example.lockapp.setup

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.lockapp.R
import com.example.lockapp.MainActivity
import com.example.lockapp.util.setFullScreenIntent

private const val CHANNEL_ID = "lock_debug_fullscreen"

fun pokeFullScreenNotification(ctx: Context) {
    // Create channel
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL_ID, "FSI Test", NotificationManager.IMPORTANCE_HIGH)
        nm.createNotificationChannel(ch)
    }
    // Fullscreen Pi to MainActivity for demo
    val fullPi = PendingIntent.getActivity(
        ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
    )
    val builder = NotificationCompat.Builder(ctx, CHANNEL_ID)
        .setSmallIcon(R.mipmap.ic_launcher)
        .setContentTitle("Wake demo")
        .setContentText("Triggering full-screen intent")
        .setAutoCancel(true)
        .setPriority(NotificationCompat.PRIORITY_MAX)
    val notif = setFullScreenIntent(builder, fullPi)
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    nm.notify(2001, notif)
}
