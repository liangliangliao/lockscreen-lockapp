import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import 'db.dart';

class QuoteDao {
  Future<void> seedDefaultQuote() async {
    final db = await AppDatabase.instance();
    final c = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM quotes')) ?? 0;
    if (c > 0) return;
    await db.insert('quotes', {
      'text': '凡是不能杀死我的，必使我更坚强。',
      'author': '弗里德里希·尼采',
      'source': '《偶像的黄昏》',
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
  }

  Future<Map<String, dynamic>?> fetchLatest() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', orderBy: 'created_at DESC', limit: 1);
    return rows.isEmpty ? null : rows.first;
  }

  Future<List<Map<String, dynamic>>> fetchPaged({int offset = 0, int limit = 100, String? keyword}) async {
    final db = await AppDatabase.instance();
    if (keyword == null || keyword.trim().isEmpty) {
      return db.query('quotes', orderBy: 'created_at DESC', limit: limit, offset: offset);
    }
    final k = '%${keyword.trim()}%';
    return db.query('quotes',
        where: 'text LIKE ? OR author LIKE ? OR source LIKE ?',
        whereArgs: [k, k, k],
        orderBy: 'created_at DESC',
        limit: limit,
        offset: offset);
  }

  Future<void> insertQuote(String text, {String author = '', String source = ''}) async {
    final db = await AppDatabase.instance();
    await db.insert('quotes', {
      'text': text,
      'author': author,
      'source': source,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
  }
}

class SettingsDao {
  Future<Map<String, dynamic>> getSettings() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('settings', limit: 1);
    return rows.isEmpty ? {'api_key': '', 'auto_enabled': 0} : rows.first;
  }
  Future<void> updateSettings({String? apiKey, bool? autoEnabled}) async {
    final db = await AppDatabase.instance();
    final current = await getSettings();
    await db.update('settings', {
      'api_key': apiKey ?? current['api_key'],
      'auto_enabled': (autoEnabled ?? (current['auto_enabled'] == 1)) ? 1 : 0
    });
  }

  Future<void> upsertPrompt(String content) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now().millisecondsSinceEpoch;
    await db.transaction((txn) async {
      await txn.update('prompts', {'is_default': 0});
      await txn.insert('prompts', {'content': content, 'is_default': 1, 'updated_at': now});
    });
  }
  Future<String> getDefaultPrompt() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('prompts', where: 'is_default=1', limit: 1, orderBy: 'updated_at DESC');
    return rows.isEmpty ? '给我一句简短的名人名言，并附上作者与来源（中文）。' : (rows.first['content'] as String);
  }
}

class ScheduleDao {
  Future<List<Map<String, dynamic>>> all() async {
    final db = await AppDatabase.instance();
    return db.query('schedules', orderBy: 'next_run_at ASC');
  }
  Future<void> add(Map<String, dynamic> s) async {
    final db = await AppDatabase.instance();
    await db.insert('schedules', {'type': s['type'], 'payload': jsonEncode(s['payload']), 'enabled': s['enabled'] ?? 1, 'next_run_at': s['next_run_at']});
  }
  Future<void> clear() async {
    final db = await AppDatabase.instance();
    await db.delete('schedules');
  }
}
