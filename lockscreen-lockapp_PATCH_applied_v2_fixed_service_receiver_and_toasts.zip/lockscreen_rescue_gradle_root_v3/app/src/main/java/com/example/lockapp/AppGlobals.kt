package com.example.lockapp

import android.app.Application
import android.content.Context

object AppGlobals {
    private lateinit var app: Application

    fun init(application: Application) {
        app = application
    }

    val context: Context
        get() = app.applicationContext
}
