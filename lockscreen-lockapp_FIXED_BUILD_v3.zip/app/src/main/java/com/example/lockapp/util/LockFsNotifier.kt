package com.example.lockapp.util

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.R

object LockFsNotifier {
    private const val CH_HEADS_UP_ID = "lockapp_debug_heads_up"
    private const val CH_FSI_ID = "lockapp_fs_fullscreen"

    private fun ensureChannel(ctx: Context, channelId: String, name: String, importance: Int) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(channelId) == null) {
                val ch = NotificationChannel(channelId, name, importance)
                nm.createNotificationChannel(ch)
            }
        }
    }

    private fun defaultContentIntent(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, LockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0) or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** Simple heads-up notification for debugging visibility. */
    @JvmStatic
    fun showDebugHeadsUp(ctx: Context, title: String, text: String) {
        ensureChannel(ctx, CH_HEADS_UP_ID, "LockApp Debug", NotificationManager.IMPORTANCE_HIGH)
        val builder = NotificationCompat.Builder(ctx, CH_HEADS_UP_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
        NotificationManagerCompat.from(ctx).notify(1002, builder.build())
    }

    /** Full-screen intent style notification. */
    @JvmStatic
    fun showFullScreen(ctx: Context, title: String = "Unlock required", text: String = "Tap to open lock screen") {
        ensureChannel(ctx, CH_FSI_ID, "LockApp Fullscreen", NotificationManager.IMPORTANCE_HIGH)

        val fullPi = defaultContentIntent(ctx)
        val builder = NotificationCompat.Builder(ctx, CH_FSI_ID)
            .setSmallIcon(android.android.R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(Notification.CATEGORY_CALL)
            .setAutoCancel(true)
            .setFullScreenIntent(fullPi, /* highPriority = */ true)

        NotificationManagerCompat.from(ctx).notify(1003, builder.build())
    }
}
