package com.example.lockapp.util

import com.example.lockapp.R

object CompatIcons {
    @JvmField val LAUNCHER_ICON = android.R.mipmap.ic_launcher
}
