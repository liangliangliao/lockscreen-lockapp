import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'data/dao.dart';
import 'services/notification_service.dart';
import 'services/notification_service.dart' show NotificationOrchestrator;
import 'services/scheduler_service.dart';
import 'pages/home_page.dart';

const bool kSafeHome = bool.fromEnvironment('SAFE_HOME', defaultValue: false);
const int kFallbackSeconds = int.fromEnvironment('FALLBACK_AFTER', defaultValue: 8);

bool _secondAppFirstFrame = false;
void _markSecondAppFirstFrame() { _secondAppFirstFrame = true; }

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  FlutterError.onError = (details) { FlutterError.presentError(details); };
  PlatformDispatcher.instance.onError = (error, stack) { return true; };
  ErrorWidget.builder = (details) => const SizedBox.shrink();

  if (kSafeHome) { runApp(const _SafeHome()); return; }

  runApp(const _BootstrapShell());

  WidgetsBinding.instance.addPostFrameCallback((_) async {
    try { await NotificationService.init(); } catch (_) {}
    try { await SchedulerService.initBackground(); } catch (_) {}
    try { await SchedulerService.registerPeriodic(); } catch (_) {}
    try { await QuoteDao().seedDefaultQuote(); } catch (_) {}
    try { await NotificationOrchestrator.checkAndNotifyNewQuotes(); } catch (_) {}

    final Widget realApp = _AppGuard(child: const MyApp());
    runApp(realApp);

    if (kFallbackSeconds > 0) {
      Future.delayed(Duration(seconds: kFallbackSeconds), () {
        if (!_secondAppFirstFrame) runApp(const _DiagnosticsApp());
      });
    }
  });
}

class _BootstrapShell extends StatelessWidget {
  const _BootstrapShell({super.key});
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(body: Center(child: CircularProgressIndicator())),
    );
  }
}

class _AppGuard extends StatefulWidget {
  final Widget child;
  const _AppGuard({super.key, required this.child});
  @override
  State<_AppGuard> createState() => _AppGuardState();
}
class _AppGuardState extends State<_AppGuard> {
  @override
  void initState() { super.initState(); WidgetsBinding.instance.addPostFrameCallback((_) { _markSecondAppFirstFrame(); }); }
  @override
  Widget build(BuildContext context) => widget.child;
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: const HomePage(),
    );
  }
}

class _DiagnosticsApp extends StatelessWidget {
  const _DiagnosticsApp({super.key});
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(body: Center(child: Text('应用启动异常：未能绘制首帧，已进入诊断模式。'))),
    );
  }
}

class _SafeHome extends StatelessWidget {
  const _SafeHome({super.key});
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(body: Center(child: Text('Engine OK'))),
    );
  }
}
