import 'package:flutter/material.dart';

class QuoteCard extends StatelessWidget {
  final String text;
  final String author;
  final String source;
  const QuoteCard({super.key, required this.text, required this.author, required this.source});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(text, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('—— $author', style: Theme.of(context).textTheme.bodyMedium),
                Text(source, style: Theme.of(context).textTheme.bodySmall),
              ],
            )
          ],
        ),
      ),
    );
  }
}
