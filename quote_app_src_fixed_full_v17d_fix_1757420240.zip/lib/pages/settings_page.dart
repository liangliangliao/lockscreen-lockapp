import 'dart:convert';
import 'package:flutter/material.dart';
import '../data/dao.dart';
import '../services/notification_service.dart' show NotificationOrchestrator;

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final SettingsDao _settingsDao = SettingsDao();
  final ScheduleDao _scheduleDao = ScheduleDao();
  final TextEditingController _apiKeyCtrl = TextEditingController();
  final TextEditingController _promptCtrl = TextEditingController();
  final TextEditingController _manualQuoteCtrl = TextEditingController();

  bool _autoEnabled = false;
  List<Map<String,dynamic>> _schedules = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final s = await _settingsDao.getSettings();
    _apiKeyCtrl.text = (s['api_key'] as String?) ?? '';
    _autoEnabled = (s['auto_enabled'] == 1);
    _schedules = await _scheduleDao.all();
    _schedules.sort((a,b)=> (b['id'] as int).compareTo(a['id'] as int));
    if (mounted) setState((){});
  }

  Future<void> _saveAll() async {
    await _settingsDao.updateSettings(apiKey: _apiKeyCtrl.text.trim(), autoEnabled: _autoEnabled);
    if (_promptCtrl.text.trim().isNotEmpty) {
      await _settingsDao.upsertPrompt(_promptCtrl.text.trim());
    }
    if (_manualQuoteCtrl.text.trim().isNotEmpty) {
      await QuoteDao().insertQuote(_manualQuoteCtrl.text.trim(), author: '手动', source: '设置页');
      try { await NotificationOrchestrator.checkAndNotifyNewQuotes(); } catch (_) {}
      _manualQuoteCtrl.clear();
    }
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存')));
  }

  Future<void> _addDaily() async {
    final now = TimeOfDay.now();
    final time = await showTimePicker(context: context, initialTime: now);
    if (time == null) return;
    final payload = {'time': '${time.hour.toString().padLeft(2,'0')}:${time.minute.toString().padLeft(2,'0')}:00'};
    await _scheduleDao.add({'type': 'daily', 'payload': payload, 'enabled': 1});
    _schedules = await _scheduleDao.all();
    _schedules.sort((a,b)=> (b['id'] as int).compareTo(a['id'] as int));
    if (mounted) setState((){});
  }

  String _readable(Map<String,dynamic> s) {
    final type = s['type'] as String;
    final payload = (s['payload'] is String) ? jsonDecode(s['payload'] as String) : s['payload'] as Map<String,dynamic>;
    if (type == 'daily') return '每日 · ${payload['time']}';
    if (type == 'weekly') return '每周 · ${payload['weekday']} ${payload['time']}';
    return '自定义 · ${payload['date']} ${payload['time']}';
  }

  Future<void> _editDaily(int id, Map<String,dynamic> s) async {
    final payload = s['payload'] is String ? jsonDecode(s['payload'] as String) : s['payload'] as Map<String,dynamic>;
    final t = (payload['time'] as String? ?? '08:00:00').split(':');
    final initial = TimeOfDay(hour: int.tryParse(t[0]) ?? 8, minute: int.tryParse(t[1]) ?? 0);
    final picked = await showTimePicker(context: context, initialTime: initial);
    if (picked != null) {
      final newPayload = {'time': '${picked.hour.toString().padLeft(2,'0')}:${picked.minute.toString().padLeft(2,'0')}:00'};
      await _scheduleDao.updatePayload(id, newPayload);
      _schedules = await _scheduleDao.all();
      if (mounted) setState((){});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('设置'),
        actions: [ IconButton(icon: const Icon(Icons.save), onPressed: _saveAll) ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _manualQuoteCtrl,
            maxLength: 100,
            minLines: 3,
            maxLines: 5,
            decoration: const InputDecoration(
              labelText: '手动添加名言（100字）',
              hintText: '输入后点右上角保存将写入数据库并触发通知',
              alignLabelWithHint: true,
            ),
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            title: const Text('自动获取开关'),
            value: _autoEnabled,
            onChanged: (v){ setState(()=> _autoEnabled = v); },
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _apiKeyCtrl,
            decoration: const InputDecoration(labelText: 'OpenAI API Key'),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _promptCtrl,
            minLines: 3,
            maxLines: 5,
            decoration: const InputDecoration(
              labelText: '提示词（用于生成名言）',
              alignLabelWithHint: true,
            ),
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            icon: const Icon(Icons.add),
            label: const Text('添加每日定时'),
            onPressed: _addDaily,
          ),
          const SizedBox(height: 16),
          Row(
  children: [
    const Expanded(child: Text('已添加的任务', style: TextStyle(fontWeight: FontWeight.bold))),
    TextButton.icon(
      onPressed: _openCreateTaskDialog,
      icon: const Icon(Icons.add_task),
      label: const Text('新增任务'),
    ),
  ],
),
          const SizedBox(height: 8),
          ..._schedules.map((s) {
            final id = s['id'] as int;
            return ListTile(
              dense: true,
              title: Text(((s['payload'] is String ? jsonDecode(s['payload']) : s['payload'])['name'] ?? '未命名') as String),
              subtitle: Text(_readableTime(s)),
              onTap: () async {
                if ((s['type'] as String) == 'daily') {
                  await _editDaily(id, s);
                }
              },
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: const Icon(Icons.edit),
                    onPressed: () async {
                      if ((s['type'] as String) == 'daily') {
                        await _editDaily(id, s);
                      }
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete),
                    onPressed: () async {
                      await _scheduleDao.deleteById(id);
                      _schedules = await _scheduleDao.all();
                      if (mounted) setState((){});
                    },
                  ),
                ],
              ),
            );
          }).toList(),
        ],
      ),
    );
  }
}
