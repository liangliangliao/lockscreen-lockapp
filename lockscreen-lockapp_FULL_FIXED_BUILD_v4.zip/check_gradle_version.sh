
#!/bin/bash
./gradlew --version
