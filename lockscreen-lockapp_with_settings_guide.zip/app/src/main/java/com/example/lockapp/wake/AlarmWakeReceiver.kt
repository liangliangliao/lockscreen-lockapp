package com.example.lockapp.wake

import android.app.AlarmManager
import android.app.KeyguardManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import androidx.core.content.ContextCompat
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.util.LockCoordinator
import com.example.lockapp.util.LockVisibilityTracker
import com.example.lockapp.util.LockFsNotifier

class AlarmWakeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_LOCK_WAKE) return
        val km = context.getSystemService(KeyguardManager::class.java)
        if (km?.isKeyguardLocked != true) return
        if (!LockCoordinator.isLocked(context)) return
        if (LockVisibilityTracker.visible) return

        val pm = context.getSystemService(PowerManager::class.java)
        val wl = try { pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lockapp:wake") } catch (_: Throwable) { null }
        try {
            try { wl?.acquire(800) } catch (_: Throwable) {}

            try {
                val act = Intent(context, LockScreenActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
                    .putExtra("from_alarm_wake", true)
                ContextCompat.startActivity(context, act, null)
                return
            } catch (_: Throwable) { }

            try { LockFsNotifier.showFullScreen(context) } catch (_: Throwable) {}
        } finally {
            try { if (wl?.isHeld == true) wl.release() } catch (_: Throwable) {}
        }
    }

    companion object {
        const val ACTION_LOCK_WAKE = "com.example.lockapp.action.LOCK_WAKE"

        fun schedule(context: Context, delayMs: Long = 300) {
            try {
                val am = context.getSystemService(AlarmManager::class.java) ?: return
                val isSamsung = Build.MANUFACTURER.equals("samsung", ignoreCase = true)
                val delay = if (isSamsung) maxOf(delayMs, 700L) else delayMs
                val triggerAt = System.currentTimeMillis() + delay.coerceAtLeast(100)

                if (isSamsung) {
                    val flags = (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0) or PendingIntent.FLAG_UPDATE_CURRENT
                    val act = Intent(context, LockScreenActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
                        .putExtra("from_alarm_wake", true)
                    val piAct = PendingIntent.getActivity(context, 4101, act, flags)
                    val info = AlarmManager.AlarmClockInfo(triggerAt, piAct)
                    am.setAlarmClock(info, piAct)
                    return
                }

                val flags = (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0) or PendingIntent.FLAG_UPDATE_CURRENT
                val pi = PendingIntent.getBroadcast(
                    context, 3101,
                    Intent(context, AlarmWakeReceiver::class.java).setAction(ACTION_LOCK_WAKE),
                    flags
                )
                if (Build.VERSION.SDK_INT >= 23) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                } else {
                    am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                }
            } catch (_: Throwable) { }
        }
    }
}
