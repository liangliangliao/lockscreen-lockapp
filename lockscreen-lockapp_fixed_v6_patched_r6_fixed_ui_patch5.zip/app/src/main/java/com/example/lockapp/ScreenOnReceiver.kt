package com.example.lockapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import com.example.lockapp.util.LockCoordinator
import com.example.lockapp.util.LockVisibilityTracker
import com.example.lockapp.util.LockFsNotifier

class ScreenOnReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_SCREEN_OFF -> {
                // 息屏：置锁 + 复位闸门
                LockCoordinator.markLocked(context)
                LockCoordinator.leaveShowing()
                LockVisibilityTracker.visible = false
            }
            Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> {
                val i = Intent(context, LockScreenActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)

                var launched = false
                if (LockCoordinator.isLocked(context)
                    && !LockVisibilityTracker.visible
                    && LockCoordinator.requestShowOnce()
                    && LockCoordinator.tryEnterShowing()
                ) {
                    try {
                        context.startActivity(i)
                        launched = true
                    } catch (_: Throwable) { }
                }

                // 兜底：如果未显示则用全屏通知拉起
                Handler(Looper.getMainLooper()).postDelayed({
                    if (!LockVisibilityTracker.visible && LockCoordinator.isLocked(context)) {
                        LockFsNotifier.showFullScreen(context)
                    }
                }, 120)
            }
        }
    }
}
