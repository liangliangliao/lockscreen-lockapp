package com.example.lockapp.service
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.overlay.OverlayLockService
import com.example.lockapp.util.LockVisibilityTracker

class GatekeeperService : Service() {

    private val prefs by lazy { getSharedPreferences("gatekeeper", MODE_PRIVATE) }
    private fun lastLaunchMs(): Long = prefs.getLong("last_launch_ms", 0L)
    private fun markLaunchNow() { prefs.edit().putLong("last_launch_ms", SystemClock.elapsedRealtime()).apply() }
    private fun shouldLaunch(): Boolean = (SystemClock.elapsedRealtime() - lastLaunchMs()) > 2500L

    private fun newCycleToken(): Long = SystemClock.elapsedRealtime()
    private fun setToken(t: Long) { prefs.edit().putLong("cycle_token", t).apply() }
    private fun getToken(): Long = prefs.getLong("cycle_token", 0L)
    private fun markDidAct(t: Long) { prefs.edit().putLong("cycle_done", t).apply() }
    private fun didAct(t: Long): Boolean = prefs.getLong("cycle_done", 0L) == t

    private val mainHandler by lazy { Handler(Looper.getMainLooper()) }
    private lateinit var screenReceiver: BroadcastReceiver

    companion object {
        private const val NOTIF_ID_GATEKEEPER = 20001
        private const val CH_ID_FSI = "gatekeeper_alert_v3"
        private const val CH_ID_CORE = "guard_core"
        private const val NOTIF_ID_CORE = 20002
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ensureCoreChannel()
        val core = NotificationCompat.Builder(this, CH_ID_CORE)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("锁屏守护已启用")
            .setContentText("保持监听亮屏事件以顶起解锁界面")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        startForeground(NOTIF_ID_CORE, core)

        screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                when (intent.action) {
                    Intent.ACTION_SCREEN_ON,
                    Intent.ACTION_USER_PRESENT,
                    Intent.ACTION_USER_UNLOCKED -> scheduleGate()
                }
            }
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_USER_UNLOCKED)
        }
        registerReceiver(screenReceiver, f)
    }

    override fun onDestroy() {
        try { unregisterReceiver(screenReceiver) } catch (_: Throwable) {}
        stopForeground(STOP_FOREGROUND_DETACH)
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        scheduleGate()
        return START_STICKY
    }

    private fun scheduleGate() {
        val token = newCycleToken()
        setToken(token)

        // 0ms: 优先 FSI
        mainHandler.post {
            if (didAct(token)) return@post
            if (shouldLaunch()) {
                sendFSI()
                markLaunchNow()
                markDidAct(token)
            }
        }
        // 900ms: 解锁态 + overlay 权限 → Overlay 兜底
        mainHandler.postDelayed({
            if (didAct(token)) return@postDelayed
            val unlocked = !isActuallyLocked()
            if (unlocked && canOverlay()) {
                if (shouldLaunch()) {
                    OverlayLockService.show(this)
                    markLaunchNow()
                    markDidAct(token)
                }
            }
        }, 900)
        // 1500ms: 仍锁定 + 未可见 → 再补 FSI
        mainHandler.postDelayed({
            if (didAct(token)) return@postDelayed
            if (isActuallyLocked() && shouldLaunch() && !LockVisibilityTracker.visible) {
                sendFSI()
                markLaunchNow()
                markDidAct(token)
            }
        }, 1500)
    }

    private fun isActuallyLocked(): Boolean {
        val km = getSystemService(KeyguardManager::class.java)
        return (km?.isKeyguardLocked == true) || (km?.isDeviceLocked == true)
    }

    private fun canOverlay(): Boolean =
        !(Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this))

    private fun sendFSI() {
        ensureFsiChannel()
        val i = Intent(this, LockScreenActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        val pi = PendingIntent.getActivity(this, 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(this, CH_ID_FSI)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("需要解锁")
            .setContentText("点击或自动弹出解锁界面")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setDefaults(Notification.DEFAULT_ALL)
            .setCategory(Notification.CATEGORY_CALL)
            .setFullScreenIntent(pi, true)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(this).notify(NOTIF_ID_GATEKEEPER, n)
    }

    private fun ensureFsiChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CH_ID_FSI) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CH_ID_FSI, "Gate prompt", NotificationManager.IMPORTANCE_HIGH).apply {
                        description = "Wake and present lock screen"
                        lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                        setBypassDnd(true)
                    }
                )
            }
        }
    }

    private fun ensureCoreChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CH_ID_CORE) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CH_ID_CORE, "Guard core", NotificationManager.IMPORTANCE_LOW).apply {
                        description = "Keep service alive to listen screen events"
                        lockscreenVisibility = Notification.VISIBILITY_SECRET
                    }
                )
            }
        }
    }
}
