package com.example.lockapp.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ImagePasswordDao {
    @Query("SELECT * FROM ImagePassword ORDER BY orderIndex ASC")
    fun all(): Flow<List<ImagePassword>>

    @Insert
    suspend fun insert(entity: ImagePassword): Long

    @Update
    suspend fun update(entity: ImagePassword)

    @Delete
    suspend fun delete(entity: ImagePassword)

    @Query("DELETE FROM ImagePassword")
    suspend fun clear()

    @Query("SELECT * FROM ImagePassword WHERE uri = :uri LIMIT 1")
    suspend fun findByUri(uri: String): ImagePassword?
}
