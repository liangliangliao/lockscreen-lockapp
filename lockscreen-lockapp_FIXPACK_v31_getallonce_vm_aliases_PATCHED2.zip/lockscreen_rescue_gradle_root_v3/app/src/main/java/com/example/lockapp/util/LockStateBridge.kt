package com.example.lockapp.util

import android.content.Context
import com.example.lockapp.data.LockStateStore

object LockStateBridge {
    @JvmStatic fun setLocked(context: Context, v: Boolean) = LockStateStore(context).setLocked(v)
    @JvmStatic fun isLocked(context: Context): Boolean = LockStateStore(context).isLocked()
}
