package com.example.lockapp.data
import android.content.Context

object ActiveLockStore {
    private const val PREF = "active_lock_store"
    private const val KEY_URI = "uri"
    private const val KEY_PWD = "pwd"
    fun set(context: Context, uri: String?, password: String?) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString(KEY_URI, uri).putString(KEY_PWD, password).apply()
    }
    fun getUri(context: Context): String? =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_URI, null)
    fun getPwd(context: Context): String? =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_PWD, null)
}