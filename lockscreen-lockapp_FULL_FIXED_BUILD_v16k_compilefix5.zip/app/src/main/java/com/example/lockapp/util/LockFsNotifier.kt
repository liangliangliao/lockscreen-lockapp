package com.example.lockapp.util

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/**
 * 通知工具：确保渠道 + 发送 FSI（全屏通知，锁屏显示）。
 */
object LockFsNotifier {

    private const val FSI_CHANNEL_ID = "lock_guard_fsi_v2"

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = context.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(FSI_CHANNEL_ID) == null) {
                val ch = NotificationChannel(
                    FSI_CHANNEL_ID,
                    "LockApp 全屏通知（FSI）",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "用于锁屏场景的全屏弹窗"
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
                nm.createNotificationChannel(ch)
            }
        }
    }

    /**
     * 直接发送一条 FSI，目标为透明跳板。
     */
    fun showFullScreen(context: Context) {
        try {
            ensureChannels(context)

            // PendingIntent → 透明跳板
            val intent = Intent().apply {
                setClassName(
                    context,
                    "com.example.lockapp.launcher.TransparentTrampolineActivity"
                )
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                action = "com.example.lockapp.SHOW_LOCK_FROM_FSI"
                putExtra("from_fsi", true)
            }
            val pi = PendingIntent.getActivity(
                context, 2102, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // 调试提示
            Toaster.show5s(context, "正在发送全屏弹窗（FSI）[LockFsNotifier]")

            // 构建并发送通知（带全屏 Intent）
            val n = NotificationCompat.Builder(context, FSI_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("锁屏唤起")
                .setContentText("触发全屏通知兜底")
                .setCategory(Notification.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setFullScreenIntent(pi, true)
                .build()

            NotificationManagerCompat.from(context).notify(2102, n)
        } catch (t: Throwable) {
            DebugLog.w("LockFsNotifier", "showFullScreen 失败: ${t.message}", t)
        }
    }
}
