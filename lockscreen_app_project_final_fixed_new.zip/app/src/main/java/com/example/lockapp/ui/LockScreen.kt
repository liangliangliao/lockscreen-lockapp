package com.example.lockapp.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.lockapp.R

/**
 * Composable used on the lock screen. Displays the current image with an animated neon effect,
 * shows a password input field and notifies the hosting activity when the correct password is
 * entered. On failure an error message appears prompting the user to try again.
 *
 * @param viewModel the lock screen view model managing current entry and verification
 * @param onUnlock callback invoked when the password has been verified successfully
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LockScreen(viewModel: LockScreenViewModel, onUnlock: () -> Unit) {
    val entry by viewModel.currentEntry.collectAsState()
    val unlockResult by viewModel.unlockResult.collectAsState()
    var password by remember { mutableStateOf("") }

    // When unlock result becomes true, call onUnlock and reset password state
    LaunchedEffect(unlockResult) {
        if (unlockResult == true) {
            // Reset password text
            password = ""
            onUnlock()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (entry == null) {
            Text(text = stringResource(id = R.string.add_image))
            return
        }
        // Show neon animated image for the current entry
        NeonAnimatedImage(
            model = entry!!.uri,
            modifier = Modifier
                .size(250.dp)
        )
        // Error message when last attempt failed
        if (unlockResult == false) {
            Text(
                text = stringResource(id = R.string.password_wrong),
                color = androidx.compose.ui.graphics.Color.Red,
                modifier = Modifier.padding(top = 16.dp)
            )
        }
        // Password input
        OutlinedTextField(
            value = password,
            onValueChange = {
                if (it.length <= 100) password = it
            },
            label = { Text(text = stringResource(id = R.string.enter_password)) },
            placeholder = { Text(text = stringResource(id = R.string.enter_password)) },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 24.dp)
        )
        Button(
            onClick = {
                viewModel.verifyPassword(password)
            },
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .padding(top = 24.dp)
        ) {
            Text(text = stringResource(id = R.string.unlock))
        }
    }
}