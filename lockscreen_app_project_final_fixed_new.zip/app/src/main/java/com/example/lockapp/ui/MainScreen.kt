package com.example.lockapp.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.PickVisualMediaRequest
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
// Removed unused Shuffle and Sort icons import. These icons are not used in the UI
// and cause unresolved reference errors when material-icons-extended is not included.
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import android.app.WallpaperManager
import android.widget.Toast
import android.content.Intent
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import coil.compose.AsyncImage
import com.example.lockapp.R
import com.example.lockapp.data.ImagePassword
import com.example.lockapp.data.RotationMode

/**
 * Top-level screen that allows the user to manage their collection of image/password pairs,
 * select the rotation mode and import new images from the device's photo picker. Displays
 * existing images in a list with options to edit or delete each entry. Uses a dialog to
 * prompt for passwords when importing or editing.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val entries by viewModel.entries.collectAsState()
    val rotationMode by viewModel.rotationMode.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current

    // List of URIs pending password entry when importing multiple images
    val pendingUris = remember { mutableStateListOf<Uri>() }
    // Currently active URI being assigned a password (when importing)
    var currentImportUri by remember { mutableStateOf<Uri?>(null) }
    // Entry currently being edited, null when not editing
    var editingEntry by remember { mutableStateOf<ImagePassword?>(null) }
    // Entry currently being previewed. When non-null, a preview dialog will be shown allowing
    // the user to set this image as the lock screen wallpaper. This satisfies the requirement
    // that tapping an image should allow previewing and applying it as the lock screen photo.
    var previewEntry by remember { mutableStateOf<ImagePassword?>(null) }
    // Password text field state used for both import and edit dialogs
    var passwordText by remember { mutableStateOf(TextFieldValue("")) }
    // Controls visibility of the password dialog
    var showPasswordDialog by remember { mutableStateOf(false) }

    // Launcher for selecting multiple images (up to system imposed limit). When images are
    // returned we enqueue them and show the password dialog for the first.
    val pickImagesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            pendingUris.clear()
            pendingUris.addAll(uris)
            // Take persistable read permission for each URI so the app can access it later
            uris.forEach { uri ->
                try {
                    context.contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                } catch (_: Exception) {
                    // ignore if permission cannot be taken
                }
            }
            // Start with the first image in the queue
            currentImportUri = pendingUris.removeAt(0)
            passwordText = TextFieldValue("")
            showPasswordDialog = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text(text = stringResource(id = R.string.app_name)) })
        },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                // Launch the photo picker with an explicit request object.
                // Passing `null` here would cause a NullPointerException in
                // PickMultipleVisualMedia.getSynchronousResult() on Android 14+.
                pickImagesLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            }) {
                Icon(Icons.Default.Add, contentDescription = stringResource(id = R.string.add_image))
            }
        },
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState)
        }
    ) { padding ->
        Column(modifier = Modifier
            .padding(padding)
            .fillMaxSize()) {
            // Rotation mode selection row
            RotationSelector(
                selected = rotationMode,
                onSelect = { mode -> viewModel.setRotationMode(mode) }
            )

            // List of image/password entries
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(entries) { entry ->
                    EntryRow(
                        entry = entry,
                        onPreview = {
                            // Show preview dialog for this entry
                            previewEntry = entry
                        },
                        onEdit = {
                            editingEntry = entry
                            passwordText = TextFieldValue(entry.password)
                            showPasswordDialog = true
                        },
                        onDelete = { viewModel.delete(entry) }
                    )
                }
            }
        }

        // Password prompt dialog used for both importing and editing
        if (showPasswordDialog) {
            val isEdit = editingEntry != null
            AlertDialog(
                onDismissRequest = {
                    // Canceling clears editing/import state
                    editingEntry = null
                    currentImportUri = null
                    passwordText = TextFieldValue("")
                    pendingUris.clear()
                    showPasswordDialog = false
                },
                confirmButton = {
                    val coroutineScope = rememberCoroutineScope()
                    TextButton(onClick = {
                        val password = passwordText.text
                        if (password.isBlank()) {
                            // Show a snackbar prompting user to enter password
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar(
                                    message = context.getString(R.string.enter_password)
                                )
                            }
                            return@TextButton
                        }
                        if (isEdit) {
                            editingEntry?.let { entry ->
                                viewModel.insertOrUpdate(
                                    uri = Uri.parse(entry.uri),
                                    password = password,
                                    existing = entry
                                )
                            }
                            editingEntry = null
                            showPasswordDialog = false
                            passwordText = TextFieldValue("")
                        } else {
                            currentImportUri?.let { uri ->
                                viewModel.insertOrUpdate(uri = uri, password = password, existing = null)
                            }
                            // Clear current and move to next pending URI
                            if (pendingUris.isNotEmpty()) {
                                currentImportUri = pendingUris.removeAt(0)
                                passwordText = TextFieldValue("")
                                // Keep dialog open for next password
                                showPasswordDialog = true
                            } else {
                                currentImportUri = null
                                passwordText = TextFieldValue("")
                                showPasswordDialog = false
                            }
                        }
                    }) {
                        Text(text = stringResource(id = R.string.save))
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        // Cancel import/edit
                        editingEntry = null
                        currentImportUri = null
                        pendingUris.clear()
                        passwordText = TextFieldValue("")
                        showPasswordDialog = false
                    }) {
                        Text(text = stringResource(id = R.string.cancel))
                    }
                },
                title = {
                    Text(text = if (isEdit) stringResource(id = R.string.edit_password) else stringResource(id = R.string.enter_password))
                },
                text = {
                    androidx.compose.material3.OutlinedTextField(
                        value = passwordText,
                        onValueChange = { passwordText = it.copy(text = it.text.take(100)) },
                        label = { Text(text = stringResource(id = R.string.enter_password)) },
                        placeholder = { Text(text = stringResource(id = R.string.enter_password)) },
                        singleLine = true
                    )
                }
            )
        }

        // Preview dialog allowing the user to see the selected image in neon style and set it as
        // the lock screen wallpaper. When the user confirms, the wallpaper manager will be used
        // to update the lock screen. The preview dialog is dismissed afterwards.
        previewEntry?.let { entry ->
            val ctx = LocalContext.current
            AlertDialog(
                onDismissRequest = { previewEntry = null },
                title = { Text(text = stringResource(id = R.string.preview_title)) },
                text = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        NeonAnimatedImage(
                            model = entry.uri,
                            modifier = Modifier
                                .size(250.dp)
                        )
                        Text(
                            text = stringResource(id = R.string.preview_description),
                            modifier = Modifier.padding(top = 16.dp)
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        try {
                            val wm = WallpaperManager.getInstance(ctx)
                            ctx.contentResolver.openInputStream(entry.uri)?.use { stream ->
                                wm.setStream(stream, null, true, WallpaperManager.FLAG_LOCK)
                            }
                            Toast.makeText(ctx, ctx.getString(R.string.lock_screen_updated), Toast.LENGTH_SHORT).show()
                        } catch (_: Exception) {
                            Toast.makeText(ctx, ctx.getString(R.string.lock_screen_update_failed), Toast.LENGTH_SHORT).show()
                        }
                        previewEntry = null
                    }) {
                        Text(text = stringResource(id = R.string.set_lock_screen))
                    }
                },
                dismissButton = {
                    TextButton(onClick = { previewEntry = null }) {
                        Text(text = stringResource(id = R.string.cancel))
                    }
                }
            )
        }
    }
}

@Composable
private fun RotationSelector(selected: RotationMode, onSelect: (RotationMode) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = stringResource(id = R.string.rotation_mode))
        Spacer(modifier = Modifier.weight(1f))
        RotationMode.values().forEach { mode ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = selected == mode,
                    onClick = { onSelect(mode) }
                )
                Text(
                    text = when (mode) {
                        RotationMode.SEQUENTIAL -> stringResource(id = R.string.sequential)
                        RotationMode.SHUFFLE -> stringResource(id = R.string.shuffle)
                    },
                    modifier = Modifier.padding(end = 8.dp)
                )
            }
        }

        // Preview dialog is handled in MainScreen instead of here
    }
}

@Composable
private fun EntryRow(entry: ImagePassword, onPreview: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            // Make the entire card clickable to preview the image
            .clickable { onPreview() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Start
        ) {
            // Thumbnail of the image using Coil
            AsyncImage(
                model = entry.uri,
                contentDescription = null,
                modifier = Modifier
                    .size(64.dp)
                    .padding(end = 16.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(text = entry.password, color = Color.Gray)
            }
            IconButton(onClick = { onEdit() }) {
                Icon(Icons.Default.Edit, contentDescription = "Edit password")
            }
            IconButton(onClick = { onDelete() }) {
                Icon(Icons.Default.Delete, contentDescription = "Delete entry")
            }
        }
    }
}