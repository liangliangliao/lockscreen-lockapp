package com.example.lockapp.util

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import androidx.core.app.NotificationCompat

/**
 * Backward-compatible shim to satisfy old call sites that used a free function
 * setFullScreenIntent(builder, pi) or setFullScreenIntent(ctx, builder, pi).
 * We return Notification so code that expects notify(..., result) still works.
 */
fun setFullScreenIntent(builder: NotificationCompat.Builder, fullScreenPi: PendingIntent): Notification {
    builder.setFullScreenIntent(fullScreenPi, true)
    return builder.build()
}

fun setFullScreenIntent(ctx: Context, builder: NotificationCompat.Builder, fullScreenPi: PendingIntent): Notification {
    builder.setFullScreenIntent(fullScreenPi, true)
    return builder.build()
}
