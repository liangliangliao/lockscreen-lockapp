Patched on 20250907T065027Z:
- Normalized NotificationCompat.Builder usage and setFullScreenIntent chaining.
- Ensured notify(..., builder.build()).
- Added launcher icons if missing.
- Added stubs for AppLifecycleHook/AppLockState if referenced.
- Ensured LockScreenActivity present and lockscreen flags set.
This patch tries to be minimal and compatible with existing logic.
