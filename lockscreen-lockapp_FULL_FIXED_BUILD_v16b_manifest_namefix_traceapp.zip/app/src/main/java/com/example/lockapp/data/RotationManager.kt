package com.example.lockapp.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Manages user-configurable rotation settings such as sequential vs shuffle and remembering
 * which image was last displayed on the lock screen. Settings are persisted in the
 * [androidx.datastore.preferences.core.DataStore].
 */
class RotationManager(private val context: Context) {
    companion object {
        // Keys for DataStore fields
        private val MODE_KEY = stringPreferencesKey("rotation_mode")
        private val LAST_INDEX_KEY = intPreferencesKey("last_index")

        // Provide DataStore extension on the application context
        private val Context.dataStore by preferencesDataStore(name = "rotation_prefs")
    }

    /** Expose the stored rotation mode as a Flow of [RotationMode]. */
    val rotationMode: Flow<RotationMode> = context.dataStore.data.map { prefs ->
        when (prefs[MODE_KEY]) {
            RotationMode.SHUFFLE.name -> RotationMode.SHUFFLE
            else -> RotationMode.SEQUENTIAL
        }
    }

    /** Persist a new rotation mode selection. */
    suspend fun setRotationMode(mode: RotationMode) {
        context.dataStore.edit { prefs ->
            prefs[MODE_KEY] = mode.name
        }
    }

    /** Expose the last viewed index as a Flow of Int. Default is -1 when not set. */
    val lastIndex: Flow<Int> = context.dataStore.data.map { it[LAST_INDEX_KEY] ?: -1 }

    /** Persist the last viewed index. */
    suspend fun setLastIndex(index: Int) {
        context.dataStore.edit { prefs ->
            prefs[LAST_INDEX_KEY] = index
        }
    }
}

/**
 * Enumerates the rotation modes supported by the lock screen. When [SEQUENTIAL] is selected the
 * images rotate through the list in order; [SHUFFLE] picks a new image at random each time
 * the device is locked.
 */
enum class RotationMode {
    SEQUENTIAL,
    SHUFFLE
}