package com.example.app.patchlock

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class FullscreenLockActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } catch (_: Throwable) {}
        if (AppLockState.shouldLockNow()) {
            LockDialog.show(this)
        } else {
            finish()
        }
        supportFragmentManager.setFragmentResultListener("unlock", this) { _, _ ->
            LockPositionKeeper.restoreIfNeeded(this)
            finish()
            overridePendingTransition(0, 0)
        }
    }
}
