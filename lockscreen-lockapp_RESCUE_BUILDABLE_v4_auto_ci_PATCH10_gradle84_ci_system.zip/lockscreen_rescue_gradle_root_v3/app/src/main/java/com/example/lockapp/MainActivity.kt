package com.example.lockapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.lockapp.data.ImageStore
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.data.RotationMode
import com.example.lockapp.service.GatekeeperService
import com.example.lockapp.util.DebugToasts

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_rescue)

        // Start service
        startForegroundService(Intent(this, GatekeeperService::class.java))
        DebugToasts.show(this, "Started foreground service")

        val pwdEt = findViewById<EditText>(R.id.pwd_input)
        val savePwd = findViewById<Button>(R.id.btn_save_pwd)
        val addImg = findViewById<Button>(R.id.btn_add_image)
        val modeGroup = findViewById<RadioGroup>(R.id.rotation_group)
        val showNow = findViewById<Button>(R.id.btn_show_now)

        val lockStore = LockStateStore(this)
        val imageStore = ImageStore(this)
        pwdEt.setText(lockStore.getPassword())

        savePwd.setOnClickListener {
            lockStore.setPassword(pwdEt.text.toString())
            DebugToasts.show(this, "Password saved")
        }
        addImg.setOnClickListener {
            // For rescue: just add launcher foreground icon as a resource URI (demo). In real app you'd use SAF
            val uri = Uri.parse("android.resource://${packageName}/${R.drawable.ic_launcher_foreground}")
            val list = imageStore.getImages().toMutableList().apply { add(uri.toString()) }
            imageStore.setImages(list)
            DebugToasts.show(this, "Added demo image (${list.size})")
        }
        modeGroup.setOnCheckedChangeListener { _, id ->
            val mode = if (id == R.id.rb_seq) RotationMode.SEQUENTIAL else RotationMode.RANDOM
            imageStore.setRotationMode(mode)
            DebugToasts.show(this, "Rotation: $mode")
        }
        showNow.setOnClickListener {
            startActivity(Intent(this, LockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}