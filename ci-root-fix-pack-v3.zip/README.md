# CI AutoRoot v3

This workflow fixes: "Directory '.../lockscreen-lockapp/lockscreen-lockapp' does not contain a Gradle build."
It auto-detects where `settings.gradle(.kts)` lives and builds from there.
If the Gradle Wrapper is missing, it will install Gradle 8.4 via SDKMAN and build using `gradle -p <root>`.

## How to use
1. Commit `.github/workflows/android-autoroot-v3.yml` into your repo.
2. Ensure your Android project (with `settings.gradle(.kts)`) is committed either at repo root or in a subfolder (e.g., `android/`, `mobile/`).
3. Prefer committing the Gradle Wrapper (gradlew, gradlew.bat, gradle/wrapper/**). If not present, the workflow will install Gradle on the runner.

## Notes
- If *no* `settings.gradle(.kts)` is found anywhere, the job fails early with a clear error.
- The workflow uploads any debug APKs it finds under the detected root.
