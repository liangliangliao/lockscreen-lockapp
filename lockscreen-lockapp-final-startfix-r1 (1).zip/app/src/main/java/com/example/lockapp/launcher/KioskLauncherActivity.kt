package com.example.lockapp.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import com.example.lockapp.ui.LockActivity
import com.example.lockapp.data.LockConfigStore
import com.example.lockapp.data.LockStateStore

/**
 * HOME-only entry when the app is set as default launcher (Device Owner).
 * If not armed/required, we hand over to system HOME.
 */
class KioskLauncherActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
        route()
    }

    private fun route() {
        val armed = try { LockConfigStore.isArmed(this) } catch (_: Throwable) { false }
        val needUnlock = try { LockStateStore.isRequireUnlock(this) } catch (_: Throwable) { false }
        if (armed && needUnlock) {
            startActivity(Intent(this, LockActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            })
        } else {
            // Fallback to system home
            val home = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(home)
        }
        // Never stay here
        finish()
    }
}
