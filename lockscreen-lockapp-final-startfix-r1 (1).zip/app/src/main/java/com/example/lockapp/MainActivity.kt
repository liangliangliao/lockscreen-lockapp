package com.example.lockapp

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.lifecycle.ViewModelProvider
import com.example.lockapp.service.GatekeeperService
import com.example.lockapp.ui.MainScreen
import com.example.lockapp.ui.MainViewModel
import com.example.lockapp.ui.MainViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Ensure monitoring service is up; if already running this is a no-op.
        try {
            startForegroundService(Intent(this, GatekeeperService::class.java))
        } catch (t: Throwable) {
            // Don't crash UI if FGS boot fails on older devices
        }

        setContent {
            MaterialTheme {
                val app = application as LockScreenApp
                val viewModel = ViewModelProvider(
                    this@MainActivity,
                    MainViewModelFactory(app)
                ).get(MainViewModel::class.java)
                MainScreen(viewModel)
            }
        }
    }
}
