// RESTORED: minimal implementation to compile
package com.example.app.patchlock

import android.app.Service
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.lockapp.MainActivity
import com.example.lockapp.R
import com.example.lockapp.util.*

class LockGuardService : Service() {
    override fun onCreate() {
        super.onCreate()
        NotifyUtils.ensureChannel(this, ChanIDs.FOREGROUND, "Foreground", "Foreground service notifications")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val pi = PendingIntent.getActivity(
            this, 4001, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        val n = NotificationCompat.Builder(this, ChanIDs.FOREGROUND)
            .setSmallIcon(CompatIcons.smallIcon)
            .setContentTitle(getString(R.string.app_name))
            .setContentText("Guarding…")
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
        startForeground(99, n)
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
