// BUILD TAG: LOCKAPP-FSI-FIX-CI-REWRITE-20250907
package com.example.lockapp.ordered

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.lockapp.util.DebugLog
import com.example.lockapp.util.LockFsNotifier

class WakeOrderedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        DebugLog.i("WakeOrderedReceiver", "收到广播：${intent?.action}")
        try {
            LockFsNotifier.showFullScreen(context)
            DebugLog.i("WakeOrderedReceiver", "已触发全屏通知兜底")
        } catch (t: Throwable) {
            DebugLog.e("WakeOrderedReceiver", "触发全屏通知失败: ${t.message}", t)
        }
    }

    companion object {
        const val ACTION_WAKE_ORDERED = "com.example.lockapp.ACTION_WAKE_ORDERED"
    }
}
