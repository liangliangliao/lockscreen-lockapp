package com.example.lockapp.wake

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.lockapp.util.LockFsNotifier

class FsiAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        LockFsNotifier.showFullScreen(context, "Wake alarm")
    }
}
