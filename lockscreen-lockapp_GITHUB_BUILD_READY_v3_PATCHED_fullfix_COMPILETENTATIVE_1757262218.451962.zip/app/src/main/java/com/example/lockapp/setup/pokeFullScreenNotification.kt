// Fullscreen notification poke
package com.example.lockapp.setup

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.MainActivity
import com.example.lockapp.util.*

fun pokeFullScreenNotification(ctx: Context) {
    NotifyUtils.ensureChannel(ctx, ChanIDs.FULLSCREEN, "Fullscreen", "Full screen alerts")
    val fullPi = PendingIntent.getActivity(
        ctx, 7001, Intent(ctx, MainActivity::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
    )
    val n = NotificationCompat.Builder(ctx, ChanIDs.FULLSCREEN)
        .setSmallIcon(CompatIcons.smallIcon)
        .setContentTitle("测试全屏通知")
        .setContentText("这是一条用于唤起界面的测试通知")
        .setCategory(NotificationCompat.CATEGORY_ALARM)
        .setPriority(NotificationCompat.PRIORITY_MAX)
        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        .setAutoCancel(true)
        .setFullScreenIntent(fullPi, true)
        .build()
    NotificationManagerCompat.from(ctx).notify(7002, n)
}
