package com.example.lockapp

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.util.*

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Keep it layout-less to avoid missing layout resources
        setContentView(TextView(this).apply { text = "LockApp" })
        // Ensure channels exist (no-op pre-26)
        NotifyUtils.ensureChannel(this, ChanIDs.FOREGROUND, "Foreground", "Foreground service notifications")
        NotifyUtils.ensureChannel(this, ChanIDs.HEADS_UP, "Heads Up", "High priority alerts")
        NotifyUtils.ensureChannel(this, ChanIDs.FULLSCREEN, "Fullscreen", "Full screen alerts")

        // Optionally show a small heads-up when launched in debug builds
        showDebugHeadsUp()
    }

    private fun showDebugHeadsUp() {
        val pi = PendingIntent.getActivity(
            this, 1001, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        val n = NotificationCompat.Builder(this, ChanIDs.HEADS_UP)
            .setSmallIcon(CompatIcons.smallIcon)
            .setContentTitle(getString(R.string.app_name))
            .setContentText("Debug heads-up")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pi)
        // Use our shim for consistent API
        n.setFullScreenIntent(pi, true)
        NotificationManagerCompat.from(this).notify(2000, n.build())
    }
}
