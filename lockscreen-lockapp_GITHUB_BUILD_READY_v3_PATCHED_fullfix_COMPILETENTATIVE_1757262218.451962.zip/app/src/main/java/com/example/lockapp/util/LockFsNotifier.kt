package com.example.lockapp.util

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.MainActivity
import com.example.lockapp.R

object LockFsNotifier {

    fun showHeadsUp(ctx: Context, msg: String = "Heads up") {
        NotifyUtils.ensureChannel(ctx, ChanIDs.HEADS_UP, "Heads Up", "High priority alerts")
        val pi = PendingIntent.getActivity(
            ctx, 3001, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        val b = NotificationCompat.Builder(ctx, ChanIDs.HEADS_UP)
            .setSmallIcon(CompatIcons.smallIcon)
            .setContentTitle(ctx.getString(R.string.app_name))
            .setContentText(msg)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pi)
        NotificationManagerCompat.from(ctx).notify(3002, b.build())
    }

    fun showFullScreen(ctx: Context, msg: String = "Full screen alert") {
        NotifyUtils.ensureChannel(ctx, ChanIDs.FULLSCREEN, "Fullscreen", "Full screen alerts")
        val pi = PendingIntent.getActivity(
            ctx, 3003, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        val b = NotificationCompat.Builder(ctx, ChanIDs.FULLSCREEN)
            .setSmallIcon(CompatIcons.smallIcon)
            .setContentTitle(ctx.getString(R.string.app_name))
            .setContentText(msg)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pi)
        b.setFullScreenIntent(pi, true)
        NotificationManagerCompat.from(ctx).notify(3004, b.build())
    }
}
