package com.example.lockapp.util

/**
 * Central place for notification channel IDs so the constructor
 * NotificationCompat.Builder(context, channelId: String) is unambiguous.
 */
object ChanIDs {
    const val FOREGROUND = "lockapp.foreground"
    const val HEADS_UP = "lockapp.headsup"
    const val FULLSCREEN = "lockapp.fullscreen"
}
