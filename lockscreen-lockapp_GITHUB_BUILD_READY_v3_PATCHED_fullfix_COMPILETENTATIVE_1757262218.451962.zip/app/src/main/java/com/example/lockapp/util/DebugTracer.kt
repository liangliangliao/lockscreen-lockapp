package com.example.lockapp.util

import android.util.Log
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object DebugTracer {
    private const val TAG = "LockApp"

    fun d(msg: String) = Log.d(TAG, msg)
    fun e(msg: String, tr: Throwable? = null) = Log.e(TAG, msg, tr)

    fun headsUp(ctx: Context, msg: String) {
        NotifyUtils.ensureChannel(ctx, ChanIDs.HEADS_UP, "Heads Up", "High priority alerts")
        val b = NotificationCompat.Builder(ctx, ChanIDs.HEADS_UP)
            .setSmallIcon(CompatIcons.smallIcon)
            .setContentTitle("Debug")
            .setContentText(msg)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
        NotificationManagerCompat.from(ctx).notify(6001, b.build())
    }
}
