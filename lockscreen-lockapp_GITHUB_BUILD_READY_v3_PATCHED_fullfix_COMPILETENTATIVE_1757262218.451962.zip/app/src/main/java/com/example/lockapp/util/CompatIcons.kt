package com.example.lockapp.util

import com.example.lockapp.R

object CompatIcons {
    // Prefer mipmap ic_launcher; fall back to Android lock icon
    val smallIcon: Int = try { R.mipmap.ic_launcher } catch (_: Throwable) { android.R.drawable.ic_lock_lock }
    val LAUNCHER_ICON: Int get() = smallIcon
}
