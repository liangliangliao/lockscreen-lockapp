package com.example.lockapp.service

import android.app.*
import android.content.*
import android.os.Build
import android.os.IBinder
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import com.example.lockapp.LauncherActivity
import com.example.lockapp.data.LockStateStore

/**
 * Foreground guard for app-driven lock workflow.
 * Android 14+ requires BOTH: a specific FGS type in manifest AND the matching specialized permission.
 * We also use the 3-arg startForeground() with type on API >= 29 to be explicit.
 */
class GatekeeperService : Service() {

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> LockStateStore.setLocked(context, true)
                Intent.ACTION_SCREEN_ON  -> showGate(context)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        // register screen on/off
        registerReceiver(screenReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        })
        // foreground right away
        startForegroundWithNotification()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(screenReceiver) } catch (_: Throwable) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startForegroundWithNotification() {
        val channelId = ensureChannel(this)
        val launchIntent = Intent(this, LauncherActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("forceLock", true)
        }
        val pi = PendingIntent.getActivity(
            this, 0, launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("Lock screen guard")
            .setContentText("Running")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setContentIntent(pi)
            .build()

        // Android 14+ (targetSdk 34): need explicit type that matches manifest + permission.
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(101, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(101, notification)
        }
    }

    private fun showGate(context: Context) {
        val it = Intent(context, LauncherActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("forceLock", true)
        }
        try {
            context.startActivity(it)
        } catch (_: Throwable) {
            val chId = "gatekeeper_alert"
            val nm = context.getSystemService(NotificationManager::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm.getNotificationChannel(chId) == null) {
                val ch = NotificationChannel(chId, "Gate prompt", NotificationManager.IMPORTANCE_HIGH).apply {
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
                nm.createNotificationChannel(ch)
            }
            val pi = PendingIntent.getActivity(
                context, 1, it,
                PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            )
            val n = NotificationCompat.Builder(context, chId)
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentTitle("需要解锁")
                .setContentText("请验证密码继续")
                .setCategory(Notification.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setFullScreenIntent(pi, true)
                .build()
            nm.notify(202, n)
        }
    }

    companion object {
        private const val FG_CHANNEL_ID = "gatekeeper_foreground"
        private const val FG_CHANNEL_NAME = "Gatekeeper"
        fun ensureChannel(ctx: Context): String {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = ctx.getSystemService(NotificationManager::class.java)
                if (nm.getNotificationChannel(FG_CHANNEL_ID) == null) {
                    val ch = NotificationChannel(
                        FG_CHANNEL_ID, FG_CHANNEL_NAME, NotificationManager.IMPORTANCE_MIN
                    ).apply {
                        setShowBadge(false)
                        lockscreenVisibility = Notification.VISIBILITY_SECRET
                    }
                    nm.createNotificationChannel(ch)
                }
            }
            return FG_CHANNEL_ID
        }
    }
}
