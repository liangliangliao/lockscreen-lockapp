FGS Hotfix v34 (Android 14 MissingForegroundServiceTypeException)

WHAT CHANGED
- GatekeeperService now calls the 3-arg startForeground(..., FOREGROUND_SERVICE_TYPE_DATA_SYNC) on API >= 29.
- You MUST also declare the matching foreground service type and permission in AndroidManifest.xml.

HOW TO APPLY
1) Replace file:
   app/src/main/java/com/example/lockapp/service/GatekeeperService.kt
   with the one in this hotfix pack.

2) Edit app/src/main/AndroidManifest.xml:
   Inside <manifest> add:
       <uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC"/>
       <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
   Inside your <application> block, on GatekeeperService declaration add:
       android:foregroundServiceType="dataSync"

   A ready-to-copy snippet is provided in MANIFEST_SNIPPET.xml.

WHY THIS FIX?
- On Android 14 (targetSdk=34), starting any Foreground Service requires specifying a service TYPE
  both in Manifest (android:foregroundServiceType) and at runtime (or be inferred) and also holding
  the specialized permission (FOREGROUND_SERVICE_DATA_SYNC here). Without it, the system throws:
  MissingForegroundServiceTypeException: Starting FGS without a type.

EXTRA NOTES
- If your app doesn't need notifications, you can keep POST_NOTIFICATIONS, it's benign. On Android 13+
  users may need to grant it to avoid notification being hidden (which could cause the FGS to be stopped
  by OEMs).

- If your logic later uses other capabilities (location/camera/connectedDevice etc.), update both the
  manifest service type and the permission to match.

Rebuild:
  ./gradlew :app:assembleDebug
