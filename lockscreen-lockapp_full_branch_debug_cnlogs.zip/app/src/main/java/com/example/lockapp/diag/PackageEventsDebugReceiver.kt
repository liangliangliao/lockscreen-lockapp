package com.example.lockapp.diag

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.lockapp.util.LockFsNotifier
import com.example.lockapp.util.DebugLog

class PackageEventsDebugReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val pkg = intent.data?.schemeSpecificPart ?: "(unknown)"
        try { LockFsNotifier.showDebugHeadsUp(context, "系统包事件", "$action -> $pkg"); DebugLog.i("PackageEvents", "系统包事件："+action+" -> "+pkg) } catch (_: Throwable) {}
    }
}