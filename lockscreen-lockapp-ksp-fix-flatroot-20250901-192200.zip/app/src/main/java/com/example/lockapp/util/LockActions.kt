package com.example.lockapp.util
import android.content.Context
import android.content.Intent
import com.example.lockapp.data.ActiveLockStore
import com.example.lockapp.data.LockConfigStore
import com.example.lockapp.service.GatekeeperService

object LockActions {
    fun afterSetLock(context: Context, imageUri: String?, password: String?) {
        // 保存用户选择（允许无密码预览），但未设置密码时不激活
        ActiveLockStore.set(context, imageUri, password)
        if (password.isNullOrEmpty()) {
            android.widget.Toast.makeText(context, "请先设置密码，未激活锁屏", android.widget.Toast.LENGTH_SHORT).show()
            LockConfigStore.setArmed(context, false)
            return
        }
        // 设置了密码：激活并启动守护前台服务
        LockConfigStore.setArmed(context, true)
        try {
            context.startForegroundService(Intent(context, GatekeeperService::class.java))
        } catch (_: Throwable) { }
    }
}
