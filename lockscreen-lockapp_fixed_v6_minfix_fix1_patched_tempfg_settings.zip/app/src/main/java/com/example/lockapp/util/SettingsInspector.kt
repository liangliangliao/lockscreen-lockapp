package com.example.lockapp.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.NotificationManager.IMPORTANCE_HIGH
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast

/**
 * 极小的设置引导工具：只在三星机型上轻提示并跳转到系统设置页面；
 * 不引入新权限，不改变主流程。
 */
object SettingsInspector {

    // 你工程里 FSI/保活用到的通道ID（若有多个可再传入或复制一份）
    private const val CHANNEL_LOCK_KEEPALIVE = "lock_keepalive"
    private const val CHANNEL_LOCK_TEMP = "lock_temp_keepalive"

    fun nudgeIfSamsung(ctx: Context) {
        val manu = Build.MANUFACTURER.lowercase()
        if (!manu.contains("samsung")) return

        // 1) 通知权限 & 通道重要级
        if (Build.VERSION.SDK_INT >= 33) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (!nm.areNotificationsEnabled()) {
                Toast.makeText(ctx, "请开启“通知权限”，保证解锁提示可显示", Toast.LENGTH_LONG).show()
                try {
                    ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                        putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    })
                } catch (_: Throwable) {}
                return
            }
        }
        ensureChannelHigh(ctx, CHANNEL_LOCK_KEEPALIVE)
        ensureChannelHigh(ctx, CHANNEL_LOCK_TEMP)

        // 2) 电池优化白名单
        val pm = ctx.getSystemService(PowerManager::class.java)
        if (pm != null && !pm.isIgnoringBatteryOptimizations(ctx.packageName)) {
            Toast.makeText(ctx, "建议将应用设为“电池不限制”，避免息屏后被休眠", Toast.LENGTH_LONG).show()
            try {
                ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:${ctx.packageName}")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            } catch (_: Throwable) {
                // 退而求其次，打开总列表
                try {
                    ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    })
                } catch (_: Throwable) {}
            }
            return
        }

        // 3) 锁屏通知显示开关（提示用户检查）
        Toast.makeText(ctx, "若仍不弹，请在“锁定屏幕 → 通知/显示”里允许在锁屏显示通知", Toast.LENGTH_SHORT).show()
    }

    private fun ensureChannelHigh(ctx: Context, id: String) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val ch: NotificationChannel? = nm.getNotificationChannel(id)
        if (ch != null && ch.importance < IMPORTANCE_HIGH) {
            // 提示并跳转到通道设置页面
            try {
                Toast.makeText(ctx, "请将通知通道提升为“高优先级/允许打扰”", Toast.LENGTH_LONG).show()
                ctx.startActivity(Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).apply {
                    putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                    putExtra(Settings.EXTRA_CHANNEL_ID, id)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            } catch (_: Throwable) {}
        }
    }
}
