package com.example.lockapp.service
import com.example.lockapp.LockScreenActivity

import android.app.*
import android.content.*
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import com.example.lockapp.LauncherActivity
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.util.LockCoordinator
import com.example.lockapp.util.LockVisibilityTracker
import android.os.Handler
import android.os.Looper

class GatekeeperService : Service() {

    // 临时前台：在息屏后短时间内保持存活，提高首亮可靠性；到时自动降回后台
    private var tempFgHandler: Handler? = null
    private fun ensureTempForegroundFor(ms: Long) {
        if (Build.VERSION.SDK_INT < 26) return
        try {
            val nm = getSystemService(NotificationManager::class.java)
            val chId = "lock_temp_keepalive"
            if (nm.getNotificationChannel(chId) == null) {
                val ch = NotificationChannel(chId, "Lock Temp Keepalive", NotificationManager.IMPORTANCE_MIN).apply {
                    description = "Keeps lock service briefly after screen off"
                    setShowBadge(false)
                    enableLights(false)
                    enableVibration(false)
                    lockscreenVisibility = Notification.VISIBILITY_SECRET
                }
                nm.createNotificationChannel(ch)
            }
            val pi = PendingIntent.getActivity(
                this, 2101,
                Intent(this, LockScreenActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0) or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(this, "lock_temp_keepalive")
                .setSmallIcon(android.R.drawable.stat_sys_warning)
                .setContentTitle("Lock active briefly")
                .setContentText("Improving first wake reliability")
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .setContentIntent(pi)
                .build()
            try { startForeground(1903, n) } catch (_: Throwable) {}
            if (tempFgHandler == null) tempFgHandler = Handler(Looper.getMainLooper())
            tempFgHandler?.removeCallbacksAndMessages(null)
            tempFgHandler?.postDelayed({
                try { stopForeground(true) } catch (_: Throwable) {}
            }, ms.coerceAtLeast(1000))
        } catch (_: Throwable) { }
    }


    private fun attemptShow(ctx: Context) {
        LockCoordinator.markLocked(ctx)
        val i = Intent(ctx, LockScreenActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)

        if (LockCoordinator.isLocked(ctx)
            && !LockVisibilityTracker.visible
            && LockCoordinator.requestShowOnce()
            && LockCoordinator.tryEnterShowing()
        ) {
            try { ctx.startActivity(i) } catch (_: Throwable) {}
        }

        Handler(Looper.getMainLooper()).postDelayed({
            if (!LockVisibilityTracker.visible && LockCoordinator.isLocked(ctx)) {
                try { com.example.lockapp.util.LockFsNotifier.showFullScreen(ctx) } catch (_: Throwable) {}
            }
        }, 120)
    }


    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> LockCoordinator.markLocked(context)
                Intent.ACTION_SCREEN_ON -> {/* UI launch disabled (r6) */}
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        // register screen on/off
        registerReceiver(screenReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        })
        // foreground right away
        startForegroundWithNotification()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(screenReceiver) } catch (_: Throwable) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startForegroundWithNotification() {
        val channelId = ensureChannel(this)
        val launchIntent = Intent(this, LauncherActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("forceLock", true)
        }
        val pi = PendingIntent.getActivity(
            this, 0, launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_lock) // always valid
            .setContentTitle("Lock screen guard")
            .setContentText("Running")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setContentIntent(pi)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(101, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            @Suppress("DEPRECATION")
            startForeground(101, notification)
        }
    }

    private fun showGate(context: Context) { /* disabled */ return
        val it = Intent(context, LauncherActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("forceLock", true)
        }
        try {
            context.startActivity(it)
        } catch (_: Throwable) {
            val chId = "gatekeeper_alert_v2"
            val nm = context.getSystemService(NotificationManager::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm.getNotificationChannel(chId) == null) {
                val ch = NotificationChannel(chId, "Gate prompt", NotificationManager.IMPORTANCE_HIGH).apply {
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            setBypassDnd(true)
                }
                nm.createNotificationChannel(ch)
            }
            val pi = PendingIntent.getActivity(
                context, 1, it,
                PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            )
            val n = NotificationCompat.Builder(context, chId)
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentTitle("需要解锁")
                .setContentText("请验证密码继续")
                .setCategory(Notification.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_MAX)
            .setDefaults(Notification.DEFAULT_ALL)
                .setFullScreenIntent(pi, true)
                .build()
            nm.notify(202, n)
        }
    }

    companion object {
        private const val FG_CHANNEL_ID = "gatekeeper_foreground"
        private const val FG_CHANNEL_NAME = "Gatekeeper"
        fun ensureChannel(ctx: Context): String {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = ctx.getSystemService(NotificationManager::class.java)
                if (nm.getNotificationChannel(FG_CHANNEL_ID) == null) {
                    val ch = NotificationChannel(
                        FG_CHANNEL_ID, FG_CHANNEL_NAME, NotificationManager.IMPORTANCE_MIN
                    ).apply {
                        setShowBadge(false)
                        lockscreenVisibility = Notification.VISIBILITY_SECRET
                    }
                    nm.createNotificationChannel(ch)
                }
            }
            return FG_CHANNEL_ID
        }
    }
}
