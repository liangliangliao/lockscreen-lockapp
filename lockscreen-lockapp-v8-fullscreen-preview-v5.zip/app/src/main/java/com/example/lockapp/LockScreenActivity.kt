package com.example.lockapp

import android.app.KeyguardManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat



class LockScreenActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setShowWhenLocked(true)
        setTurnScreenOn(true)

        setContent {
            com.example.lockapp.ui.LockScreen(
                onUnlock = {
                    try {
                        val km = getSystemService(KeyguardManager::class.java)
                        km?.requestDismissKeyguard(this, null)
                    } catch (_: Throwable) {}
                    finish()
                }
            )
        }
    }
}