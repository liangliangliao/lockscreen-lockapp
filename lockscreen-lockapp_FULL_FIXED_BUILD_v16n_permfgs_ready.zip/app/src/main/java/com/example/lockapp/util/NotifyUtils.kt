package com.example.lockapp.util

import android.app.NotificationManager
import android.content.Context
import android.os.Build

object NotifyUtils {
    /**
     * 兼容检查“通知是否可用”：
     * - Android N(API 24)+：使用框架 NotificationManager.areNotificationsEnabled()
     * - 更低版本：默认返回 true（系统无开关）
     * - 捕获异常时也返回 true，避免误判
     */
    @JvmStatic
    fun areNotificationsEnabled(context: Context): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 24) {
                val nm = context.getSystemService(NotificationManager::class.java)
                nm.areNotificationsEnabled()
            } else {
                true
            }
        } catch (_: Throwable) {
            true
        }
    }
}