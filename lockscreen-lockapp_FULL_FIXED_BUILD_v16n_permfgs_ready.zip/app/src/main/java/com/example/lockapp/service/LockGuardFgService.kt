package com.example.lockapp.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.lockapp.R
import com.example.lockapp.util.Toaster
import com.example.lockapp.util.LockFsNotifier

class LockGuardFgService : Service() {

    companion object {
        private const val CH_ID = "lock_guard_fg"
        private const val CH_NAME = "锁屏保护（前台服务）"
        private const val NOTI_ID = 41001

        fun start(ctx: Context) {
            val i = Intent(ctx, LockGuardFgService::class.java)
            ContextCompat.startForegroundService(ctx, i)
        }
        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, LockGuardFgService::class.java))
        }
    }

    private var screenReceiver: BroadcastReceiver? = null

    override fun onCreate() {
        super.onCreate()
        ensureChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notif: Notification = NotificationCompat.Builder(this, CH_ID)
            .setSmallIcon(R.drawable.ic_lock)
            .setContentTitle("锁屏保护已开启（常驻）")
            .setContentText("正在监听亮屏/解锁以触发伪锁屏")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        startForeground(NOTI_ID, notif)
        registerDynamicReceivers()
        Toaster.show5s(this, "常驻服务：动态亮屏接收器已注册")
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterDynamicReceivers()
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) {}
        Toaster.show5s(this, "常驻服务：动态亮屏接收器已注销")
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onTaskRemoved(rootIntent: Intent?) {
        try { start(this) } catch (_: Throwable) {}
        super.onTaskRemoved(rootIntent)
    }

    private fun registerDynamicReceivers() {
        if (screenReceiver != null) return
        screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                when (intent.action) {
                    Intent.ACTION_SCREEN_ON,
                    Intent.ACTION_USER_PRESENT -> {
                        Toaster.show5s(context, "动态广播命中：准备发送FSI")
                        LockFsNotifier.showFullScreen(context)
                    }
                    Intent.ACTION_SCREEN_OFF -> {
                        Toaster.show5s(context, "动态广播：SCREEN_OFF")
                    }
                    Intent.ACTION_DREAMING_STOPPED -> {
                        Toaster.show5s(context, "动态广播：DREAMING_STOPPED→准备发送FSI")
                        LockFsNotifier.showFullScreen(context)
                    }
                }
            }
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_DREAMING_STOPPED)
            priority = IntentFilter.SYSTEM_HIGH_PRIORITY
        }
        registerReceiver(screenReceiver, f)
    }

    private fun unregisterDynamicReceivers() {
        screenReceiver?.let {
            try { unregisterReceiver(it) } catch (_: Throwable) {}
            screenReceiver = null
        }
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CH_ID) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(
                        CH_ID, CH_NAME, NotificationManager.IMPORTANCE_LOW
                    )
                )
            }
        }
    }
}