package com.example.lockapp.overlay
import com.example.lockapp.util.Toaster

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import android.content.Context
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.util.DebugTracer

class OverlayLockService : Service() {
    private var wm: WindowManager? = null
    private var container: FrameLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        
        DebugTracer.w("OverlayLockService", "OverlayLockService onCreate")
        try { DebugTracer.notify(this, "Trace", "OverlayLockService onCreate") } catch (t: Throwable) { }
wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        container = FrameLayout(this).apply {
            setBackgroundColor(0xB3000000.toInt())
            isClickable = true
            isFocusable = true
            val btn = Button(context).apply {
                text = "打开解锁界面"
                textSize = 20f
                setOnClickListener {
                    val i = Intent().apply { setClassName(context, "com.example.lockapp.launcher.TransparentTrampolineActivity"); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP); action = "com.example.lockapp.SHOW_LOCK_FROM_FSI"; putExtra("from_fsi", true) }.apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    }
                    Toaster.show5s(this@OverlayLockService, "Overlay：通过跳板拉起伪锁屏（FSI路径）"); startActivity(i)
                    stopSelf()
                }
            }
            val tv = TextView(context).apply {
                text = "需要解锁"
                textSize = 22f
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(32, 48, 32, 24)
            }
            addView(tv, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL })
            addView(btn, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply { gravity = Gravity.CENTER })
            setOnClickListener {
                val i = Intent().apply { setClassName(context, "com.example.lockapp.launcher.TransparentTrampolineActivity"); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP); action = "com.example.lockapp.SHOW_LOCK_FROM_FSI"; putExtra("from_fsi", true) }.apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                Toaster.show5s(this@OverlayLockService, "Overlay：通过跳板拉起伪锁屏（FSI路径）"); startActivity(i)
                stopSelf()
            }
        }

        wm?.addView(container, lp)
    }

    override fun onDestroy() {
        container?.let { v -> wm?.removeViewImmediate(v) }
        container = null
        wm = null
        super.onDestroy()
    }

    companion object {
        fun show(context: Context) = context.startService(Intent(context, OverlayLockService::class.java))
        fun hide(context: Context) = context.stopService(Intent(context, OverlayLockService::class.java))
    }
}