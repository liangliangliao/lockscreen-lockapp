package com.example.lockapp.setup

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

object SetupNavigator {

    fun appDetails(ctx: Context) =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:${ctx.packageName}")
        }

    fun notificationSettings(ctx: Context): Intent =
        if (Build.VERSION.SDK_INT >= 26) {
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
            }
        } else {
            Intent("android.settings.APP_NOTIFICATION_SETTINGS").apply {
                putExtra("app_package", ctx.packageName)
                putExtra("app_uid", ctx.applicationInfo.uid)
            }
        }

    /** Show the global list screen for battery optimizations (so user can find us) */
    fun batteryOptimizationList(): Intent =
        Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)

    /** Request exemption for this app directly */
    fun requestIgnoreBatteryOptimizations(ctx: Context) =
        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = Uri.parse("package:${ctx.packageName}")
        }

    /** Open the overlay permission page for just this app with robust fallbacks. */
    fun overlayPermission(ctx: Context): Intent {
        return Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
    }

    /** Vendor-specific overlay pages as last resort (best effort). */
    fun vendorOverlayFallbackIntents(ctx: Context): List<Intent> {
        val pkg = ctx.packageName
        val list = mutableListOf<Intent>()
        // MIUI
        list += Intent("miui.intent.action.APP_PERM_EDITOR").apply {
            setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
            putExtra("extra_pkgname", pkg)
        }
        list += Intent("miui.intent.action.APP_PERM_EDITOR").apply {
            setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.AppPermissionsEditorActivity")
            putExtra("extra_pkgname", pkg)
        }
        // Oppo
        list += Intent().apply {
            setClassName("com.coloros.safecenter", "com.coloros.safecenter.permission.floatwindow.FloatWindowListActivity")
        }
        // Vivo
        list += Intent().apply {
            setClassName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.FloatWindowManager")
        }
        return list
    }
}
