package com.example.lockapp.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.IBinder
import android.view.Display
import androidx.core.app.NotificationCompat
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.R

/**
 * Foreground gatekeeper service that ensures lock UI is shown on screen-on.
 * Uses both a BroadcastReceiver and a DisplayManager.DisplayListener for reliability.
 */
class GatekeeperService : Service() {

    private val channelId = "gk_foreground"
    private val alertChannelId = "gk_alerts"

    private var screenReceiver: BroadcastReceiver? = null
    private var displayListener: DisplayManager.DisplayListener? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        registerScreenOnReceiver()
        registerDisplayListener()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildServiceNotification()
        try { startForeground(1337, notification) } catch (_: Throwable) { /* ignore */ }
        return START_STICKY
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(screenReceiver)
        } catch (_: Throwable) {}
        screenReceiver = null

        try {
            val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            displayListener?.let { dm.unregisterDisplayListener(it) }
        } catch (_: Throwable) {}
        displayListener = null

        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun registerScreenOnReceiver() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_SCREEN_ON,
                    Intent.ACTION_USER_PRESENT -> showLockNow()
                }
            }
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(screenReceiver, filter)
        }
    }

    private fun registerDisplayListener() {
        val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        displayListener = object : DisplayManager.DisplayListener {
            override fun onDisplayChanged(displayId: Int) {
                val d = dm.getDisplay(displayId) ?: return
                if (d.displayId == Display.DEFAULT_DISPLAY && d.state == Display.STATE_ON) {
                    showLockNow()
                }
            }
            override fun onDisplayAdded(displayId: Int) {}
            override fun onDisplayRemoved(displayId: Int) {}
        }
        dm.registerDisplayListener(displayListener, null)
    }

    private fun buildServiceNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this,
            100,
            Intent(this, LockScreenActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_lock_patch)
            .setContentTitle(getString(R.string.app_name))
            .setContentText("守护服务运行中")
            .setOngoing(true)
            .setContentIntent(pi)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun buildAlertNotification(): Notification {
        val fullPi = PendingIntent.getActivity(
            this,
            101,
            Intent(this, LockScreenActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        return NotificationCompat.Builder(this, alertChannelId)
            .setSmallIcon(R.drawable.ic_lock_patch)
            .setContentTitle("正在唤起解锁界面")
            .setContentText("点按以继续")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(Notification.CATEGORY_CALL)
            .setFullScreenIntent(fullPi, true)
            .setAutoCancel(true)
            .build()
    }

    private fun showLockNow() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm.getNotificationChannel(alertChannelId) == null) {
            createChannels()
        }
        val n = buildAlertNotification()
        try { nm.notify(10086, n) } catch (_: Throwable) { /* ignore SecurityException on 13+ if notifications not granted */ }
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val fg = NotificationChannel(channelId, "Gatekeeper Service", NotificationManager.IMPORTANCE_MIN)
            nm.createNotificationChannel(fg)
            val alerts = NotificationChannel(alertChannelId, "Lock Alerts", NotificationManager.IMPORTANCE_HIGH)
            alerts.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(alerts)
        }
    }
}
