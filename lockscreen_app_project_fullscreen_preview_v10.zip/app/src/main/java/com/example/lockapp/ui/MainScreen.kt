package com.example.lockapp.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.lockapp.data.AppDatabase
import androidx.room.Room

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    val context = LocalContext.current

    val dao = remember {
        Room.databaseBuilder(context, AppDatabase::class.java, "lockapp.db")
            .allowMainThreadQueries()
            .build()
            .imagePasswordDao()
    }

    var items by remember { mutableStateOf(dao.getAllOnce()) }

    var previewUri by remember { mutableStateOf<Uri?>(null) }
    var isPreviewVisible by remember { mutableStateOf(false) }

    val pickMultiple = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(maxItems = 50)
    ) { uris ->
        if (!uris.isNullOrEmpty()) {
            val base = items?.size ?: 0
            uris.take(50).forEachIndexed { idx, uri ->
                dao.upsert(
                    com.example.lockapp.data.ImagePassword(
                        id = 0,
                        uri = uri.toString(),
                        password = "",
                        orderIndex = base + idx
                    )
                )
            }
            items = dao.getAllOnce()
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("锁屏图片管理") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                pickMultiple.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            }) { Text("+") }
        }
    ) { padding ->
        val list = items ?: emptyList()
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("点击右下角 + 添加图片")
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(list) { it ->
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(Uri.parse(it.uri))
                            .build(),
                        contentDescription = null,
                        modifier = Modifier
                            .aspectRatio(1f)
                            .fillMaxWidth()
                            .clickable {
                                previewUri = Uri.parse(it.uri)
                                isPreviewVisible = true
                            },
                        contentScale = ContentScale.Crop
                    )
                }
            }
        }
    }

    if (isPreviewVisible && previewUri != null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.98f)),
            contentAlignment = Alignment.Center
        ) {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(previewUri)
                    .crossfade(true)
                    .build(),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .align(Alignment.TopStart),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = { isPreviewVisible = false; previewUri = null }) {
                    Text("返回", color = Color.White)
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .align(Alignment.BottomCenter),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "预览（全屏适配显示）",
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Button(onClick = { isPreviewVisible = false; previewUri = null }) {
                    Text("完成")
                }
            }
        }
    }
}
