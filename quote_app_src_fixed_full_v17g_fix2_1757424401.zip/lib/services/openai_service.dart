import '../data/dao.dart';
import 'notification_service.dart';

class OpenAIService {
  static Future<void> fetchAndStoreQuote() async {
    await QuoteDao().insertQuote('（占位）保持好奇，持续迭代。', author: '系统', source: '后台任务');
    await NotificationOrchestrator.checkAndNotifyNewQuotes();
}
}
