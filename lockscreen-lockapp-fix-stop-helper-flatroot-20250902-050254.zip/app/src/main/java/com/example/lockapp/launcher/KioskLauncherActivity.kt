package com.example.lockapp.launcher

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import androidx.activity.ComponentActivity
import com.example.lockapp.device.LockAdminReceiver
import com.example.lockapp.data.LockConfigStore
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.ui.LockActivity

class KioskLauncherActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        maybeSetupDeviceOwnerDefaults()
    }

    override fun onResume() {
        super.onResume()
        route()
    }

    private fun route() {
        val armed = LockConfigStore.isArmed(this)
        val locked = LockStateStore.isLocked(this)
        val target = if (armed && locked) LockActivity::class.java else null
        if (target != null) {
            startActivity(Intent(this, target).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        } else {
            launchOriginalLauncher()
        }
        finish()
    }

    private fun maybeSetupDeviceOwnerDefaults() {
        val dpm = getSystemService(DevicePolicyManager::class.java) ?: return
        if (!dpm.isDeviceOwnerApp(packageName)) return
        val admin = ComponentName(this, LockAdminReceiver::class.java)
        // 1) LockTask 白名单
        try { dpm.setLockTaskPackages(admin, arrayOf(packageName)) } catch (_: Throwable) {}
        // 2) 设为持久默认桌面
        try {
            val filter = IntentFilter(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                addCategory(Intent.CATEGORY_DEFAULT)
            }
            dpm.addPersistentPreferredActivity(admin, filter, ComponentName(this, KioskLauncherActivity::class.java))
        } catch (_: Throwable) {}
    }


private fun launchOriginalLauncher() {
    // 找到原有的 LAUNCHER Activity（排除自己），用于非锁定时作为入口
    val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage(packageName)
    val list = packageManager.queryIntentActivities(main, 0)
    val original = list.firstOrNull { it.activityInfo.name != KioskLauncherActivity::class.java.name }
    val comp = original?.activityInfo?.let { ComponentName(it.packageName, it.name) }
    if (comp != null) {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(comp)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
    } else {
        // 兜底：如果没有找到原启动器，则回到 LockActivity（不会抛异常）
        startActivity(Intent(this, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
    }
}
}
