package com.example.lockapp.ui

import android.net.Uri
import android.widget.ImageView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.lockapp.LockScreenApp
import com.example.lockapp.data.ImagePassword
import com.example.lockapp.data.ActiveLockStore

@Composable
fun LiveLockScreen(
    onUnlock: () -> Unit,
    onEmergency: () -> Unit = {},
    viewModel: LockScreenViewModel
) {
    val ctx = LocalContext.current
    val entry: ImagePassword? by viewModel.currentEntry.collectAsState()
    val unlockResult: Boolean? by viewModel.unlockResult.collectAsState()

    // Keep ActiveLockStore in sync so dialog lock (if used) matches
    LaunchedEffect(entry?.uri) {
        entry?.let { ActiveLockStore.set(ctx, it.uri, it.password) }
    }

    // When password verified as correct, call onUnlock
    LaunchedEffect(unlockResult) {
        if (unlockResult == true) onUnlock()
    }

    var input by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var showInput by remember { mutableStateOf(true) }

    Box(modifier = Modifier.fillMaxSize()) {
        // Background image via AndroidView to avoid extra image libraries
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ImageView(it).apply { scaleType = ImageView.ScaleType.CENTER_CROP } },
            update = { iv ->
                entry?.uri?.let { runCatching { iv.setImageURI(Uri.parse(it)) } }
            }
        )

        if (showInput) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
                    .align(Alignment.Center)
                    .background(Color(0x66000000))
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "请输入密码解锁",
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(Modifier.height(12.dp))
                TextField(
                    value = input,
                    onValueChange = { input = it; error = null },
                    label = { Text("密码") },
                    singleLine = true,
                    keyboardOptions = androidx.compose.ui.text.input.androidx.compose.ui.text.input.KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Done
                    ),
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = {
                    val ok = input.trim() == (entry?.password?.trim() ?: "")
                    if (ok) {
                        viewModel.verifyPassword(input.trim())
                    } else {
                        error = "密码错误！"
                    }
                }) {
                    Text("解锁", color = Color.White)
                }
                error?.let { msg ->
                    Spacer(Modifier.height(8.dp))
                    Text(msg, color = Color.Red)
                }
            }
        }

        BackHandler(enabled = showInput) { showInput = false }
    }
}