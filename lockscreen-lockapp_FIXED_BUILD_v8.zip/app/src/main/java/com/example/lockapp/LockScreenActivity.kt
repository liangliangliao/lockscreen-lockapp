// BUILD TAG: LOCKAPP-FIX-LOCKSCREEN-20250907
package com.example.lockapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import com.example.lockapp.util.DebugLog

class LockScreenActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                or android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        DebugLog.w("LockScreen", "LockScreenActivity launched")
    }
}
