package com.example.lockapp.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.lockapp.data.LockConfigStore
import com.example.lockapp.data.LockStateStore

/**
 * When the user unlocks the system keyguard (USER_PRESENT), mark our app as requiring its own
 * unlock on next foreground if armed. This combines with the HOME launcher check to actually
 * show the password screen even if another app was open before sleep.
 */
class UserPresentReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (LockConfigStore.isArmed(context)) {
            LockStateStore.setRequireUnlock(context, true)
        }
    }
}
