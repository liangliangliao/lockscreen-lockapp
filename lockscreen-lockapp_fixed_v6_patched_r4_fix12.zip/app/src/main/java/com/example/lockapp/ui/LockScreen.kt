package com.example.lockapp.ui

import androidx.compose.runtime.Composable

@Composable
fun LockScreen(onUnlock: () -> Unit = {}) {
    // Deprecated wrapper; not used. Kept to satisfy references if any future use appears.
}