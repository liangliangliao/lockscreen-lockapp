package com.example.lockapp

import android.app.KeyguardManager
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.lockapp.ui.LiveLockScreen
import com.example.lockapp.util.LockVisibilityTracker

import com.example.lockapp.util.LockCoordinator
import androidx.lifecycle.ViewModelProvider
import com.example.lockapp.ui.LockScreenViewModel
import com.example.lockapp.ui.LockScreenViewModelFactory
import com.example.lockapp.LockScreenApp
class LockScreenActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val vm = ViewModelProvider(this, LockScreenViewModelFactory(application as LockScreenApp)).get(LockScreenViewModel::class.java)
// Ensure we can appear above the keyguard and wake the screen
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        // Ask system to dismiss keyguard when possible
        getSystemService(KeyguardManager::class.java)
            ?.requestDismissKeyguard(this, null)

        setContent {
            LiveLockScreen(viewModel = vm, onEmergency = { /* no-op or start emergency activity if you have one */ },
                onUnlock = { LockCoordinator.markUnlocked(this); finish() }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        LockVisibilityTracker.visible = true
    }

    override fun onPause() {
        super.onPause()
        LockVisibilityTracker.visible = false
    }
}