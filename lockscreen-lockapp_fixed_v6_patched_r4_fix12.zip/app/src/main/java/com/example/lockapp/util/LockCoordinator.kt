package com.example.lockapp.util

import android.content.Context
import android.os.SystemClock
import com.example.lockapp.data.LockStateStore
import com.example.app.patchlock.AppLockState

/**
 * Single coordination point for lock state + debouncing across all entry points.
 * Ensures that LockDialog / LockScreenActivity / services/receivers share the same state.
 */
object LockCoordinator {
    @Volatile private var lastShownAt: Long = 0L
    private const val DEBOUNCE_MS = 2000L

    fun isLocked(context: Context): Boolean = LockStateStore.isLocked(context)

    fun markLocked(context: Context) {
        LockStateStore.setLocked(context, true)
        AppLockState.markLocked()
    }

    fun markUnlocked(context: Context) {
        LockStateStore.setLocked(context, false)
        AppLockState.markUnlocked()
    }

    /** Allow showing the lock UI only once within a debounce window. */
    @Synchronized
    fun requestShowOnce(): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (now - lastShownAt < DEBOUNCE_MS) return false
        lastShownAt = now
        return true
    }
}
