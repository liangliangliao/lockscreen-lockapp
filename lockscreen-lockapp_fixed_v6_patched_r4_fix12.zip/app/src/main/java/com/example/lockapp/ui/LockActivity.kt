package com.example.lockapp.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import androidx.compose.material3.MaterialTheme
import androidx.lifecycle.ViewModelProvider
import com.example.lockapp.ui.LockScreenViewModel
import com.example.lockapp.ui.LockScreenViewModelFactory
import com.example.lockapp.LockScreenApp

class LockActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val vm = ViewModelProvider(this, LockScreenViewModelFactory(application as LockScreenApp)).get(LockScreenViewModel::class.java)
// edge-to-edge to let preview全屏
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            MaterialTheme {
                LiveLockScreen(viewModel = vm, onUnlock = { finish() })
            }
        }
    }
}