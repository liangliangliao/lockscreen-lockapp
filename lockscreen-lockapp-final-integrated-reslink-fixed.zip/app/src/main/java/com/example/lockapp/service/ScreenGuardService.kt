
package com.example.lockapp.service

import android.app.*
import android.content.*
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.lifecycle.Lifecycle
import com.example.lockapp.ui.LockActivity
import com.example.lockapp.R

class ScreenGuardService : Service() {

    private val scrReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    getSharedPreferences("lock_prefs", MODE_PRIVATE)
                        .edit().putBoolean("should_lock", true).apply()
                }
                Intent.ACTION_SCREEN_ON -> {
                    val shouldLock = getSharedPreferences("lock_prefs", MODE_PRIVATE)
                        .getBoolean("should_lock", true)
                    if (shouldLock) {
                        triggerLockUI()
                    }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        startInForeground()
        registerReceiver(scrReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(scrReceiver) } catch (_: Exception) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startInForeground() {
        val chId = "lock_guard_ch"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(chId, "Lock Guard", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(ch)
        }
        val n = NotificationCompat.Builder(this, chId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("锁屏守护运行中")
            .setContentText("监控亮灭屏以显示密码界面")
            .setOngoing(true)
            .build()
        startForeground(101, n)
    }

    private fun triggerLockUI() {
        val lifecycleState = ProcessLifecycleOwner.get().lifecycle.currentState
        val appInForeground = lifecycleState.isAtLeast(Lifecycle.State.STARTED)

        val intent = Intent(this, LockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }

        if (appInForeground) {
            startActivity(intent)
        } else {
            val fsPi = PendingIntent.getActivity(
                this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val chId = "lock_fs_ch"
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                val ch = NotificationChannel(
                    chId, "Lock Fullscreen", NotificationManager.IMPORTANCE_HIGH
                ).apply { lockscreenVisibility = Notification.VISIBILITY_PUBLIC }
                nm.createNotificationChannel(ch)
            }
            val n = NotificationCompat.Builder(this, chId)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("需要验证")
                .setContentText("请完成密码验证")
                .setCategory(Notification.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setFullScreenIntent(fsPi, true)
                .setAutoCancel(true)
                .build()
            nm.notify(202, n)
        }
    }
}
