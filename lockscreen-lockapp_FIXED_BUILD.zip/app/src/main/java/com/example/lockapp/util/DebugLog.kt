
package com.example.lockapp.util

import android.util.Log

private const val TAG_BASE = "LockApp"

/** Simple warn logger kept for backward compatibility. */
fun w(tag: String, msg: String, tr: Throwable? = null) {
    if (tr != null) Log.w("$TAG_BASE/$tag", msg, tr) else Log.w("$TAG_BASE/$tag", msg)
}

/** Info logger kept for compatibility (not widely used). */
fun i(tag: String, msg: String) {
    Log.i("$TAG_BASE/$tag", msg)
}
