
package com.example.lockapp.util

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.R
import com.example.lockapp.LockScreenActivity

/**
 * Helper to show heads-up and full-screen notifications used by the lock flow.
 * Keep implementation minimal to avoid behavior change.
 */
object LockFsNotifier {

    private fun defaultContentIntent(ctx: Context): PendingIntent {
        val intent = Intent(ctx, LockScreenActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        return PendingIntent.getActivity(ctx, 0, intent, flags)
    }

    /** Simple Heads-Up notification (high priority). */
    @JvmStatic
    fun showHeadsUp(ctx: Context, msg: String = "Heads up") {
        // Ensure a channel exists for HUN
        ensureChannel(ctx, channelId = "lockapp_fs_hun", channelName = "LockApp HeadsUp", importance = NotificationManagerCompat.IMPORTANCE_HIGH)

        val builder = NotificationCompat.Builder(ctx, "lockapp_fs_hun")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("LockApp")
            .setContentText(msg)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(Notification.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setContentIntent(defaultContentIntent(ctx))

        NotificationManagerCompat.from(ctx).notify(1002, builder.build())
    }

    /** Full-screen intent style notification. */
    @JvmStatic
    fun showFullScreen(ctx: Context, title: String = "Unlock required", text: String = "Tap to open lock screen") {
        ensureChannel(ctx, channelId = "lockapp_fs_fullscreen", channelName = "LockApp FullScreen", importance = NotificationManagerCompat.IMPORTANCE_HIGH)

        val fullPi = defaultContentIntent(ctx)
        val builder = NotificationCompat.Builder(ctx, "lockapp_fs_fullscreen")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(Notification.CATEGORY_CALL) // Helps HUN/FS behavior
            .setAutoCancel(true)

        // Use extension shim for compatibility
        builder.setFullScreenIntent(fullPi, /*highPriority=*/true)

        NotificationManagerCompat.from(ctx).notify(1003, builder.build())
    }
}
