package com.example.lockapp.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.lockapp.data.ImagePassword
import com.example.lockapp.data.ImagePasswordRepository
import com.example.lockapp.data.RotationManager
import com.example.lockapp.data.RotationMode
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(
    private val repo: ImagePasswordRepository,
    private val rotationManager: RotationManager
) : ViewModel() {

    val entries: StateFlow<List<ImagePassword>> =
        repo.all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val mode: StateFlow<RotationMode> =
        rotationManager.mode.stateIn(viewModelScope, SharingStarted.Eagerly, RotationMode.SEQUENTIAL)

    fun addOrUpdate(uri: Uri, password: String, existing: ImagePassword? = null) {
        viewModelScope.launch {
            repo.insertOrUpdate(uri.toString(), password, existing)
        }
    }

    fun remove(item: ImagePassword) {
        viewModelScope.launch { repo.delete(item) }
    }

    // Alias for legacy call sites
    fun delete(item: ImagePassword) = remove(item)

        viewModelScope.launch { repo.delete(item) }
    }

    fun clearAll() {
        viewModelScope.launch { repo.clear() }
    }

    fun setMode(value: RotationMode) {
        rotationManager.setMode(value)
    }

    // Alias for legacy call sites
    fun setRotationMode(value: RotationMode) = setMode(value)

        viewModelScope.launch { rotationManager.setMode(value) }
    }

    // Legacy-friendly overloads used by UI
    fun insertOrUpdate(imageUri: Uri, password: String, existing: ImagePassword? = null) {
        add(imageUri, password)
    }
    fun insertOrUpdate(uri: String, password: String, existing: ImagePassword? = null) {
        viewModelScope.launch { repo.insertOrUpdate(ImagePassword(uri, password)) }
    }
    
}
