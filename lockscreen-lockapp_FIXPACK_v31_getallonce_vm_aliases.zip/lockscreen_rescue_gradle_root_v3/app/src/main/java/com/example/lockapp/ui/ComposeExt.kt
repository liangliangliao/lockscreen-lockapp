package com.example.lockapp.ui

import androidx.compose.ui.Modifier

/** No-op overlay extension to satisfy old references. */
fun Modifier.overlay(alpha: Float = 0.5f): Modifier = this
