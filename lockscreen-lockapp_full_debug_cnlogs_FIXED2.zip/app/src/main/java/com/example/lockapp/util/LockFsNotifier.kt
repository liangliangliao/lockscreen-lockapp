package com.example.lockapp.util

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.R

/**
 * 负责全屏通知(FSI)与调试 heads-up 的创建与发送；
 * 统一在这里保证通知渠道存在，避免调用方出现未创建渠道导致的静默失败。
 */
object LockFsNotifier {
    private const val CHANNEL_FSI = "lock_guard_fsi"
    private const val CHANNEL_FG = "lock_guard_fg"
    private const val NOTIFY_FSI_ID = 0x9321
    private const val NOTIFY_DEBUG_BASE = 0x9500

    /** 创建高优先级通知渠道：FSI 用和普通 heads-up 用 */
    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = context.getSystemService(NotificationManager::class.java)
            // FSI 渠道
            var ch = nm.getNotificationChannel(CHANNEL_FSI)
            if (ch == null) {
                ch = NotificationChannel(
                    CHANNEL_FSI,
                    "锁屏全屏通知",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                    enableVibration(true)
                    enableLights(true)
                    setShowBadge(false)
                    setBypassDnd(true)
                    description = "用于在锁屏时以全屏方式拉起解锁界面"
                }
                nm.createNotificationChannel(ch)
            }
            // 普通 heads-up 渠道
            var fg = nm.getNotificationChannel(CHANNEL_FG)
            if (fg == null) {
                fg = NotificationChannel(
                    CHANNEL_FG,
                    "锁屏调试通知",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                    enableVibration(true)
                    enableLights(true)
                    setShowBadge(false)
                    description = "用于显示调试提示（路径与分支）"
                }
                nm.createNotificationChannel(fg)
            }
        }
    }

    /**
     * 发送一条全屏通知（FSI），目标为 LockScreenActivity。
     * 用于在后台启动 Activity 受限时，依靠 FSI 将界面顶到前台。
     */
    fun showFullScreen(context: Context) {
        ensureChannels(context)

        val intent = Intent(context, LockScreenActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
            .setAction("com.example.lockapp.SHOW_LOCK")

        val piFlags = if (Build.VERSION.SDK_INT >= 23)
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        else PendingIntent.FLAG_UPDATE_CURRENT

        val fullPi = PendingIntent.getActivity(context, 100, intent, piFlags)

        val builder = NotificationCompat.Builder(context, CHANNEL_FSI)
            .setSmallIcon(R.drawable.ic_stat_name)
            .setContentTitle("锁屏解锁")
            .setContentText("正在尝试以全屏方式打开解锁界面")
            .setCategory(NotificationCompat.CATEGORY_CALL) // 部分 ROM 会优先处理
            .setPriority(if (Build.VERSION.SDK_INT < 26) NotificationCompat.PRIORITY_MAX else 0)
            .setAutoCancel(true)
            .setOngoing(false)
            .setFullScreenIntent(fullPi, true)

        NotificationManagerCompat.from(context).notify(NOTIFY_FSI_ID, builder.build())
    }

    /** 调试：快捷显示一个高优先级 heads-up 通知（锁屏也可见） */
    fun showDebugHeadsUp(context: Context, title: String, text: String) {
        try {
            ensureChannels(context)
            val n = NotificationCompat.Builder(context, CHANNEL_FG)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(text)
                .setPriority(if (Build.VERSION.SDK_INT < 26) NotificationCompat.PRIORITY_HIGH else 0)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setAutoCancel(true)
                .build()
            val id = (System.currentTimeMillis() % 100000).toInt() + NOTIFY_DEBUG_BASE
            NotificationManagerCompat.from(context).notify(id, n)
        } catch (_: Throwable) {}
    }
}