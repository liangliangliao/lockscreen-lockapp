#!/usr/bin/env bash
set -e
"$GRADLE_8_4_HOME/bin/gradle" tasks --all | sed -n '1,200p'
