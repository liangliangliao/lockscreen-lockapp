package com.example.lockapp.activity

import android.app.KeyguardManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.util.LockVisibilityTracker
import com.example.lockapp.util.LockCoordinator

/**
 * A transparent, show-when-locked trampoline opened by FSI.
 * It immediately launches LockScreenActivity and finishes.
 */
class TrampolineActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            if (Build.VERSION.SDK_INT >= 27) {
                setShowWhenLocked(true)
                setTurnScreenOn(true)
            } else {
                @Suppress("DEPRECATION")
                window.addFlags(
                    android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                )
            }
        } catch (_: Throwable) {}

        if (LockCoordinator.isLocked(this)) {
            val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
            val i = Intent(this, LockScreenActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .setAction("com.example.lockapp.SHOW_LOCK")
            try { startActivity(i) } catch (_: Throwable) {}
        }
        finish()
    }

    override fun onResume() {
        super.onResume()
        LockVisibilityTracker.visible = true
    }
}