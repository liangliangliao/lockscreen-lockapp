package com.example.lockapp.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.PowerManager
import android.util.Log
import android.view.Display
import java.util.concurrent.CopyOnWriteArraySet

/**
 * 统一的“屏幕状态(息屏/亮屏)”检测与订阅工具。
 * - isScreenInteractive(context): 可信获取当前是否亮屏（interactive）
 * - start/stop: 动态注册 ACTION_SCREEN_ON/OFF 与 DisplayListener
 * - addListener/removeListener: 订阅屏幕状态变化事件
 */
object ScreenStateMonitor {
    private const val TAG = "ScreenStateMonitor"
    private var started = false
    @Volatile private var _interactive: Boolean = false
    val interactive: Boolean get() = _interactive

    interface Listener {
        fun onScreenInteractiveChanged(interactive: Boolean)
    }

    private val listeners = CopyOnWriteArraySet<Listener>()

    fun isScreenInteractive(context: Context): Boolean {
        return try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (Build.VERSION.SDK_INT >= 20) pm.isInteractive else @Suppress("DEPRECATION") pm.isScreenOn
        } catch (_: Throwable) {
            // 兜底：用 DisplayManager 判断是否有一个状态为 STATE_ON 的屏幕
            try {
                val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
                dm.displays.any { it.state == Display.STATE_ON }
            } catch (_: Throwable) {
                true // 保守返回 true，避免误判关闭触发
            }
        }
    }

    fun start(context: Context) {
        if (started) return
        started = true
        _interactive = isScreenInteractive(context)
        Log.d(TAG, "start, interactive=$_interactive")

        // 1) 动态广播：SCREEN_ON/OFF
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        context.registerReceiver(receiver, filter)

        // 2) DisplayManager: 监听屏幕状态变化（更实时）
        try {
            val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            dm.registerDisplayListener(displayListener, null)
        } catch (_: Throwable) { }
    }

    fun stop(context: Context) {
        if (!started) return
        started = false
        try { context.unregisterReceiver(receiver) } catch (_: Throwable) {}
        try {
            val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            dm.unregisterDisplayListener(displayListener)
        } catch (_: Throwable) {}
    }

    fun addListener(l: Listener) { listeners.add(l) }
    fun removeListener(l: Listener) { listeners.remove(l) }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_ON -> update(context, true, "BRD_ON")
                Intent.ACTION_SCREEN_OFF -> update(context, false, "BRD_OFF")
            }
        }
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}

        override fun onDisplayChanged(displayId: Int) {
            // 只要有任何一个 Display 切到 ON，我们就认为 interactive
            // 有些场景（AOD/外接）可能有多个 display，取 "任一 ON 即视为交互"
            val ctx = appContext
            if (ctx != null) {
                val now = isScreenInteractive(ctx)
                update(ctx, now, "DM_CHANGED")
            }
        }
    }

    @Volatile private var appContext: Context? = null

    private fun update(context: Context, interactive: Boolean, src: String) {
        appContext = context.applicationContext
        val now = isScreenInteractive(context) // 再确认一次
        val newVal = interactive && now
        if (_interactive != newVal) {
            _interactive = newVal
            Log.d(TAG, "interactive=$_interactive src=$src")
            listeners.forEach {
                try {
                    if (!_interactive) {
                        val i = android.content.Intent(context, com.example.lockapp.service.GatekeeperService::class.java)
                        androidx.core.content.ContextCompat.startForegroundService(context, i)
                    }
                } catch (_: Throwable) {}

                try { it.onScreenInteractiveChanged(_interactive) } catch (_: Throwable) {}
            }
        } else {
            Log.d(TAG, "interactive unchanged=$_interactive src=$src")
        }
    }
}