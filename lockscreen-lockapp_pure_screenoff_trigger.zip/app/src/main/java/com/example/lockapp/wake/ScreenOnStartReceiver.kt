package com.example.lockapp.wake

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import android.os.Build
import com.example.lockapp.service.GatekeeperService

class ScreenOnStartReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            ContextCompat.startForegroundService(
                context,
                Intent(context, GatekeeperService::class.java)
                        .setAction("com.example.lockapp.action.BOOST")
                        .addFlags(Intent.FLAG_RECEIVER_FOREGROUND)
            )
        } catch (_: Throwable) {
            try { context.startService(Intent(context, GatekeeperService::class.java)) } catch (_: Throwable) {}
        }
    }
}
