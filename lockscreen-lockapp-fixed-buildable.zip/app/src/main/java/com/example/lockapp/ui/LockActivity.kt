
package com.example.lockapp.ui

import android.app.Activity
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

class LockActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        )

        setContent { LockScreen() }
    }
}

@Composable
fun LockScreen() {
    val ctx = LocalContext.current
    val sp = ctx.getSharedPreferences("lock_prefs", Activity.MODE_PRIVATE)
    val expect = sp.getString("password", "") ?: ""
    var input by remember { mutableStateOf("") }
    val bg = sp.getString("bg_uri", null)

    Box(Modifier.fillMaxSize()) {
        if (!bg.isNullOrBlank()) {
            AsyncImage(
                model = bg,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }

        Column(
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp)
        ) {
            Text("请输入解锁密码", textAlign = TextAlign.Center, style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                label = { Text("明文密码") }
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = {
                if (input == expect && input.isNotBlank()) {
                    (ctx as Activity).finish()
                }
            }) { Text("解锁") }
        }
    }
}
