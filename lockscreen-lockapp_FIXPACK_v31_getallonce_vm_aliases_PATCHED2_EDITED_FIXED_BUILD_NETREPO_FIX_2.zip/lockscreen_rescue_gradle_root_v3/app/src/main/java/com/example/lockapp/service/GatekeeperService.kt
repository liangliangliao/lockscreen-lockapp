package com.example.lockapp.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.lockapp.R
import com.example.lockapp.LockScreenActivity

/**
 * Foreground keeper that listens screen-on and shows the lock UI via a full-screen intent.
 * NOTE: We deliberately avoid referencing android.content.pm.ServiceInfo to keep
 * the code compiling across different Android plugin/sdk setups.
 */
class GatekeeperService : Service() {

    private val channelId = "gk_foreground"
    private val alertChannelId = "gk_alerts"
    private var screenReceiver: BroadcastReceiver? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        registerScreenOnReceiver()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Start as a foreground service with a minimal ongoing notification.
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm.getNotificationChannel(channelId) == null) {
            createChannels()
        }
        val notification = buildServiceNotification()
        // Use two-arg startForeground to avoid explicit ServiceInfo constants; types are declared in Manifest.
        startForeground(1337, notification)
        return START_STICKY
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(screenReceiver)
        } catch (_: Throwable) {}
        screenReceiver = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun registerScreenOnReceiver() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_SCREEN_ON,
                    Intent.ACTION_USER_PRESENT -> {
                        showLockNow()
                    }
                }
            }
        }
        registerReceiver(screenReceiver, filter)
    }

    private fun buildServiceNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this,
            100,
            Intent(this, LockScreenActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_lock_patch)
            .setContentTitle(getString(R.string.app_name))
            .setContentText("守护服务运行中")
            .setOngoing(true)
            .setContentIntent(pi)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun buildAlertNotification(): Notification {
        // Full-screen intent to force show the lock UI
        val fullPi = PendingIntent.getActivity(
            this,
            101,
            Intent(this, LockScreenActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        return NotificationCompat.Builder(this, alertChannelId)
            .setSmallIcon(R.drawable.ic_lock_patch)
            .setContentTitle("正在唤起解锁界面")
            .setContentText("点按以继续")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(Notification.CATEGORY_CALL)
            .setFullScreenIntent(fullPi, true)
            .setAutoCancel(true)
            .build()
    }

    private fun showLockNow() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        // Ensure channel exists on O+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm.getNotificationChannel(alertChannelId) == null) {
            createChannels()
        }
        val n = buildAlertNotification()
        nm.notify(10086, n)
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val fg = NotificationChannel(channelId, "Gatekeeper Service", NotificationManager.IMPORTANCE_MIN)
            nm.createNotificationChannel(fg)
            val alerts = NotificationChannel(alertChannelId, "Lock Alerts", NotificationManager.IMPORTANCE_HIGH)
            alerts.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(alerts)
        }
    }
}
