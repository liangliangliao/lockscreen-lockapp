package com.example.lockapp.util

import android.content.Context
import android.os.SystemClock
import com.example.lockapp.data.LockStateStore

object LockCoordinator {
    @Volatile private var lastShownAt: Long = 0L
    @Volatile private var isShowing: Boolean = false
    private const val DEBOUNCE_MS = 2000L

    fun isLocked(context: Context): Boolean = LockStateStore(context).isLocked()

    fun setLocked(context: Context, v: Boolean) = LockStateStore(context).setLocked(v)

    
    // Allow one on-demand show ignoring debounce once.
    @Volatile private var allowNextShow: Boolean = false

    /**
     * Request the lock UI to be allowed to show once soon, ignoring the debounce.
     * Returns true if the flag was set.
     */
    @Synchronized
    fun requestShowOnce(): Boolean {
        allowNextShow = true
        return true
    }

    /**
     * Try to enter "showing" state. Returns true if we are allowed to show now.
     * Debounced to avoid spamming the UI.
     */
    @Synchronized
    fun tryEnterShowing(): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (allowNextShow || (now - lastShownAt) > DEBOUNCE_MS) {
            isShowing = true
            allowNextShow = false
            lastShownAt = now
            return true
        }
        return false
    }

    /** Leave showing state and record the timestamp to enforce debounce. */
    @Synchronized
    fun leaveShowing() {
        isShowing = false
        lastShownAt = SystemClock.elapsedRealtime()
    }

    @Synchronized
    fun releaseShowOnce() {
        // Reset internal debounce state to allow another show
        isShowing = false
        lastShownAt = 0L
        allowNextShow = false
    }

    /** Convenience used by UI to mark the device as unlocked and clear the showing gate. */
    fun markUnlocked(context: android.content.Context) {
        setLocked(context, false)
        leaveShowing()
    }

}
