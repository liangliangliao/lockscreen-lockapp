package com.example.lockapp.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.lockapp.data.ImagePassword
import com.example.lockapp.data.ImagePasswordRepository
import com.example.lockapp.data.RotationManager
import com.example.lockapp.data.RotationMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

/**
 * Central app state holder bridging UI and data/repository layers.
 */
class MainViewModel(
    private val repo: ImagePasswordRepository,
    private val rotationManager: RotationManager
) : ViewModel() {

    /** Stream of saved image-password pairs. */
    val items: Flow<List<ImagePassword>> = repo.items
    // Back-compat alias for older UI code
    val entries: Flow<List<ImagePassword>> = items

    /** Current rotation mode stream. */
    val rotationMode: Flow<RotationMode> = rotationManager.rotationMode

    /** Convenience alias required by some older UI code. */
    val mode: Flow<RotationMode> = rotationMode

    /** Add or update an entry by uri + password. */
    fun add(imageUri: String, password: String) {
        viewModelScope.launch {
            repo.insertOrUpdate(imageUri, password)
        }
    }

    /** Add or update an entry by entity. */
    fun add(entity: ImagePassword) {
        viewModelScope.launch {
            repo.insertOrUpdate(entity)
        }
    }

    /** Remove an entry. */
    fun remove(entity: ImagePassword) {
        viewModelScope.launch {
            repo.delete(entity)
        }
    }

    /** Backwards-compat method name used by UI. */
    fun delete(entity: ImagePassword) = remove(entity)

    /** Change rotation mode. */
    fun setRotationMode(value: RotationMode) {
        viewModelScope.launch {
            rotationManager.setRotationMode(value)
        }
    }

    /** Backwards-compat alias. */
    fun setMode(value: RotationMode) = setRotationMode(value)
}
