package com.example.lockapp.patchlock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.lockapp.service.GatekeeperService

/**
 * Manifest references this class. Keep it minimal: just forward system broadcasts
 * (BOOT_COMPLETED / LOCKED_BOOT_COMPLETED / MY_PACKAGE_REPLACED) to GatekeeperService.
 * We prefer foreground service on O+ to satisfy background start restrictions.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            ContextCompat.startForegroundService(
                context,
                Intent(context, GatekeeperService::class.java)
            )
        } catch (_: Throwable) {
            try { context.startService(Intent(context, GatekeeperService::class.java)) } catch (_: Throwable) {}
        }
    }
}
