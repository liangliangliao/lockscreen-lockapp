package com.example.lockapp.boot

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.lockapp.service.GatekeeperService

class BootAndUpdateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_LOCKED_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> {
                try {
                    ContextCompat.startForegroundService(
                        context, Intent(context, GatekeeperService::class.java)
                    )
                } catch (_: Throwable) {}
            }
        }
    }
}