package com.example.app.patchlock

object AppLockState {
    @Volatile private var locked: Boolean = true
    fun markLocked() { locked = true }
    fun markUnlocked() { locked = false }
    fun shouldLockNow(): Boolean = locked
}
