// BUILD TAG: LOCKAPP-FSI-FIX-CI-REWRITE-20250907
package com.example.lockapp.util

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.MainActivity
import com.example.lockapp.util.ChanIDs.FOREGROUND
import com.example.lockapp.util.CompatIcons.LAUNCHER_ICON

/**
 * Utilities to send heads-up and full-screen notifications.
 * Keep the implementation minimal and stable for CI builds.
 */
object LockFsNotifier {

    private const val FSI_CHANNEL_ID = FOREGROUND
    private const val FSI_NOTIF_ID = 10001

    private fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(
                FSI_CHANNEL_ID,
                "LockApp Foreground",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Foreground / full-screen wake channel"
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            nm?.createNotificationChannel(ch)
        }
    }

    fun showHeadsUp(ctx: Context, title: String, text: String) {
        ensureChannel(ctx)
        val contentPi = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or (
                if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
            )
        )
        val n = NotificationCompat.Builder(ctx, FSI_CHANNEL_ID)
            .setSmallIcon(LAUNCHER_ICON)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(contentPi)
            .build()
        NotificationManagerCompat.from(ctx).notify(FSI_NOTIF_ID, n)
    }

    fun showDebugHeadsUp(ctx: Context, title: String, text: String) = showHeadsUp(ctx, title, text)

    fun showFullScreen(ctx: Context) {
        ensureChannel(ctx)
        val fullPi = PendingIntent.getActivity(
            ctx, 1,
            Intent(ctx, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("from_fsi", true)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or (
                if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
            )
        )
        val n = NotificationCompat.Builder(ctx, FSI_CHANNEL_ID)
            .setSmallIcon(LAUNCHER_ICON)
            .setContentTitle("唤醒屏幕")
            .setContentText("通过全屏通知拉起界面")
            .setCategory(Notification.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setFullScreenIntent(fullPi, true)
            .build()

        NotificationManagerCompat.from(ctx).notify(FSI_NOTIF_ID, n)
        Toaster.show5s(ctx, "已发送全屏通知")
    }
}
