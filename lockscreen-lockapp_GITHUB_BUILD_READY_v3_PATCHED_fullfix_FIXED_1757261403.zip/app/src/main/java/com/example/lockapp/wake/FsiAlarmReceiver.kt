// BUILD TAG: LOCKAPP-FSI-FIX-CI-REWRITE-20250907
package com.example.lockapp.wake

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.MainActivity
import com.example.lockapp.util.ChanIDs
import com.example.lockapp.util.CompatIcons
import com.example.lockapp.util.Toaster

class FsiAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        ensureChannel(context)
        val fullPi = PendingIntent.getActivity(
            context, 3001,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("from_fsi_alarm", true)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or (
                if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
            )
        )

        val n = NotificationCompat.Builder(context, ChanIDs.FOREGROUND)
            .setSmallIcon(CompatIcons.LAUNCHER_ICON)
            .setContentTitle("闹钟唤醒")
            .setContentText("通过广播触发全屏通知")
            .setCategory(Notification.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setFullScreenIntent(fullPi, true)
            .build()

        NotificationManagerCompat.from(context).notify(30010, n)
        Toaster.show5s(context, "FSI广播已触发")
    }

    private fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(
                ChanIDs.FOREGROUND,
                "LockApp Foreground",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "用于锁屏场景的全屏弹窗测试"
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            nm?.createNotificationChannel(ch)
        }
    }
}
