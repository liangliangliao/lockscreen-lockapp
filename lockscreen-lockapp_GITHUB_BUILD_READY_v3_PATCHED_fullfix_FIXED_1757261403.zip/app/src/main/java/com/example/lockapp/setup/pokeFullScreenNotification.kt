// BUILD TAG: LOCKAPP-FSI-POKE-FIX-20250907
package com.example.lockapp.setup

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.MainActivity
import com.example.lockapp.util.ChanIDs
import com.example.lockapp.util.CompatIcons

/**
 * Issue a one-shot full-screen notification for setup/wizard poke.
 */
fun pokeFullScreenNotification(ctx: Context) {
    // Ensure channel
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(
            ChanIDs.FOREGROUND,
            "LockApp Foreground",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Foreground / full-screen wake channel"
            setShowBadge(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        nm?.createNotificationChannel(ch)
    }

    val fullPi = PendingIntent.getActivity(
        ctx, 2001,
        Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("from_fsi_poke", true)
        },
        PendingIntent.FLAG_UPDATE_CURRENT or (
            if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
    )

    val n = NotificationCompat.Builder(ctx, ChanIDs.FOREGROUND)
        .setSmallIcon(CompatIcons.LAUNCHER_ICON)
        .setContentTitle("测试全屏通知")
        .setContentText("这是一条用于唤起界面的测试通知")
        .setCategory(Notification.CATEGORY_CALL)
        .setPriority(NotificationCompat.PRIORITY_MAX)
        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        .setAutoCancel(true)
        .setFullScreenIntent(fullPi, true)
        .build()

    NotificationManagerCompat.from(ctx).notify(20010, n)
}
