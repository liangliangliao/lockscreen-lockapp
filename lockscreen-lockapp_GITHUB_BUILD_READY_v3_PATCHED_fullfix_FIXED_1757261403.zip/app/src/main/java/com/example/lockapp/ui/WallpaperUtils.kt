// BUILD TAG: LOCKAPP-FSI-FIX-CI-20250907T021838Z
package com.example.lockapp.ui
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.content.Intent
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R

import android.app.WallpaperManager
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build

fun setLockScreenWallpaper(context: Context, uri: Uri): Boolean {
    return try {
        val wm = WallpaperManager.getInstance(context)
        context.contentResolver.openInputStream(uri).use { input ->
            val bmp = BitmapFactory.decodeStream(input) ?: return false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                wm.setBitmap(bmp, null, true, WallpaperManager.FLAG_LOCK)
            } else {
                wm.setBitmap(bmp)
            }
        }
        true
    } catch (_: Throwable) {
        false
    }
}