package com.example.lockapp

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import com.example.lockapp.ui.LiveLockScreen

class LauncherActivity : ComponentActivity() {

    private fun tryEnterKiosk() {
        try {
            val dpm = getSystemService(android.app.admin.DevicePolicyManager::class.java)
            val comp = android.content.ComponentName(this, com.example.lockapp.admin.MyDeviceAdminReceiver::class.java)
            if (dpm != null && dpm.isDeviceOwnerApp(packageName)) {
                dpm.setLockTaskPackages(comp, arrayOf(packageName))
                startLockTask()
            } else {
                // If not DO, user-initiated screen pin prompt may appear on startLockTask()
                startLockTask()
            }
        } catch (t: Throwable) {
            // ignore
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        tryEnterKiosk()
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            LiveLockScreen(
                onUnlock = {
                    startActivity(Intent(this, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
                    })
                    finish()
                }
            )
        }
    }
}
