package com.example.lockapp.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.lockapp.data.ActiveLockStore
import com.example.lockapp.data.LockConfigStore
import com.example.lockapp.service.GatekeeperService

class BootCompleteReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try {
            if (!LockConfigStore.isArmed(context)) return
            val pwd = ActiveLockStore.getPwd(context) ?: return
            if (pwd.isEmpty()) return
            com.example.lockapp.data.LockStateStore.setRequireUnlock(context, true)
            val svc = Intent(context, GatekeeperService::class.java)
            try { context.startForegroundService(svc) } catch (_: Throwable) { context.startService(svc) }
        } catch (t: Throwable) {
            Log.e("BootCompleteReceiver", "failed to start service on boot", t)
        }
    }
}