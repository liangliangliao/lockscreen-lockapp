package com.example.lockapp.data

import android.content.Context

/**
 * Ephemeral runtime lock state.
 *
 * - locked: legacy flag (kept for backward-compat)
 * - requireUnlock: whether the next foreground/Home should present our LockActivity
 */
object LockStateStore {
    private const val PREF = "lock_state_prefs"
    private const val KEY_LOCKED = "locked"
    private const val KEY_REQUIRE = "require_unlock"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    /** Legacy: some code still toggles this; keep behavior but prefer [setRequireUnlock]. */
    fun setLocked(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_LOCKED, value).apply()
        // Keep the two in sync: locked=true implies requireUnlock=true
        if (value) setRequireUnlock(context, true)
    }
    fun isLocked(context: Context): Boolean = prefs(context).getBoolean(KEY_LOCKED, false)

    fun isRequireUnlock(context: Context): Boolean = prefs(context).getBoolean(KEY_REQUIRE, false)
    fun setRequireUnlock(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_REQUIRE, value).apply()
        if (!value) {
            // Clear legacy flag too
            prefs(context).edit().putBoolean(KEY_LOCKED, false).apply()
        }
    }
}
