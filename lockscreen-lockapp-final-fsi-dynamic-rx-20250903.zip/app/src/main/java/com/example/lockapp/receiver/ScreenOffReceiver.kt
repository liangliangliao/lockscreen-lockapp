package com.example.lockapp.receiver
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.lockapp.util.GateXPrefs
class ScreenOffReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_SCREEN_OFF) return
        Log.d("ScreenOffReceiver", "ACTION_SCREEN_OFF -> pending=true")
        GateXPrefs.setPending(context, true)
    }
}
