package com.example.lockapp

import android.app.KeyguardManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import com.example.lockapp.ui.LiveLockScreen
import com.example.lockapp.util.LockVisibilityTracker

class LockScreenActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(
            android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            android.view.WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        // Request to dismiss keyguard where allowed
        getSystemService(KeyguardManager::class.java)?.requestDismissKeyguard(this, null)

        setContent {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            LiveLockScreen(
                onUnlock = {
                    finish() // close lock screen when unlocked
                }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        LockVisibilityTracker.visible = true
    }

    override fun onPause() {
        LockVisibilityTracker.visible = false
        super.onPause()
    }
}
