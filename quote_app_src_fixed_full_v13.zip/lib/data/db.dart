import 'dart:async';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  static Database? _db;
  static Future<Database> instance() async {
    if (_db != null) return _db!;
    final dir = await getApplicationDocumentsDirectory();
    final path = p.join(dir.path, 'quotes.db');
    _db = await openDatabase(path, version: 3, onCreate: _onCreate, onUpgrade: _onUpgrade);
    return _db!;
  }

  static Future _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE quotes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        text TEXT NOT NULL,
        author TEXT NOT NULL,
        source TEXT DEFAULT '未知',
        lang TEXT DEFAULT 'zh',
        tags TEXT DEFAULT '',
        prompt_id INTEGER,
        created_at INTEGER NOT NULL,
        hash TEXT NOT NULL
      );
    ''');

    await db.execute('''
      CREATE VIRTUAL TABLE fts_quotes USING fts5(text, author, source, content='quotes', content_rowid='id');
    ''');

    await db.execute('''
      CREATE TRIGGER quotes_ai AFTER INSERT ON quotes BEGIN
        INSERT INTO fts_quotes(rowid, text, author, source) VALUES (new.id, new.text, new.author, new.source);
      END;
    ''');
    await db.execute('''
      CREATE TRIGGER quotes_ad AFTER DELETE ON quotes BEGIN
        INSERT INTO fts_quotes(fts_quotes, rowid, text, author, source) VALUES('delete', old.id, old.text, old.author, old.source);
      END;
    ''');
    await db.execute('''
      CREATE TRIGGER quotes_au AFTER UPDATE ON quotes BEGIN
        INSERT INTO fts_quotes(fts_quotes, rowid, text, author, source) VALUES('delete', old.id, old.text, old.author, old.source);
        INSERT INTO fts_quotes(rowid, text, author, source) VALUES (new.id, new.text, new.author, new.source);
      END;
    ''');

    await db.execute('CREATE INDEX idx_quotes_created_at ON quotes(created_at DESC);');
    await db.execute('CREATE UNIQUE INDEX idx_quotes_hash ON quotes(hash);');

    await db.execute('''
      CREATE TABLE prompts(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        content TEXT NOT NULL,
        is_default INTEGER DEFAULT 0,
        updated_at INTEGER NOT NULL
      );
    ''');

    await db.execute('''
      CREATE TABLE schedules(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        type TEXT NOT NULL,
        payload TEXT NOT NULL,
        enabled INTEGER DEFAULT 1,
        next_run_at INTEGER,
        last_run_at INTEGER
      );
    ''');

    await db.execute('''
      CREATE TABLE settings(
        id INTEGER PRIMARY KEY CHECK (id = 1),
        auto_fetch_enabled INTEGER DEFAULT 0,
        notification_enabled INTEGER DEFAULT 1,
        badge_enabled INTEGER DEFAULT 1,
        quiet_hours TEXT DEFAULT '',
        backend_mode TEXT DEFAULT 'local',
        api_key TEXT
      );
    ''');

    await db.insert('settings', {'id': 1});
  }

  static Future _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await db.execute('ALTER TABLE schedules ADD COLUMN next_run_at INTEGER;');
      await db.execute('ALTER TABLE schedules ADD COLUMN last_run_at INTEGER;');
    }
    if (oldVersion < 3) {
      await db.execute('ALTER TABLE settings ADD COLUMN api_key TEXT;');
    }
  }
}
