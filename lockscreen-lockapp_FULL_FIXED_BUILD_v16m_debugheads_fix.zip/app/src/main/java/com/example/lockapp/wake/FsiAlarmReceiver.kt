package com.example.lockapp.wake

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.util.DebugLog
import com.example.lockapp.util.Toaster

/**
 * 闹钟兜底接收器：不依赖 ScreenOnBinder，屏幕亮起后若主通路被 Doze/延迟，
 * 则由闹钟触发一次 FSI。
 */
class FsiAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        if ("com.example.lockapp.ACTION_FSI_ALARM" != intent.action) return
        Toaster.show5s(ctx, "兜底闹钟触发：尝试发送全屏弹窗")
        try {
            postFsiNow(ctx)
        } catch (t: Throwable) {
            DebugLog.w("FsiAlarmReceiver", "postFsiNow 失败: ${t.message}", t)
        }
    }

    private fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(FSI_CHANNEL_ID) == null) {
                val ch = NotificationChannel(
                    FSI_CHANNEL_ID,
                    "LockApp 全屏通知（FSI）",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "用于锁屏场景的全屏弹窗"
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
                nm.createNotificationChannel(ch)
            }
        }
    }

    private fun postFsiNow(ctx: Context) {
        ensureChannel(ctx)

        val trampolineIntent = Intent().apply {
            setClassName(
                ctx,
                "com.example.lockapp.launcher.TransparentTrampolineActivity"
            )
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            action = "com.example.lockapp.SHOW_LOCK_FROM_FSI"
            putExtra("from_fsi", true)
        }
        val pi = PendingIntent.getActivity(
            ctx, 2102, trampolineIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        Toaster.show5s(ctx, "正在发送全屏弹窗（FSI）[AlarmFallback]")

        val n = NotificationCompat.Builder(ctx, FSI_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("锁屏唤起")
            .setContentText("兜底闹钟触发全屏通知")
            .setCategory(Notification.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setFullScreenIntent(pi, true)
            .build()

        NotificationManagerCompat.from(ctx).notify(2102, n)
    }

    companion object {
        private const val FSI_CHANNEL_ID = "lock_guard_fsi_v2"
    }
}
