package com.example.lockapp.wake

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.lockapp.util.LockFsNotifier
import com.example.lockapp.util.DebugLog

/**
 * 仅用于调试：当闹钟唤醒时，发一条 heads-up 提示。
 * 真正 FSI 发送由 FsiAlarmReceiver 负责。
 */
class AlarmWakeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        DebugLog.i("AlarmWakeReceiver", "闹钟唤醒收到：${intent.action}")
        try { LockFsNotifier.showDebugHeadsUp(context, "闹钟触发", "AlarmWakeReceiver 收到广播") } catch (_: Throwable) {}
    }
}
