package com.example.lockapp.ordered

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.lockapp.util.LockFsNotifier
import com.example.lockapp.util.DebugLog

class WakeOrderedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (ACTION_WAKE_ORDERED != intent.action) return
        DebugLog.i("WakeOrderedReceiver", "收到前台有序广播，触发调试 heads-up")
        try { LockFsNotifier.showDebugHeadsUp(context, "有序广播", "已收到 ACTION_WAKE_ORDERED") } catch (_: Throwable) {}
        resultCode = 1
        abortBroadcast()
    }
    companion object {
        const val ACTION_WAKE_ORDERED = "com.example.lockapp.ACTION_WAKE_ORDERED"
    }
}
