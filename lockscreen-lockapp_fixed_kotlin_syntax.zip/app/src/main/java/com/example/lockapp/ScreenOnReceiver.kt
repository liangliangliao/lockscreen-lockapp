package com.example.lockapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/** 静态亮屏广播：仅用于拉起前台服务，真正的 UI 交给服务的动态广播与 FSI/跳板处理 */
class ScreenOnReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Intent.ACTION_SCREEN_ON == intent.action) {
            try {
                ContextCompat.startForegroundService(
                    context,
                    Intent(context, com.example.lockapp.service.GatekeeperService::class.java)
                )
            } catch (_: Throwable) {}
        }
    }
}