package com.example.lockapp.wake

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/** 闹钟触发的唤醒广播：仅确保服务激活，具体弹窗逻辑由服务负责 */
class AlarmWakeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            ContextCompat.startForegroundService(
                context,
                Intent(context, com.example.lockapp.service.GatekeeperService::class.java)
            )
        } catch (_: Throwable) {}
    }
}