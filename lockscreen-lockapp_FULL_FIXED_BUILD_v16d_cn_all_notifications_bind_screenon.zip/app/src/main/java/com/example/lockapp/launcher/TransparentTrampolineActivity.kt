package com.example.lockapp.launcher

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import com.example.lockapp.MainActivity
import com.example.lockapp.util.DebugLog
import com.example.lockapp.util.DebugTracer

class TransparentTrampolineActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(0, 0)
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            (getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager)?.requestDismissKeyguard(this,null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        DebugLog.w("FSI","TransparentTrampolineActivity started → launching target Activity")
        val targetClass = try { Class.forName("com.example.lockapp.LockScreenActivity") } catch (_: ClassNotFoundException) { MainActivity::class.java }
        try {
            val i = Intent(this, com.example.lockapp.LockScreenActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
                .setAction("com.example.lockapp.SHOW_LOCK_FROM_FSI")
                .putExtra("from_fsi", true)
            startActivity(i)
            DebugLog.w("FSI","Target Activity started from FSI")
        } catch (t: Throwable) {
            DebugLog.e("FSI","Start target from FSI failed: "+t.message,t)
        }
        finish()
        overridePendingTransition(0, 0)
    }
}