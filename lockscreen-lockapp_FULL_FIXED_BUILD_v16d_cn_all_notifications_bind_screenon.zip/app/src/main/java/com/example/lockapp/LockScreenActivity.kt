package com.example.lockapp

import android.app.KeyguardManager
import android.os.Bundle
import android.widget.Toast
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.lockapp.ui.LiveLockScreen
import com.example.lockapp.util.LockVisibilityTracker
import com.example.lockapp.util.DebugTracer

class LockScreenActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        
        try { Toast.makeText(this, "伪锁屏界面已启动", Toast.LENGTH_LONG).show() } catch (_: Throwable) {}
        com.example.lockapp.util.DebugLog.w("LockScreen","LockScreenActivity started (from_fsi=" + (intent?.getBooleanExtra("from_fsi", false)?:false) + ")")
DebugTracer.w("LockScreen", "LockScreen onCreate")
        try { DebugTracer.notify(this, "Trace", "LockScreen onCreate") } catch (t: Throwable) { }
// Ensure we can appear above the keyguard and wake the screen
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        // Ask system to dismiss keyguard when possible
        getSystemService(KeyguardManager::class.java)
            ?.requestDismissKeyguard(this, null)

        setContent {
            LiveLockScreen(
                onEmergency = { /* no-op or start emergency activity if you have one */ },
                onUnlock = {
                    try { getSystemService(android.app.KeyguardManager::class.java)?.requestDismissKeyguard(this, null) } catch (_: Throwable) {}
                    com.example.lockapp.util.LockCoordinator.markUnlocked(this)
                    com.example.lockapp.util.LockCoordinator.leaveShowing()
                    finish()
                }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        
        DebugTracer.w("LockScreen", "LockScreen onResume")
        try { DebugTracer.notify(this, "Trace", "LockScreen onResume") } catch (t: Throwable) { }
LockVisibilityTracker.visible = true
    }

    override fun onDestroy() { super.onDestroy(); com.example.lockapp.util.LockVisibilityTracker.visible = false }

    override fun onPause() {
        super.onPause()
        LockVisibilityTracker.visible = false
    }
}