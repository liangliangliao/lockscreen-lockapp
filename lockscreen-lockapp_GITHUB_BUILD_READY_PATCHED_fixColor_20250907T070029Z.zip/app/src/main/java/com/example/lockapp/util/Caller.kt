// BUILD TAG: LOCKAPP-FSI-FIX-CI-20250907T021838Z
package com.example.lockapp.util
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.content.Context
import android.content.Intent
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R

object Caller {
    @JvmStatic
    fun tag(skip: Int = 3): String {
        return try {
            val st = Throwable().stackTrace
            if (st.size > skip) {
                val el = st[skip]
                val cls = el.className.substringAfterLast('.')
                "${'$'}cls.${'$'}{el.methodName}:${'$'}{el.lineNumber}"
            } else "unknown"
        } catch (_: Throwable) {
            "unknown"
        }
    }
}