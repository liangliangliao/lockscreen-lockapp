
package com.example.lockapp

import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.lockapp.data.ImageStore
import com.example.lockapp.util.DebugToasts

class LockScreenActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show over lockscreen, turn screen on
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }

        val store = ImageStore(this)
        val bg = intent.getStringExtra("backgroundUri") ?: store.getCurrentImageUri()
        val expectedPwd = store.getPasswordForCurrent() ?: ""

        val root = FrameLayout(this)
        val iv = ImageView(this).apply {
            setBackgroundColor(Color.BLACK)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.CENTER_CROP
            if (bg != null) setImageURI(Uri.parse(bg))
            setOnClickListener {
                it.animate().scaleX(1.06f).scaleY(1.06f).setDuration(100).withEndAction {
                    it.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                }.start()
            }
        }
        root.addView(iv, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32,32,32,32)
            setBackgroundColor(0x66000000)
        }
        val et = EditText(this).apply { hint = "输入密码"; setText("") }
        val btn = Button(this).apply {
            text = "解锁"
            setOnClickListener {
                val ok = et.text.toString() == expectedPwd || expectedPwd.isEmpty()
                if (ok) {
                    store.advanceAfterUnlock()
                    DebugToasts.toast("Unlocked")
                    finish()
                } else DebugToasts.toast("密码错误")
            }
        }
        panel.addView(et)
        panel.addView(btn)
        val lp = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        root.addView(panel, lp)

        setContentView(root)

        DebugToasts.toast("LockScreenActivity created")
    }
}
