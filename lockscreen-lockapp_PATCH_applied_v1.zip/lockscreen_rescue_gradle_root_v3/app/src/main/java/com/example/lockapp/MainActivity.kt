
package com.example.lockapp

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.lockapp.data.ImageItem
import com.example.lockapp.data.ImageStore
import com.example.lockapp.service.GatekeeperService
import com.example.lockapp.util.DebugToasts

class MainActivity : AppCompatActivity() {

    private lateinit var store: ImageStore
    private lateinit var grid: GridLayout
    private lateinit var enableSwitch: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ImageStore(this)

        if (!store.onboardingDone()) {
            startActivity(Intent(this, OnboardingActivity::class.java))
        }

        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        scroll.addView(root)

        enableSwitch = Switch(this).apply {
            text = "Enable lock foreground service"
            isChecked = store.serviceEnabled()
            setOnCheckedChangeListener { _, checked ->
                store.setServiceEnabled(checked)
                if (checked) startLockService() else stopLockService()
            }
        }
        root.addView(enableSwitch)

        val importBtn = Button(this).apply {
            text = "Import image"
            setOnClickListener { pickImage() }
        }
        root.addView(importBtn)

        val modeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("SEQUENTIAL","RANDOM"))
            setSelection(if (store.rotationMode() == "RANDOM") 1 else 0)
            onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                    store.setRotationMode(if (position==1) "RANDOM" else "SEQUENTIAL")
                }
                override fun onNothingSelected(parent: AdapterView<*>) {}
            }
        }
        root.addView(TextView(this).apply{ text="Rotation mode"})
        root.addView(modeSpinner)

        grid = GridLayout(this).apply {
            columnCount = 3
        }
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val showLock = Button(this).apply {
            text = "Show lock now"
            setOnClickListener {
                val i = Intent(this@MainActivity, GatekeeperService::class.java).apply {
                    action = "SHOW_LOCK_NOW"
                }
                if (Build.VERSION.SDK_INT >= 26) {
                    this@MainActivity.startForegroundService(i)
                } else startService(i)
            }
        }
        root.addView(showLock)

        setContentView(scroll)
        refreshGrid()

        if (enableSwitch.isChecked) startLockService()
    }

    private fun startLockService() {
        val i = Intent(this, GatekeeperService::class.java).apply { action = "START_FG" }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        DebugToasts.toast("Requested start foreground service")
    }
    private fun stopLockService() {
        val i = Intent(this, GatekeeperService::class.java).apply { action = "STOP_FG" }
        startService(i)
        DebugToasts.toast("Requested stop foreground service")
    }

    private fun pickImage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(intent, 1001)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == Activity.RESULT_OK) {
            val uri: Uri? = data?.data
            if (uri != null) {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                // ask for password
                // ask for password via simple dialog
                val et = android.widget.EditText(this)
                et.hint = "为该图片设置密码"
                android.app.AlertDialog.Builder(this)
                    .setTitle("设置图片密码")
                    .setView(et)
                    .setPositiveButton("保存") { _, _ ->
                        val pwd = et.text?.toString() ?: ""
                        store.add(ImageItem(uri.toString(), pwd))
                        DebugToasts.toast("Imported image")
                        refreshGrid()
                    }
                    .setNegativeButton("取消", null)
                    .show()
            }
        }
    }

    private fun refreshGrid() {
        grid.removeAllViews()
        val imgs = store.list()
        if (imgs.isEmpty()) {
            grid.addView(TextView(this).apply{ text="No images imported yet" })
            return
        }
        imgs.forEachIndexed { index, item ->
            val frame = FrameLayout(this)
            val iv = ImageView(this).apply {
                setImageURI(Uri.parse(item.uri))
                adjustViewBounds = true
                layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    height = 300
                }
                setOnClickListener {
                    // simple bounce
                    it.animate().scaleX(1.05f).scaleY(1.05f).setDuration(80).withEndAction {
                        it.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                    }.start()
                }
                setOnLongClickListener {
                    val options = arrayOf("编辑密码","删除")
                    android.app.AlertDialog.Builder(this@MainActivity)
                        .setItems(options) { _, which ->
                            if (which==0) {
                                val et = android.widget.EditText(this@MainActivity)
                                et.setText(item.password)
                                android.app.AlertDialog.Builder(this@MainActivity)
                                    .setTitle("编辑密码")
                                    .setView(et)
                                    .setPositiveButton("保存") { _, _ ->
                                        store.update(index, ImageItem(item.uri, et.text?.toString() ?: ""))
                                        refreshGrid()
                                    }
                                    .setNegativeButton("取消", null)
                                    .show()
                            } else {
                                store.delete(index)
                                refreshGrid()
                            }
                        }.show()
                    true
                }
            }
            frame.addView(iv)
            // show password as hint
            val tv = TextView(this).apply {
                text = "PWD: ${item.password}"
                setBackgroundColor(0x55FFFFFF)
                setPadding(6,6,6,6)
            }
            frame.addView(tv)
            grid.addView(frame)
        }
    }
}
