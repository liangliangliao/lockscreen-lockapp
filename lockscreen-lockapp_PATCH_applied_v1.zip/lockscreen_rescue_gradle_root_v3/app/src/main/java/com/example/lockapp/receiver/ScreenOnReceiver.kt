
package com.example.lockapp.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import com.example.lockapp.service.GatekeeperService
import com.example.lockapp.util.DebugToasts

class ScreenOnReceiver: BroadcastReceiver() { 
    override fun onReceive(context: Context, intent: Intent?) {
        if (Intent.ACTION_SCREEN_ON == intent?.action) {
            // Ask service to show lock
            val i = Intent(context, GatekeeperService::class.java).apply { action = "SHOW_LOCK_NOW" }
            context.startService(i)
            DebugToasts.toast("screen on -> showing lock")
        }
    }
}
