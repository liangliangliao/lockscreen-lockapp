
package com.example.lockapp.data

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

data class ImageItem(var uri: String, var password: String)

class ImageStore(private val context: Context) { 
    private val prefs = context.getSharedPreferences("lock_store", Context.MODE_PRIVATE)

    fun list(): MutableList<ImageItem> { 
        val raw = prefs.getString("images_json", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val out = mutableListOf<ImageItem>()
        for (i in 0 until arr.length()) { 
            val o = arr.getJSONObject(i)
            out.add(ImageItem(o.optString("uri"), o.optString("password")))
        }
        return out
    }

    private fun save(list: List<ImageItem>) {
        val arr = JSONArray()
        list.forEach { 
            val o = JSONObject()
            o.put("uri", it.uri)
            o.put("password", it.password)
            arr.put(o)
        }
        prefs.edit().putString("images_json", arr.toString()).apply()
    }

    fun add(item: ImageItem) {
        val l = list()
        l.add(item)
        save(l)
    }
    fun update(index: Int, item: ImageItem) {
        val l = list()
        if (index in l.indices) { l[index] = item; save(l) }
    }
    fun delete(index: Int) {
        val l = list()
        if (index in l.indices) { l.removeAt(index); save(l) }
    }

    fun rotationMode(): String = prefs.getString("rotation_mode", "SEQUENTIAL") ?: "SEQUENTIAL"
    fun setRotationMode(mode: String) { prefs.edit().putString("rotation_mode", mode).apply() }

    fun lastIndex(): Int = prefs.getInt("last_index", -1)
    private fun setLastIndex(i: Int) { prefs.edit().putInt("last_index", i).apply() }

    fun getCurrentImageUri(): String? {
        val imgs = list()
        if (imgs.isEmpty()) return null
        val li = lastIndex()
        if (li in imgs.indices) return imgs[li].uri
        // first time, return index 0 without advancing
        setLastIndex(0)
        return imgs[0].uri
    }

    fun getPasswordForCurrent(): String? {
        val imgs = list()
        val li = lastIndex().coerceAtLeast(0)
        return if (li in imgs.indices) imgs[li].password else null
    }

    fun advanceAfterUnlock() {
        val imgs = list()
        if (imgs.isEmpty()) return
        val mode = rotationMode()
        val next = when (mode) {
            "RANDOM" -> (imgs.indices).random()
            else -> ((lastIndex().coerceAtLeast(0)) + 1) % imgs.size
        }
        setLastIndex(next)
    }

    fun serviceEnabled(): Boolean = prefs.getBoolean("service_enabled", false)
    fun setServiceEnabled(enabled: Boolean) { prefs.edit().putBoolean("service_enabled", enabled).apply() }
    fun onboardingDone(): Boolean = prefs.getBoolean("onboarding_done", false)
    fun setOnboardingDone(done: Boolean) { prefs.edit().putBoolean("onboarding_done", done).apply() }
}
