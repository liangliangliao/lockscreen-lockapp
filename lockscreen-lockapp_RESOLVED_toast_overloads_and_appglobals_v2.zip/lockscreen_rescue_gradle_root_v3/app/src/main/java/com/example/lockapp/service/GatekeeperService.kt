package com.example.lockapp.service

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.lockapp.R
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.util.DebugToasts

class GatekeeperService : Service() {

    companion object {
        const val CHANNEL_FG = "lock_fg"
        const val CHANNEL_FSI = "lock_fsi"
        const val NOTIF_ID_FG = 1001
        const val NOTIF_ID_FSI = 1002

        const val ACTION_SHOW_LOCK_NOW = "com.example.lockapp.action.SHOW_LOCK_NOW"
    }

    private var screenReceiverRegistered = false

    private val screenOnReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.action ?: return
            when (action) {
                Intent.ACTION_SCREEN_ON -> {
                    DebugToasts.toast(context, "screen on -> showing lock")
                    postFullScreenLock(context)
                }
                Intent.ACTION_USER_PRESENT -> {
                    DebugToasts.toast(context, "user present")
                }
                Intent.ACTION_SCREEN_OFF -> {
                    DebugToasts.toast(context, "screen off")
                }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        startForeground(NOTIF_ID_FG, buildForegroundNotification())
        DebugToasts.toast(this, "gatekeeperservice started")

        // dynamic register screen events (manifest receivers won't get these on O+)
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        registerReceiver(screenOnReceiver, filter)
        screenReceiverRegistered = true
        DebugToasts.toast(this, "receiver registered")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW_LOCK_NOW -> {
                DebugToasts.toast(this, "show lock (action)")
                postFullScreenLock(this)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        if (screenReceiverRegistered) {
            try { unregisterReceiver(screenOnReceiver) } catch (_: Exception) {}
            screenReceiverRegistered = false
        }
        super.onDestroy()
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val fg = NotificationChannel(
                CHANNEL_FG, "Lock Foreground", NotificationManager.IMPORTANCE_LOW
            )
            nm.createNotificationChannel(fg)

            val fsi = NotificationChannel(
                CHANNEL_FSI, "Lock FullScreen", NotificationManager.IMPORTANCE_HIGH
            ).apply {
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                enableVibration(true)
            }
            nm.createNotificationChannel(fsi)
        }
    }

    private fun buildForegroundNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, LockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        return NotificationCompat.Builder(this, CHANNEL_FG)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Lock running")
            .setContentText("Listening for screen on")
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
    }

    private fun postFullScreenLock(context: Context) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val contentIntent = Intent(context, LockScreenActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        val fsiPi = PendingIntent.getActivity(
            context, 1, contentIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        val callStyle = NotificationCompat.Builder(context, CHANNEL_FSI)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Lock Screen")
            .setContentText("Tap to unlock")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setFullScreenIntent(fsiPi, true)
            .setAutoCancel(true)
            .build()

        nm.notify(NOTIF_ID_FSI, callStyle)
        DebugToasts.toast(context, "full-screen notification posted")
    }
}
