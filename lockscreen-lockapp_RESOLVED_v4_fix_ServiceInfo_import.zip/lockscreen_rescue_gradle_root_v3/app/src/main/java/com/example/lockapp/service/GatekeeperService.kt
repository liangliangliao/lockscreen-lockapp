package com.example.lockapp.service

import android.app.*
import android.content.*
import android.os.Build
import android.os.IBinder
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import com.example.lockapp.R
import com.example.lockapp.util.DebugToasts
import com.example.lockapp.LockScreenActivity
import android.content.pm.ServiceInfo

class GatekeeperService : Service() {

    private val channelId = "gk_foreground"
    private val alertChannelId = "gk_alerts"

    private var screenReceiver: BroadcastReceiver? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        val notif = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_lock_patch)
            .setContentTitle("LockApp service")
            .setContentText("Watching for screen-on")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()

        // Android 14+ must specify a foreground service type + have matching manifest permission
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                1,
                notif,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(1, notif)
        }
        DebugToasts.toast("GatekeeperService started (FGS: DATA_SYNC)")

        registerScreenReceiver()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "ACTION_POST_LOCK") {
            postFullScreenLock()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            if (screenReceiver != null) unregisterReceiver(screenReceiver)
        } catch (_: Throwable) {}
        DebugToasts.toast("GatekeeperService destroyed")
    }

    private fun registerScreenReceiver() {
        if (screenReceiver != null) return
        screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (Intent.ACTION_SCREEN_ON == intent.action) {
                    DebugToasts.toast("screen on -> showing lock")
                    postFullScreenLock()
                }
            }
        }
        val f = IntentFilter(Intent.ACTION_SCREEN_ON)
        registerReceiver(screenReceiver, f)
        DebugToasts.toast("receiver registered (ACTION_SCREEN_ON)")
    }

    private fun postFullScreenLock() {
        // PendingIntent to open LockScreenActivity in full-screen
        val lockIntent = Intent(this, LockScreenActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        val pi = PendingIntent.getActivity(
            this, 101, lockIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        val n = NotificationCompat.Builder(this, alertChannelId)
            .setSmallIcon(R.drawable.ic_lock_patch)
            .setContentTitle("Unlock required")
            .setContentText("Tap to unlock")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setFullScreenIntent(pi, true)
            .setOngoing(false)
            .build()

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(42, n)
        DebugToasts.toast("full-screen notification posted")
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val fg = NotificationChannel(channelId, "Gatekeeper Service", NotificationManager.IMPORTANCE_MIN)
            nm.createNotificationChannel(fg)
            val alerts = NotificationChannel(alertChannelId, "Lock Alerts", NotificationManager.IMPORTANCE_HIGH)
            nm.createNotificationChannel(alerts)
        }
    }
}