package com.example.lockapp.data

import android.content.Context
import android.net.Uri
import android.preference.PreferenceManager
import kotlin.random.Random

class ImageStore(private val context: Context) {
    private val prefs = PreferenceManager.getDefaultSharedPreferences(context)
    private val KEY_LIST = "image_list_uris"
    private val KEY_LAST_INDEX = "image_last_index"
    private val KEY_ROTATION = "image_rotation_mode" // SEQUENTIAL or RANDOM

    fun getRotationMode(): RotationMode {
        val raw = prefs.getString(KEY_ROTATION, RotationMode.SEQUENTIAL.name) ?: RotationMode.SEQUENTIAL.name
        return try { RotationMode.valueOf(raw) } catch (_: Throwable) { RotationMode.SEQUENTIAL }
    }
    fun setRotationMode(mode: RotationMode) {
        prefs.edit().putString(KEY_ROTATION, mode.name).apply()
    }

    fun getList(): List<String> {
        val csv = prefs.getString(KEY_LIST, "") ?: ""
        return csv.split("|").filter { it.isNotBlank() }
    }
    fun setList(uris: List<String>) {
        prefs.edit().putString(KEY_LIST, uris.joinToString("|")).apply()
        if (getLastIndex() !in uris.indices) setLastIndex(0)
    }

    fun getLastIndex(): Int = prefs.getInt(KEY_LAST_INDEX, 0)
    fun setLastIndex(idx: Int) { prefs.edit().putInt(KEY_LAST_INDEX, idx).apply() }

    /**
     * If [advance] is false, return current image; if true, move to next based on rotation mode,
     * persist lastIndex, and return the picked Uri. If list empty, returns null.
     */
    fun pickImage(advance: Boolean): Uri? {
        val list = getList()
        if (list.isEmpty()) return null
        val last = getLastIndex()
        val nextIdx = when (getRotationMode()) {
            RotationMode.SEQUENTIAL -> if (advance) (last + 1).mod(list.size) else last.coerceIn(0, list.size - 1)
            RotationMode.RANDOM -> if (advance) Random.nextInt(list.size) else last.coerceIn(0, list.size - 1)
        }
        if (advance) setLastIndex(nextIdx)
        return Uri.parse(list[nextIdx])
    }
}
