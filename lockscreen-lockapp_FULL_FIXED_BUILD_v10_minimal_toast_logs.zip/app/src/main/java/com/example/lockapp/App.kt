package com.example.lockapp

import android.app.Application
import android.widget.Toast
import com.example.lockapp.util.DebugLog

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Toast.makeText(this, "LockApp 已启动（源码改动已生效）", Toast.LENGTH_LONG).show()
        DebugLog.w("App", "应用已启动（Application.onCreate） → 已弹出 Toast 提示")
    }
}