package com.example.lockapp.data

import androidx.room.Database
import androidx.room.RoomDatabase

/**
 * Central database for the lock screen app. Holds a single table storing image/password
 * associations. Version 1 as there are currently no migrations to perform.
 */
@Database(entities = [ImagePassword::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    /** Provides access to [ImagePasswordDao] for reading and writing entries. */
    abstract fun imagePasswordDao(): ImagePasswordDao
}