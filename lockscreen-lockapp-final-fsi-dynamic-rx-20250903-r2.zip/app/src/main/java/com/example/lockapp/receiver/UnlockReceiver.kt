package com.example.lockapp.receiver
import android.app.Notification
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.R
import com.example.lockapp.data.LockConfigStore
import com.example.lockapp.ui.LockActivity
import com.example.lockapp.util.GateXPrefs
import com.example.lockapp.util.NotifyHelper
class UnlockReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_USER_PRESENT) return
        val tag = "UnlockReceiver"
        Log.d(tag, "ACTION_USER_PRESENT received")
        val armed = try { LockConfigStore.isArmed(context) } catch (_: Throwable) { true }
        val pending = GateXPrefs.consumePending(context)
        Log.d(tag, "armed=$armed pending=$pending")
        if (!armed || !pending) return
        val channelId = "lock_fsi"
        NotifyHelper.ensureHighChannel(context, channelId, "Lock Gate", "Full screen lock gate")
        val toLock = Intent(context, LockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("forceShow", true)
            putExtra("plainText", true)
            putExtra("fromFSI", true)
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        val pi = PendingIntent.getActivity(context, 1001, toLock, flags)
        val nb = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle(context.getString(R.string.app_name))
            .setContentText("Unlock required")
            .setCategory(Notification.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .setOngoing(true)
            .setFullScreenIntent(pi, true)
        NotificationManagerCompat.from(context).notify(99, nb.build())
    }
}
