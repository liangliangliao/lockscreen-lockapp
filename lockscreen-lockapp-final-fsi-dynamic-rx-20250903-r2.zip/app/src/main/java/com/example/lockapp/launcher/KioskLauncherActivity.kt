package com.example.lockapp.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.example.lockapp.data.LockConfigStore
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.ui.LockActivity

/**
 * HOME launcher activity used when the app is the default launcher (Device Owner kiosk).
 * It decides whether to show our LockActivity (if armed & requireUnlock) or fall back to
 * the normal system home. If not device owner / not default launcher, it just finishes.
 */
class KioskLauncherActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
    }

    override fun onResume() {
        super.onResume()
        route()
    }

    private fun route() {
        val armed = LockConfigStore.isArmed(this)
        val need = LockStateStore.isRequireUnlock(this)
        if (armed && need) {
            // Bring up our full-screen lock.
            startActivity(Intent(this, LockActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            })
        } else {
            // Nothing to do
        }
        finish()
    }
}
