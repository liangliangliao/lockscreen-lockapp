// BUILD TAG: LOCKAPP-FIX-LOCKGUARD-20250907
package com.example.app.patchlock

import android.app.Service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.LockScreenActivity

class LockGuardService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Post a minimal high-priority notification with Full-Screen Intent if needed
        postFullScreen()
        stopSelf()
        return START_NOT_STICKY
    }

    private fun ensureChannel(ctx: Context, id: String, name: String, importance: Int) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm?.getNotificationChannel(id) == null) {
                nm?.createNotificationChannel(NotificationChannel(id, name, importance))
            }
        }
    }

    private fun postFullScreen() {
        val ctx = this
        val channelId = "lockguard_fsi"
        ensureChannel(ctx, channelId, "LockGuard FullScreen", NotificationManager.IMPORTANCE_HIGH)

        val contentIntent = PendingIntent.getActivity(
            ctx, 2002,
            Intent(ctx, LockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0) or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val n: Notification = NotificationCompat.Builder(ctx, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Unlock required")
            .setContentText("Tap to open lock screen")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(Notification.CATEGORY_CALL)
            .setAutoCancel(true)
            .setFullScreenIntent(contentIntent, true)
            .build()

        NotificationManagerCompat.from(ctx).notify(2002, n)
    }
}
