package com.example.lockapp

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import com.example.lockapp.ui.LiveLockScreen

class LauncherActivity : ComponentActivity() {
    private fun hardenIfDeviceOwner() {
        try {
            val dpm = getSystemService(android.app.admin.DevicePolicyManager::class.java)
            val comp = android.content.ComponentName(this, com.example.lockapp.admin.MyDeviceAdminReceiver::class.java)
            if (dpm != null && dpm.isDeviceOwnerApp(packageName)) {
                // 禁用系统锁屏 & 状态栏 & 限制系统特性
                dpm.setKeyguardDisabled(comp, true)
                try { dpm.setStatusBarDisabled(comp, true) } catch (_: Throwable) {}
                try { if (android.os.Build.VERSION.SDK_INT >= 28) dpm.setLockTaskFeatures(comp, 0) } catch (_: Throwable) {}
                dpm.setLockTaskPackages(comp, arrayOf(packageName))
                try { startLockTask() } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }

    private fun startEmergencyDialer() {
        val intents = listOf(
            Intent("android.intent.action.DIAL_EMERGENCY"),
            Intent("com.android.phone.EmergencyDialer.DIAL"),
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:112"))
        )
        for (it in intents) {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (it.resolveActivity(packageManager) != null) {
                try {
                    // 临时退出屏幕固定可能由系统接管，返回时我们会再次受 SCREEN_ON 拉回门禁
                    try { stopLockTask() } catch (_: Throwable) {}
                    startActivity(it)
                    return
                } catch (_: Throwable) {}
            }
        }
    }

    private fun tryRequestIgnoreBattery() {
        try {
            val pm = getSystemService(android.os.PowerManager::class.java)
            if (pm != null && !pm.isIgnoringBatteryOptimizations(packageName)) {
                val it = Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                it.data = android.net.Uri.parse("package:$packageName")
                startActivity(it)
            }
        } catch (_: Throwable) {}
    }

    private fun tryEnterKiosk()
        hardenIfDeviceOwner()
        try {
            val dpm = getSystemService(android.app.admin.DevicePolicyManager::class.java)
            val comp = android.content.ComponentName(this, com.example.lockapp.admin.MyDeviceAdminReceiver::class.java)
            if (dpm != null && dpm.isDeviceOwnerApp(packageName)) {
                dpm.setKeyguardDisabled(comp, true)
                dpm.setLockTaskPackages(comp, arrayOf(packageName))
            }
        } catch (_: Throwable) {} {
        try {
            val dpm = getSystemService(android.app.admin.DevicePolicyManager::class.java)
            val comp = android.content.ComponentName(this, com.example.lockapp.admin.MyDeviceAdminReceiver::class.java)
            if (dpm != null && dpm.isDeviceOwnerApp(packageName)) {
                dpm.setLockTaskPackages(comp, arrayOf(packageName))
                startLockTask()
            } else {
                // If not DO, user-initiated screen pin prompt may appear on startLockTask()
                startLockTask()
            }
        } catch (t: Throwable) {
            // ignore
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        tryEnterKiosk()
        hardenIfDeviceOwner()
        try {
            val dpm = getSystemService(android.app.admin.DevicePolicyManager::class.java)
            val comp = android.content.ComponentName(this, com.example.lockapp.admin.MyDeviceAdminReceiver::class.java)
            if (dpm != null && dpm.isDeviceOwnerApp(packageName)) {
                dpm.setKeyguardDisabled(comp, true)
                dpm.setLockTaskPackages(comp, arrayOf(packageName))
            }
        } catch (_: Throwable) {}
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val force = intent.getBooleanExtra("forceLock", false)
        val locked = com.example.lockapp.data.LockStateStore.isLocked(this)
        if (!force && !locked) {
            startActivity(Intent(this, MainActivity::class.java).apply { addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK) })
            finish(); return
        }
        setContent {
            LiveLockScreen(
                onUnlock = {
                        try { getSystemService(android.app.KeyguardManager::class.java)?.requestDismissKeyguard(this, null) } catch (_: Throwable) {}
                        com.example.lockapp.data.LockStateStore.setLocked(this, false);
                    startActivity(Intent(this, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
                    })
                    finish()
                }
            )
        }
    }
}
