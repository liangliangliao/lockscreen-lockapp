package com.example.lockapp.data

import android.content.Context

/**
 * Single source of truth for active lock wallpaper (uri) and password.
 * Provides both canonical API (set/getUri/getPwd) and backward-compatible aliases (getActiveUri/setActive).
 */
object ActiveLockStore {
    private const val PREF = "active_lock_store"
    private const val KEY_URI = "uri"
    private const val KEY_PWD = "pwd"

    /** Canonical setter: update both uri and password (nullable allowed). */
    fun set(context: Context, uri: String?, password: String?) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_URI, uri)
            .putString(KEY_PWD, password)
            .apply()
    }

    /** Canonical getters. */
    fun getUri(context: Context): String? =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_URI, null)

    fun getPwd(context: Context): String? =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_PWD, null)

    /** Backward-compatible aliases used by older code. */
    fun getActiveUri(context: Context): String? = getUri(context)

    /**
     * Legacy signature: setActive(context, id, uri). We ignore id here and only update uri,
     * keeping existing password untouched.
     */
    fun setActive(context: Context, id: String?, uri: String?) {
        val oldPwd = getPwd(context)
        set(context, uri, oldPwd)
    }
}
