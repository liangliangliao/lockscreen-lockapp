package com.example.lockapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.lockapp.service.GatekeeperService

/**
 * 亮屏静态接收器：只负责把前台服务拉起来，不直接起界面。
 */
class ScreenOnReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_SCREEN_ON -> {
                // （重新）拉起前台服务，后续由服务内的动态广播与逻辑去弹窗/刷新
                try {
                    ContextCompat.startForegroundService(
                        context,
                        Intent(context, GatekeeperService::class.java)
                    )
                } catch (_: Throwable) {}
            }
            else -> Unit
        }
    }
}
