package com.example.lockapp.wake

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.lockapp.service.GatekeeperService

/**
 * 精确闹钟唤醒接收器（若不需要闹钟兜底，也可以不在 manifest 注册）。
 * 这里只做“确保服务在位”，不直接起 UI。
 */
class AlarmWakeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION_ALARM_WAKE -> {
                try {
                    ContextCompat.startForegroundService(
                        context,
                        Intent(context, GatekeeperService::class.java)
                    )
                } catch (_: Throwable) {}
            }
            else -> Unit
        }
    }

    companion object {
        const val ACTION_ALARM_WAKE = "com.example.lockapp.ACTION_ALARM_WAKE"
    }
}
