package com.example.lockapp.data

import android.content.Context

/**
 * Single source of truth for active lock wallpaper (uri) and password.
 * Canonical API: set/getUri/getPwd
 * Legacy compatibility: getActiveUri/setActive overloads (String?/Long?/Any? id), id is ignored.
 */
object ActiveLockStore {
    private const val PREF = "active_lock_store"
    private const val KEY_URI = "uri"
    private const val KEY_PWD = "pwd"

    /** Canonical setter: update both uri and password (nullable allowed). */
    @JvmStatic
    fun set(context: Context, uri: String?, password: String?) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_URI, uri)
            .putString(KEY_PWD, password)
            .apply()
    }

    /** Canonical getters. */
    @JvmStatic
    fun getUri(context: Context): String? =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_URI, null)

    @JvmStatic
    fun getPwd(context: Context): String? =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_PWD, null)

    /** Legacy alias. */
    @JvmStatic
    fun getActiveUri(context: Context): String? = getUri(context)

    /** Legacy setters: ignore id, only update uri; keep password untouched. */
    @JvmStatic
    fun setActive(context: Context, id: String?, uri: String?) {
        val oldPwd = getPwd(context)
        set(context, uri, oldPwd)
    }

    @JvmStatic
    fun setActive(context: Context, id: Long?, uri: String?) {
        val oldPwd = getPwd(context)
        set(context, uri, oldPwd)
    }

    @JvmStatic
    fun setActive(context: Context, id: Any?, uri: String?) {
        val oldPwd = getPwd(context)
        set(context, uri, oldPwd)
    }
}
