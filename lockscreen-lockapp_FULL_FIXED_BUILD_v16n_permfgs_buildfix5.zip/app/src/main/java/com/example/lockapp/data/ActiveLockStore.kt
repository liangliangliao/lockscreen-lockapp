package com.example.lockapp.data

import android.content.Context

object ActiveLockStore {
    private const val PREF = "active_lock_store"
    private const val KEY_URI = "uri"
    private const val KEY_PWD = "pwd"

    fun set(context: Context, uri: String?, password: String?) {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        with(sp.edit()) {
            if (uri != null) putString(KEY_URI, uri)
            if (password != null) putString(KEY_PWD, password)
            apply()
        }
    }

    fun getUri(context: Context): String? =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_URI, null)

    fun getPwd(context: Context): String? =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_PWD, null)

    // Back-compat helpers used elsewhere
    fun setActive(context: Context, uri: String?, password: String?) = set(context, uri, password)
    fun getActiveUri(context: Context): String? = getUri(context)
    fun getActivePassword(context: Context): String? = getPwd(context)

    // Legacy overloads
    fun setActive(context: Context, id: Long, uri: String?) = set(context, uri, getPwd(context))
    fun setActive(context: Context, id: Any?, uri: String?) = set(context, uri, getPwd(context))
}
