// BUILD TAG: LOCKAPP-FSI-FIX-CI-20250907T021838Z
package com.example.lockapp.setup
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.content.Context
import android.content.Intent
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.lockapp.ui.theme.LockScreenAppTheme

class SetupActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LockScreenAppTheme {
                GuardSetupScreen(onAllDone = {
                    getSharedPreferences("onboarding", MODE_PRIVATE)
                        .edit().putBoolean("done", true).apply()
                    finish()
                })
            }
        }
    }
}
