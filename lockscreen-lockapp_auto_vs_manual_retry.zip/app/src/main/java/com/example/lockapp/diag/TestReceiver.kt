package com.example.lockapp.diag

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.lockapp.util.Diag
import com.example.lockapp.util.LockFsNotifier
import com.example.lockapp.ordered.WakeOrderedReceiver

/**
 * 诊断用广播接收器（可用 adb 触发）：
 * - com.example.lockapp.DIAG_WAKE_ORDERED  -> 直接触发有序广播链路（等价亮屏时的窗口）
 * - com.example.lockapp.DIAG_FSI_LOCK     -> 直接发锁屏 FSI
 * - com.example.lockapp.DIAG_FSI_REFRESH  -> 直接发刷新 FSI
 */
class TestReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            "com.example.lockapp.DIAG_WAKE_ORDERED" -> {
                try {
                    val br = Intent(WakeOrderedReceiver.ACTION_WAKE_ORDERED).addFlags(Intent.FLAG_RECEIVER_FOREGROUND)
                    context.sendOrderedBroadcast(br, null)
                    Diag.i("TestReceiver", "sent ACTION_WAKE_ORDERED (foreground ordered)")
                } catch (t: Throwable) { Diag.e("TestReceiver", "send wake ordered failed", t) }
            }
            "com.example.lockapp.DIAG_FSI_LOCK" -> {
                try { LockFsNotifier.showFullScreen(context); Diag.i("TestReceiver", "FSI lock dispatched") } catch (t: Throwable) { Diag.e("TestReceiver", "FSI lock failed", t) }
            }
            "com.example.lockapp.DIAG_FSI_REFRESH" -> {
                try { LockFsNotifier.showFullScreenRefresh(context); Diag.i("TestReceiver", "FSI refresh dispatched") } catch (t: Throwable) { Diag.e("TestReceiver", "FSI refresh failed", t) }
            }
        }
    }
}