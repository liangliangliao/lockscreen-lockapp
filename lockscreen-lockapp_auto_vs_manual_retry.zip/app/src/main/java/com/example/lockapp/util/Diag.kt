package com.example.lockapp.util

import android.util.Log

object Diag {
    private const val GLOBAL = "LOCKAPP"
    fun i(tag: String, msg: String) = Log.i("$GLOBAL/$tag", msg)
    fun d(tag: String, msg: String) = Log.d("$GLOBAL/$tag", msg)
    fun w(tag: String, msg: String, tr: Throwable? = null) { if (tr!=null) Log.w("$GLOBAL/$tag", msg, tr) else Log.w("$GLOBAL/$tag", msg) }
    fun e(tag: String, msg: String, tr: Throwable? = null) { if (tr!=null) Log.e("$GLOBAL/$tag", msg, tr) else Log.e("$GLOBAL/$tag", msg) }
}