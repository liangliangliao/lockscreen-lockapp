package com.example.lockapp.ordered

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.util.LockCoordinator
import com.example.lockapp.util.LockFsNotifier
import com.example.lockapp.util.LockVisibilityTracker
import com.example.lockapp.util.Diag

class WakeOrderedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (ACTION_WAKE_ORDERED != intent.action) return
        Diag.d("WakeOrderedReceiver", "onReceive: ACTION_WAKE_ORDERED, locked="+com.example.lockapp.util.LockCoordinator.isLocked(context))

        try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lockapp:wakeOrdered").apply { acquire(2000) }
        } catch (_: Throwable) {}

        if (!LockCoordinator.isLocked(context)) {
            try {
                val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
                launch?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                if (launch != null) Diag.d("WakeOrderedReceiver", "bring-to-front launcher"); context.startActivity(launch)
            } catch (_: Throwable) {}
            return
        }

        Handler(Looper.getMainLooper()).post {
            var started = false
            try {
                val i = Intent(context, LockScreenActivity::class.java)
                    .addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP
                    )
                    .setAction("com.example.lockapp.SHOW_LOCK")
                Diag.d("WakeOrderedReceiver", "startActivity LockScreenActivity attempt"); context.startActivity(i)
                started = true
            } catch (_: Throwable) {}

            if (!started || !LockVisibilityTracker.visible) {
                try { Diag.d("WakeOrderedReceiver", "FSI fallback from receiver"); LockFsNotifier.showFullScreen(context) } catch (_: Throwable) {}
            }
        }
    }
    companion object { const val ACTION_WAKE_ORDERED = "com.example.lockapp.ACTION_WAKE_ORDERED" }
}