package com.example.lockapp.util

import android.content.Context
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import kotlin.math.max

/**
 * 猜测屏幕熄灭是否来源于“自动息屏”(系统超时)还是“按电源键”
 * - 基于上次 ACTION_SCREEN_OFF 时间与系统 SCREEN_OFF_TIMEOUT 的比较
 * - 辅助参考 Doze/Idle 模式
 */
object ScreenOffHeuristics {
    @Volatile private var lastScreenOffAt: Long = 0L
    @Volatile private var lastScreenOnAt: Long = 0L
    @Volatile private var lastTriggerAt: Long = 0L

    fun markScreenOff(ts: Long = System.currentTimeMillis()) { lastScreenOffAt = ts }
    fun markScreenOn(ts: Long = System.currentTimeMillis()) { lastScreenOnAt = ts }

    /** 2 秒内的重复触发直接忽略，防抖 */
    fun shouldDebounce(now: Long = System.currentTimeMillis(), windowMs: Long = 2000): Boolean {
        if (now - lastTriggerAt < windowMs) return true
        lastTriggerAt = now
        return false
    }

    data class Result(val isAutoSleep: Boolean, val offDurationMs: Long, val sysTimeoutMs: Long)

    fun judge(context: Context, now: Long = System.currentTimeMillis()): Result {
        val offDur = if (lastScreenOffAt == 0L) 0L else max(0L, now - lastScreenOffAt)
        val sysTimeout = runCatching {
            Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT)
        }.getOrDefault(0)

        // 辅助：处于设备 idle 模式时更倾向于自动息屏
        val idleBonus = runCatching {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (Build.VERSION.SDK_INT >= 23 && pm.isDeviceIdleMode) 800L else 0L
        }.getOrDefault(0L)

        // 规则：如果 offDur 接近/超过 sysTimeout（-400ms 容差）或很长(>=8s) → 判为自动息屏
        val autoByTimeout = (sysTimeout > 0 && offDur + 400 >= sysTimeout) or (offDur >= 8000)
        val isAuto = autoByTimeout || (offDur + idleBonus >= 6000)

        return Result(isAutoSleep = isAuto, offDurationMs = offDur, sysTimeoutMs = sysTimeout.toLong())
    }
}