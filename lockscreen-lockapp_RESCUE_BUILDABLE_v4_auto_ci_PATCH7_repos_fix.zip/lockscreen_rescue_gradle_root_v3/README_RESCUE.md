# Rescue Gradle Root for lockscreen-lockapp

This folder adds the missing **settings.gradle** and root **build.gradle** so that CI can find a Gradle build
in the repository root. It keeps your `:app` module intact.

## How to use
1. Put **all files from this folder at the repository root** (the same folder GitHub Actions uses as working directory).
2. Make sure the root now contains: `settings.gradle`, `build.gradle`, `gradle/wrapper/gradle-wrapper.properties`, and the `app/` module.
3. Run locally: `./gradlew clean assembleDebug` (or `gradle` if wrapper is not used).

## Why you saw: "Directory does not contain a Gradle build"
Your CI executed Gradle in a directory that didn't have `settings.gradle`. Either:
- You were one folder above the actual project root, or
- The project root was missing `settings.gradle` / `build.gradle`.

This package fixes that by providing a valid Gradle root.
