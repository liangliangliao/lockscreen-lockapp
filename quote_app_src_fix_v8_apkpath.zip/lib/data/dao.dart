import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import 'db.dart';
import 'package:crypto/crypto.dart';
import 'dart:convert' as conv;

class QuoteDao {
  Future<int> insert(Map<String, dynamic> data) async {
    final db = await AppDatabase.instance();
    return db.insert('quotes', data, conflictAlgorithm: ConflictAlgorithm.ignore);
  }

  Future<Map<String, dynamic>?> latest() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('quotes', orderBy: 'created_at DESC', limit: 1);
    return rows.isEmpty ? null : rows.first;
  }

  Future<List<Map<String, dynamic>>> page({int offset = 0, int limit = 100}) async {
    final db = await AppDatabase.instance();
    return db.query('quotes', orderBy: 'created_at DESC', limit: limit, offset: offset);
  }

  Future<List<Map<String, dynamic>>> search(String q, {int offset = 0, int limit = 100}) async {
    final db = await AppDatabase.instance();
    if (q.trim().isEmpty) return page(offset: offset, limit: limit);
    final rows = await db.rawQuery(
        "SELECT q.* FROM fts_quotes f JOIN quotes q ON q.id = f.rowid WHERE f MATCH ? ORDER BY q.created_at DESC LIMIT ? OFFSET ?",
        [q, limit, offset]);
    return rows;
  }

  Future<void> seedDefaultQuote() async {
    final db = await AppDatabase.instance();
    const text = '凡是不能杀死我的，必使我更坚强。';
    const author = '弗里德里希·尼采';
    const source = '《偶像的黄昏》';
    final explanation = '尼采想表达的是：生活中的痛苦、挫折和困难，并不会彻底摧毁我们，反而会让我们成长，获得更强的韧性和力量。换句话说，经历苦难是让人更加坚强的重要途径。';
    final hash = md5.convert(conv.utf8.encode('$text|$author')).toString();
    final row = {
      'text': text,
      'author': author,
      'source': source,
      'lang': 'zh',
      'tags': jsonEncode(['解释：$explanation']),
      'prompt_id': 0,
      'created_at': DateTime.now().millisecondsSinceEpoch,
      'hash': hash,
    };
    await db.insert('quotes', row, conflictAlgorithm: ConflictAlgorithm.ignore);
  }
}

class ScheduleDao {
  Future<List<Map<String, dynamic>>> allEnabled() async {
    final db = await AppDatabase.instance();
    return db.query('schedules', where: 'enabled=1');
  }

  Future<int> upsert({int? id, required String type, required Map<String, dynamic> payload, bool enabled = true, int? nextRunAt}) async {
    final db = await AppDatabase.instance();
    final data = {
      'type': type,
      'payload': jsonEncode(payload),
      'enabled': enabled ? 1 : 0,
      'next_run_at': nextRunAt,
    };
    if (id != null) {
      return db.update('schedules', data, where: 'id=?', whereArgs: [id]);
    } else {
      return db.insert('schedules', data);
    }
  }

  Future<int> delete(int id) async {
    final db = await AppDatabase.instance();
    return db.delete('schedules', where: 'id=?', whereArgs: [id]);
  }

  Future<int> disable(int id) async {
    final db = await AppDatabase.instance();
    return db.update('schedules', {'enabled': 0}, where: 'id=?', whereArgs: [id]);
  }

  Future<int> updateNextRunAt({required int id, required int nextRunAt}) async {
    final db = await AppDatabase.instance();
    return db.update('schedules', {'next_run_at': nextRunAt, 'last_run_at': DateTime.now().millisecondsSinceEpoch}, where: 'id=?', whereArgs: [id]);
  }

  Future<List<Map<String, dynamic>>> dueSchedules(int nowMs) async {
    final db = await AppDatabase.instance();
    return db.query('schedules', where: 'enabled=1 AND next_run_at IS NOT NULL AND next_run_at<=?', whereArgs: [nowMs]);
  }

  Future<void> replaceAll(List<Map<String, dynamic>> items) async {
    final db = await AppDatabase.instance();
    await db.transaction((txn) async {
      await txn.delete('schedules');
      for (final s in items) {
        final type = s['type'] as String;
        final payload = s['payload'];
        final payloadStr = payload is String ? payload : jsonEncode(payload as Map<String, dynamic>);
        final enabled = (s['enabled'] ?? 1) as int;
        final nextRunAt = s['next_run_at'] as int?;
        await txn.insert('schedules', {
          'type': type,
          'payload': payloadStr,
          'enabled': enabled,
          'next_run_at': nextRunAt,
        });
      }
    });
  }
}

class SettingsDao {
  Future<Map<String, dynamic>?> getOne() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('settings', where: 'id=1', limit: 1);
    return rows.isEmpty ? null : rows.first;
  }

  Future<String?> getApiKey() async {
    final row = await getOne();
    return row == null ? null : (row['api_key'] as String?);
  }

  Future<int> updateApiKey(String? key) async {
    final db = await AppDatabase.instance();
    return db.update('settings', {'api_key': key ?? ''}, where: 'id=?', whereArgs: const [1]);
  }

  Future<bool> getAutoFetchEnabled() async {
    final row = await getOne();
    return row != null && (row['auto_fetch_enabled'] as int? ?? 0) == 1;
  }

  Future<int> updateAutoFetchEnabled(bool v) async {
    final db = await AppDatabase.instance();
    return db.update('settings', {'auto_fetch_enabled': v ? 1 : 0}, where: 'id=?', whereArgs: const [1]);
  }
}

class PromptDao {
  Future<String?> getDefaultContent() async {
    final db = await AppDatabase.instance();
    final rows = await db.query('prompts', where: 'is_default=1', orderBy: 'updated_at DESC', limit: 1);
    if (rows.isEmpty) return null;
    return rows.first['content'] as String?;
  }

  Future<void> upsertNewDefault(String content) async {
    final db = await AppDatabase.instance();
    final now = DateTime.now().millisecondsSinceEpoch;
    await db.transaction((txn) async {
      await txn.update('prompts', {'is_default': 0});
      await txn.insert('prompts', {
        'content': content,
        'is_default': 1,
        'updated_at': now,
      });
    });
  }
}
