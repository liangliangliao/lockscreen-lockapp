Kiosk / Device Owner provisioning (test device, data will be wiped):
1) Factory reset the device.
2) On a PC with adb:
   adb shell dpm set-device-owner com.example.lockapp/.admin.MyDeviceAdminReceiver
   (If 'not allowed' appears, the device is not freshly reset. Use QR or NFC provisioning instead.)
3) After DO is active, the app will enter LockTask automatically and act as default launcher gate.
4) To exit kiosk (for testing): adb shell dpm remove-active-admin com.example.lockapp/.admin.MyDeviceAdminReceiver
