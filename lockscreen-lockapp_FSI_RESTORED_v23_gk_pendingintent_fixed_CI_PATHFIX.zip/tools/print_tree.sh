#!/usr/bin/env bash
set -e
echo "==== PWD ===="
pwd
echo "==== TREE (depth 2) ===="
find . -maxdepth 2 -print
echo "==== Gradle files ===="
find . -name "settings.gradle*" -o -name "build.gradle*" -print
