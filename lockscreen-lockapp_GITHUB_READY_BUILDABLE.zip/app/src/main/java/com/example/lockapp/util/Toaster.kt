// BUILD TAG: LOCKAPP-FSI-FIX-CI-20250907T021838Z
package com.example.lockapp.util
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.content.Intent
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast

object Toaster {
    @JvmStatic
    fun show5s(ctx: Context, text: CharSequence, includeCaller: Boolean = true) {
        val msg = try { if (includeCaller) "$text — 来源: ${Caller.tag()}" else "$text" } catch (e: Throwable) { "$text" }
        val h = Handler(Looper.getMainLooper())
        // Post both segments to the main thread to avoid background-thread toast issues.
        h.post { try { Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show() } catch (_: Throwable) {} }
        h.postDelayed({ try { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() } catch (_: Throwable) {} }, 3500L)
    }
}