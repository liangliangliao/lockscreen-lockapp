import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    const android = AndroidInitializationSettings('@android:drawable/sym_def_app_icon');
    const init = InitializationSettings(android: android);
    await _plugin.initialize(init);
    const channel = AndroidNotificationChannel(
      'quote_channel', 'Quote Updates',
      description: 'Notifications for new quotes',
      importance: Importance.defaultImportance,
    );
    final an = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await an?.createNotificationChannel(channel);
  }

  static Future<void> showQuote(String text) async {
    const androidDetails = AndroidNotificationDetails(
      'quote_channel', 'Quote Updates',
      channelDescription: 'Notifications for new quotes',
      importance: Importance.defaultImportance,
      priority: Priority.defaultPriority,
      icon: '@android:drawable/sym_def_app_icon',
    );
    const details = NotificationDetails(android: androidDetails);
    await _plugin.show(1, '新的名人名言', text, details);
  }
}
