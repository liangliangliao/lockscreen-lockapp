package com.example.lockapp.diag

import android.os.Bundle
import androidx.activity.ComponentActivity
import com.example.lockapp.util.LockFsNotifier

class DebugActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Minimal debug heads-up so we know Activity works
        try { LockFsNotifier.showDebugHeadsUp(this, "调试", "DebugActivity 已启动") } catch (_: Throwable) {}
    }
}
