package com.example.lockapp.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents a single image/password entry. Each record stores the URI of an image in the
 * device's media storage and a password that grants access when that image is displayed on
 * the lock screen. An [orderIndex] is maintained to preserve the user-defined ordering of
 * images when rotating through them sequentially.
 */
@Entity(tableName = "ImagePassword")
data class ImagePassword(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val uri: String,
    val password: String,
    val orderIndex: Int = 0
)