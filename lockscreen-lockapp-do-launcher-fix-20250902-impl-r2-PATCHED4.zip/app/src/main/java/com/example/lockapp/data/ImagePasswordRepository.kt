package com.example.lockapp.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.first

/**
 * Repository over [ImagePasswordDao], providing higher-level operations.
 */
class ImagePasswordRepository(private val dao: ImagePasswordDao) {
    /** Reactive stream of all entries, ordered by orderIndex. */
    val entries: Flow<List<ImagePassword>> = dao.getAll()

    /** Insert or update an entry for [uri] with [password]. */
    suspend fun upsert(uri: String, password: String) = withContext(Dispatchers.IO) {
        val all = dao.getAll().first()
        val existing = all.firstOrNull { it.uri == uri }
        if (existing != null) {
            dao.update(existing.copy(password = password))
        } else {
            val nextIdx = (all.maxOfOrNull { it.orderIndex } ?: -1) + 1
            dao.upsert(ImagePassword(uri = uri, password = password, orderIndex = nextIdx))
        }
    }

    /** Delete an entry. */
    suspend fun delete(entry: ImagePassword) = withContext(Dispatchers.IO) {
        dao.delete(entry)
    }

    /** Fetch all entries once. */
    suspend fun getAllOnce(): List<ImagePassword> = withContext(Dispatchers.IO) {
        dao.getAll().first()
    }
}

/** Returns the first entry to use for locking UI (or null if none). */
suspend fun ImagePasswordRepository.getNextForLock(): ImagePassword? = getAllOnce().firstOrNull()
