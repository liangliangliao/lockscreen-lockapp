package com.example.lockapp.data

import android.content.Context

/**
 * Ephemeral flags stored in SharedPreferences.
 * - locked: legacy flag (kept for compat)
 * - requireUnlock: whether to present LockActivity next
 */
object LockStateStore {
    private const val PREF = "lock_state_prefs"
    private const val KEY_LOCKED = "locked"
    private const val KEY_REQUIRE = "require_unlock"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun isLocked(context: Context): Boolean = prefs(context).getBoolean(KEY_LOCKED, false)
    fun setLocked(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_LOCKED, value).apply()
        if (value) setRequireUnlock(context, true)
    }

    fun isRequireUnlock(context: Context): Boolean = prefs(context).getBoolean(KEY_REQUIRE, false)
    fun setRequireUnlock(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_REQUIRE, value).apply()
        if (!value) {
            prefs(context).edit().putBoolean(KEY_LOCKED, false).apply()
        }
    }
}
