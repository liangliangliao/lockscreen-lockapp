package com.example.lockapp.ui.theme

import androidx.compose.ui.graphics.Color

// Define some baseline colors used by the custom Material3 theme. These values are taken
// directly from the res/values/colors.xml resource definitions.
val Purple40 = Color(0xFF6650A4)
val Purple90 = Color(0xFFD0BCFF)
val Teal40 = Color(0xFF31827E)
val Teal90 = Color(0xFF47D3D3)
val Black = Color(0xFF000000)
val White = Color(0xFFFFFFFF)