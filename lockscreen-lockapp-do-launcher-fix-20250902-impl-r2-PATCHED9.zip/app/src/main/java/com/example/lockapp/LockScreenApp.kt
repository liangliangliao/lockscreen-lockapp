package com.example.lockapp

import android.app.Application
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.room.Room
import com.example.lockapp.data.AppDatabase

class LockScreenApp : Application() {
    lateinit var database: AppDatabase
        private set

    override fun onCreate() {
        super.onCreate()
        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "image_password.db"
        ).build()

        // observe app foreground/background
        val lifecycle = ProcessLifecycleOwner.get().lifecycle
        lifecycle.addObserver(LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> AppVisibilityTracker.setForeground(true)
                Lifecycle.Event.ON_STOP -> AppVisibilityTracker.setForeground(false)
                else -> {}
            }
        })
    }
}
