package com.example.lockapp.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.lockapp.data.LockConfigStore
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.service.GatekeeperService

/** Receives USER_PRESENT after keyguard unlock to wake the service and mark next unlock requirement. */
class UserPresentReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (LockConfigStore.isArmed(context)) {
            // Next time we return to app/launcher, require unlock
            LockStateStore.setRequireUnlock(context, true)
            // Start or wake the foreground service which will decide how to present UI
            ContextCompat.startForegroundService(
                context,
                Intent(context, GatekeeperService::class.java)
            )
        }
    }
}
