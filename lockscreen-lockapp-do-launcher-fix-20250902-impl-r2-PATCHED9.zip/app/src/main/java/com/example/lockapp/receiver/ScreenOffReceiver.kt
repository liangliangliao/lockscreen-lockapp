package com.example.lockapp.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.lockapp.data.ActiveLockStore
import com.example.lockapp.data.LockConfigStore
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.service.GatekeeperService

/**
 * Mark that next unlock should be intercepted by our app whenever screen goes off.
 * This runs even if the app is in background.
 */
class ScreenOffReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_SCREEN_OFF) return
        if (!LockConfigStore.isArmed(context)) return
        val pwd = ActiveLockStore.getPwd(context) ?: return
        if (pwd.isEmpty()) return

        Log.d("ScreenOffReceiver", "Screen turned off -> arm next unlock")
        LockStateStore.setRequireUnlock(context, true)

        // Make sure our service is alive so that we can raise the full-screen UI on USER_PRESENT
        try {
            ContextCompat.startForegroundService(context, Intent(context, GatekeeperService::class.java))
        } catch (_: Throwable) {
            try { context.startService(Intent(context, GatekeeperService::class.java)) } catch (_: Throwable) {}
        }
    }
}
