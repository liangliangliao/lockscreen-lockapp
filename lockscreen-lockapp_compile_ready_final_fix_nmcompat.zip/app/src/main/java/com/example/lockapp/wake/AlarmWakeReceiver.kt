package com.example.lockapp.wake

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.lockapp.service.GatekeeperService

/**
 * 兜底闹钟：唤醒后拉起前台服务，交由 GatekeeperService 走弹窗链路。
 * 如不需要闹钟兜底，可不在代码里调用 scheduleExact()/cancel()。
 */
class AlarmWakeReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_LOCK_WAKE) {
            try {
                ContextCompat.startForegroundService(
                    context,
                    Intent(context, GatekeeperService::class.java)
                )
            } catch (t: Throwable) {
                Log.e(TAG, "startForegroundService failed", t)
            }
        }
    }

    companion object {
        private const val TAG = "AlarmWakeReceiver"
        const val ACTION_LOCK_WAKE = "com.example.lockapp.ACTION_LOCK_WAKE"
        private const val REQ_CODE = 3101

        private fun pendingIntent(ctx: Context): PendingIntent {
            val flags =
                if (Build.VERSION.SDK_INT >= 23)
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                else 0
            return PendingIntent.getBroadcast(
                ctx,
                REQ_CODE,
                Intent(ctx, AlarmWakeReceiver::class.java).setAction(ACTION_LOCK_WAKE),
                flags
            )
        }

        /** 调度一次精确闹钟（毫秒时间戳）。Android 12+ 需精确闹钟特殊访问。 */
        fun scheduleExact(ctx: Context, triggerAtMillis: Long) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = pendingIntent(ctx)
            if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
            } else {
                @Suppress("DEPRECATION")
                am.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
            }
        }

        /** 取消已设置的闹钟。 */
        fun cancel(ctx: Context) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(pendingIntent(ctx))
        }
    }
}