// BUILD TAG: LOCKAPP-FSI-FIX-CI-20250907T031900Z
package com.example.lockapp.service
import com.example.lockapp.R

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.util.DebugLog

class GatekeeperService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Keep service extremely simple for CI build; start a transient foreground notification to improve reliability
        try {
            val n = buildKeepAliveNotification(this)
            startForeground(1903, n)
            stopForeground(true)
        } catch (_: Throwable) {}
        return START_NOT_STICKY
    }

    private fun ensureChannel(ctx: Context, channelId: String) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm?.getNotificationChannel(channelId) == null) {
                nm?.createNotificationChannel(NotificationChannel(channelId, "LockApp GK", NotificationManager.IMPORTANCE_MIN))
            }
        }
    }

    private fun buildKeepAliveNotification(ctx: Context): Notification {
        val ch = "lock_temp_keepalive"
        ensureChannel(ctx, ch)
        val pi = PendingIntent.getActivity(
            ctx, 1903,
            Intent(ctx, LockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0) or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(ctx, ch)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("Lock service active")
            .setContentText("Boosting reliability briefly")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(pi)
            .build()
    }
}
