// BUILD TAG: LOCKAPP-FIX-LGFG-20250907
package com.example.lockapp.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.LockScreenActivity

class LockGuardFgService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureChannel()
        val pi = PendingIntent.getActivity(
            this, 1910,
            Intent(this, LockScreenActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0) or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CH_ID)
            .setSmallIcon(android.R.mipmap.ic_launcher)
            .setContentTitle("Lock service running")
            .setContentText("Keeping lock active")
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
        startForeground(NOTIF_ID, n)
        return START_STICKY
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm?.getNotificationChannel(CH_ID) == null) {
                nm?.createNotificationChannel(
                    NotificationChannel(CH_ID, CH_NAME, NotificationManager.IMPORTANCE_LOW)
                )
            }
        }
    }

    companion object {
        private const val CH_ID = "lockguard_fg"
        private const val CH_NAME = "LockGuard Foreground"
        private const val NOTIF_ID = 1910
    }
}
