// BUILD TAG: LOCKAPP-FIX-MAINACT-20250907
package com.example.lockapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import com.example.lockapp.util.DebugLog

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DebugLog.w("MainActivity", "started")
    }
}
