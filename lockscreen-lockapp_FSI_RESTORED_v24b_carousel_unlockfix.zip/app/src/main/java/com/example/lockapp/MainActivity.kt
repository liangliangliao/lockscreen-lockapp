// BUILD TAG: LOCKAPP-RESTORE-UI-ENTRY-20250907
package com.example.lockapp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.lockapp.ui.MainScreen
import com.example.lockapp.ui.MainViewModel
import com.example.lockapp.ui.MainViewModelFactory
import com.example.lockapp.setup.GuardSetupScreen
import com.example.lockapp.ui.theme.LockScreenAppTheme
import com.example.lockapp.util.DebugLog

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DebugLog.w("MainActivity", "started (compose entry)")

        setContent {
            LockScreenAppTheme {
                val app = application as LockScreenApp
                val vm: MainViewModel = viewModel(factory = MainViewModelFactory(app))

                var showGuide by remember { mutableStateOf(needsPermissionGuide()) }
                if (showGuide) {
                    GuardSetupScreen(onAllDone = { showGuide = false })
                } else {
                    MainScreen(viewModel = vm)
                }
            }
        }
    }

    private fun needsPermissionGuide(): Boolean {
        // For Android 13+ ask for notifications; for images access, flows are handled inside UI/importer.
        if (Build.VERSION.SDK_INT >= 33) {
            val notif = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            if (notif != PackageManager.PERMISSION_GRANTED) return true
        }
        return false
    }
}
