// BUILD TAG: LOCKAPP-FSI-FIX-CI-20250907T021838Z
package com.example.lockapp.data
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.content.Context
import android.content.Intent
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.Room

/**
 * Central database for the lock screen app. Holds a single table storing image/password
 * associations. Version 1 as there are currently no migrations to perform.
 */
@Database(entities = [ImagePassword::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    /** Provides access to [ImagePasswordDao] for reading and writing entries. */
    abstract fun imagePasswordDao(): ImagePasswordDao
}

fun getAppDb(context: Context): AppDatabase =
    Room.databaseBuilder(context, AppDatabase::class.java, "lockapp.db")
        .fallbackToDestructiveMigration()
        .build()
