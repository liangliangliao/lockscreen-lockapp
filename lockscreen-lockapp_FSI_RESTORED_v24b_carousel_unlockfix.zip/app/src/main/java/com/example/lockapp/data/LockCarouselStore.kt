package com.example.lockapp.data

import android.content.Context

/**
 * Stores lock-screen carousel state:
 * - currentIndex: the image index chosen for the current lock session (stays the same across
 *   repeated screen-on events until a successful unlock).
 * - lastUnlockedIndex: the image index that was last unlocked successfully
 */
object LockCarouselStore {
    private const val PREF = "lock_carousel_store"
    private const val KEY_CURRENT_INDEX = "current_index"
    private const val KEY_LAST_UNLOCKED = "last_unlocked_index"

    fun getCurrentIndex(context: Context): Int =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getInt(KEY_CURRENT_INDEX, -1)

    fun setCurrentIndex(context: Context, value: Int) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putInt(KEY_CURRENT_INDEX, value).apply()
    }

    fun clearCurrentIndex(context: Context) = setCurrentIndex(context, -1)

    fun getLastUnlockedIndex(context: Context): Int =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getInt(KEY_LAST_UNLOCKED, -1)

    fun setLastUnlockedIndex(context: Context, value: Int) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putInt(KEY_LAST_UNLOCKED, value).apply()
    }
}