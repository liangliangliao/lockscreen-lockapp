
// BUILD TAG: LOCKAPP-FSI-RUNTIME-RECEIVER-20250907
package com.example.lockapp.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.util.DebugLog

class GatekeeperService : Service() {

    private var registered = false
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.action ?: return
            DebugLog.i("GatekeeperService", "screenReceiver action=$action")
            if (Intent.ACTION_SCREEN_ON == action) {
                showFullScreenLock(context)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForeground(1902, buildOngoingNotification(this))
        registerScreenReceivers()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val reason = intent?.getStringExtra("reason")
        DebugLog.i("GatekeeperService", "onStartCommand reason=$reason")
        if (reason == "screen_on") {
            showFullScreenLock(this)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        if (registered) {
            unregisterReceiver(screenReceiver)
            registered = false
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun registerScreenReceivers() {
        if (registered) return
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        try {
            registerReceiver(screenReceiver, f)
            registered = true
            DebugLog.w("GatekeeperService", "Registered runtime screen receiver")
        } catch (t: Throwable) {
            DebugLog.e("GatekeeperService", "Failed to register runtime receiver: ${t.message}", t)
        }
    }

    private fun showFullScreenLock(ctx: Context) {
        val channelId = "lock_fsi"
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            if (nm.getNotificationChannel(channelId) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(channelId, "Lock FSI", NotificationManager.IMPORTANCE_HIGH).apply {
                        description = "Full-screen lock prompt"
                        setBypassDnd(true)
                        lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                    }
                )
            }
        }
        val pi = PendingIntent.getActivity(
            ctx,
            2100,
            Intent(ctx, LockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0) or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("Unlock required")
            .setContentText("Tap to unlock to continue")
            .setCategory(Notification.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setFullScreenIntent(pi, true)
            .build()
        NotificationManagerCompat.from(ctx).notify(2101, n)
        DebugLog.w("GatekeeperService", "Posted full-screen lock notification")
    }

    private fun buildOngoingNotification(ctx: Context): Notification {
        val channelId = "keeper_ongoing"
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            if (nm.getNotificationChannel(channelId) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(channelId, "Lock Keeper", NotificationManager.IMPORTANCE_MIN)
                )
            }
        }
        val pi = PendingIntent.getActivity(
            ctx, 1903,
            Intent(ctx, LockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0) or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(ctx, channelId)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("Lock service active")
            .setContentText("Improving reliability")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(pi)
            .build()
    }
}
