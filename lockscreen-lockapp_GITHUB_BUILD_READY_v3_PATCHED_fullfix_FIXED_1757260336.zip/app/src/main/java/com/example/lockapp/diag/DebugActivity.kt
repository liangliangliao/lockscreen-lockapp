package com.example.lockapp.diag

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import com.example.lockapp.util.showDebugHeadsUp
import com.example.lockapp.util.showFullScreen
import com.example.lockapp.MainActivity

class DebugActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Send a heads-up
        showDebugHeadsUp(this, "Debug heads-up", "It works")
        // Also try fullscreen
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        showFullScreen(this, "Debug full-screen", "Bringing activity to front", pi)
        finish()
    }
}
