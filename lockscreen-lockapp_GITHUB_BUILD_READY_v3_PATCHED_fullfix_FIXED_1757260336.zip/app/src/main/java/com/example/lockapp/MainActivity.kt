package com.example.lockapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.lockapp.util.LockFsNotifier

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Keep it minimal; just show a heads-up to prove notifications are wired.
        LockFsNotifier.showDebugHeadsUp(this, "LockApp", "MainActivity started")
        finish()
    }
}
