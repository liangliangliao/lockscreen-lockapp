package com.example.lockapp.ordered

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.app.PendingIntent
import android.os.Build
import com.example.lockapp.MainActivity
import com.example.lockapp.util.showDebugHeadsUp
import com.example.lockapp.util.showFullScreen

class WakeOrderedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Show a quick heads-up to indicate the chain is alive
        showDebugHeadsUp(context, "Ordered wake", intent.action ?: "(no action)")
        // Optionally trigger full-screen activity
        val pi = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS or Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        showFullScreen(context, "Wake", "Bringing activity forward", pi)
    }
}
