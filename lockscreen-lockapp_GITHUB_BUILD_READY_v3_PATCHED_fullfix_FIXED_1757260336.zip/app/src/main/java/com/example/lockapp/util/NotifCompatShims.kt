package com.example.lockapp.util

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import androidx.core.app.NotificationCompat

/**
 * Small shims around NotificationCompat so callers don't have to branch by API.
 * Keep surface area tiny and stable.
 */
object NotifCompatShims {
    @JvmStatic
    fun builder(context: Context, channelId: String): NotificationCompat.Builder {
        return NotificationCompat.Builder(context, channelId)
    }

    /**
     * Applies a full-screen intent and returns the built Notification for APIs that prefer it.
     */
    @JvmStatic
    fun setFullScreenIntent(builder: NotificationCompat.Builder, contentIntent: PendingIntent): Notification {
        builder.setFullScreenIntent(contentIntent, /* highPriority */ true)
        return builder.build()
    }
}
