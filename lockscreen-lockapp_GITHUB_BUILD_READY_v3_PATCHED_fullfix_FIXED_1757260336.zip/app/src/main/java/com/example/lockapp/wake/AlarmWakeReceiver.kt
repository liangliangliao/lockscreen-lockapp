package com.example.lockapp.wake

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.lockapp.util.LockFsNotifier

const val ACTION_WAKE_ORDERED = "com.example.lockapp.ACTION_WAKE_ORDERED"

class AlarmWakeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        LockFsNotifier.showDebugHeadsUp(context, "Wake", "Alarm received")
    }
}
