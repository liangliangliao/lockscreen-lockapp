package com.example.lockapp.data

import kotlinx.coroutines.flow.Flow

class ImagePasswordRepository(
    private val dao: ImagePasswordDao
) {
    fun all(): Flow<List<ImagePassword>> = dao.all()

    suspend fun getAllOnce(): List<ImagePassword> = dao.getAllOnce()

    suspend fun insert(p: ImagePassword): Long = dao.insert(p)

    suspend fun insertOrUpdate(p: ImagePassword): Long = dao.insertOrUpdate(p)

    suspend fun update(p: ImagePassword): Int = dao.update(p)

    suspend fun delete(p: ImagePassword) = dao.delete(p)

    suspend fun clear() = dao.clear()

    suspend fun insertOrUpdate(uri: String, password: String, existing: ImagePassword? = null): Long {
        val entity = existing?.copy(uri = uri, password = password) ?: ImagePassword(uri = uri, password = password)
        return insertOrUpdate(entity)
    }
    
}
