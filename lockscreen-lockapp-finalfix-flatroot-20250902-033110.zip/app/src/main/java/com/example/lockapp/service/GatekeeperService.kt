package com.example.lockapp.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.lockapp.data.ActiveLockStore
import com.example.lockapp.data.LockConfigStore
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.ui.LockActivity

class GatekeeperService : Service() {

    companion object {
        const val ACTION_REQUEST_LOCK = "com.example.lockapp.action.REQUEST_LOCK"
        private const val CH_ID = "lock_guard_channel"
        private const val NOTI_ID = 1001

        fun ensureChannel(ctx: Context): String {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (nm.getNotificationChannel(CH_ID) == null) {
                    nm.createNotificationChannel(
                        NotificationChannel(CH_ID, "Gatekeeper", NotificationManager.IMPORTANCE_MIN).apply {
                            setShowBadge(false)
                            lockscreenVisibility = Notification.VISIBILITY_SECRET
                        }
                    )
                }
            }
            return CH_ID
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    // 屏幕灭 -> 标记需要锁
                    LockStateStore.setLocked(context, true)
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        // 注册屏幕广播
        val f = IntentFilter().apply { addAction(Intent.ACTION_SCREEN_OFF) }
        registerReceiver(screenReceiver, f)
        // 以低打扰前台形态驻留
        startForegroundWithNotification()
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(screenReceiver) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_REQUEST_LOCK -> {
                if (LockConfigStore.isArmed(this) && !ActiveLockStore.getPwd(this).isNullOrEmpty()) {
                    LockStateStore.setLocked(this, true)
                    showFullScreenLockNotification()
                    maybeLaunchLock(this)
                }
            }
            else -> {
                // keep foreground
                startForegroundWithNotification()
            }
        }
        return START_STICKY
    }

    private fun startForegroundWithNotification() {
        val channelId = ensureChannel(this)
        val contentPi = PendingIntent.getActivity(
            this, 0,
            Intent(this, LockActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        val n = NotificationCompat.Builder(this, channelId)
            .setContentTitle("屏幕锁守护中")
            .setContentText("点击可进入解锁界面")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setContentIntent(contentPi)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(this, NOTI_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTI_ID, n)
        }
    }

    private fun showFullScreenLockNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        val canFsi = if (Build.VERSION.SDK_INT >= 34) nm.canUseFullScreenIntent() else true

        val pi = PendingIntent.getActivity(
            this, 1002,
            Intent(this, LockActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        val nb = NotificationCompat.Builder(this, ensureChannel(this))
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("需要解锁")
            .setContentText("正在显示解锁界面")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setOngoing(true)
            .apply { if (canFsi) setFullScreenIntent(pi, true) }
            .setContentIntent(pi)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(this, NOTI_ID + 1, nb, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTI_ID + 1, nb)
        }
    }

    private fun maybeLaunchLock(context: Context) {
        if (!LockStateStore.isLocked(context) || !LockConfigStore.isArmed(context)) return
        val i = Intent(context, LockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
            action = "com.example.lockapp.ACTION_LOCK"
        }
        val pwd = ActiveLockStore.getPwd(context)
        if (!pwd.isNullOrEmpty()) context.startActivity(i)
    }
}
