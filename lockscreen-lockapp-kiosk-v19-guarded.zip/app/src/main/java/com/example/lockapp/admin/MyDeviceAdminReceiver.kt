package com.example.lockapp.admin

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class MyDeviceAdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        Toast.makeText(context, "Device owner enabled", Toast.LENGTH_SHORT).show()
    }
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        return "Disabling device admin will remove kiosk protections."
    }
    override fun onDisabled(context: Context, intent: Intent) {
        Toast.makeText(context, "Device owner disabled", Toast.LENGTH_SHORT).show()
    }
}
