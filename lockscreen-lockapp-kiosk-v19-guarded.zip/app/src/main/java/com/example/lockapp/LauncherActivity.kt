package com.example.lockapp

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import com.example.lockapp.ui.LiveLockScreen

class LauncherActivity : ComponentActivity() {

    private fun tryEnterKiosk() {
        try {
            val dpm = getSystemService(android.app.admin.DevicePolicyManager::class.java)
            val comp = android.content.ComponentName(this, com.example.lockapp.admin.MyDeviceAdminReceiver::class.java)
            if (dpm != null && dpm.isDeviceOwnerApp(packageName)) {
                dpm.setLockTaskPackages(comp, arrayOf(packageName))
                startLockTask()
            } else {
                // If not DO, user-initiated screen pin prompt may appear on startLockTask()
                startLockTask()
            }
        } catch (t: Throwable) {
            // ignore
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        try { startForegroundService(Intent(this, com.example.lockapp.service.GatekeeperService::class.java)) } catch (_: Throwable) {}
        tryEnterKiosk()
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val force = intent.getBooleanExtra("forceLock", false)
        val locked = com.example.lockapp.data.LockStateStore.isLocked(this)
        if (!force && !locked) {
            startActivity(Intent(this, MainActivity::class.java).apply { addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK) })
            finish(); return
        }
        setContent {
            LiveLockScreen(
                onUnlock = {
                        com.example.lockapp.data.LockStateStore.setLocked(this, false);
                    startActivity(Intent(this, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
                    })
                    finish()
                }
            )
        }
    }
}
