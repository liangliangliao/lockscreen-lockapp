package com.example.lockapp.receiver
import android.content.*
import com.example.lockapp.service.GatekeeperService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Intent.ACTION_BOOT_COMPLETED == intent.action) {
            context.startForegroundService(Intent(context, GatekeeperService::class.java))
        }
    }
}