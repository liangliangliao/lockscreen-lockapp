package com.example.lockapp

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import com.example.lockapp.ui.LockScreen

class LockActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setShowWhenLocked(true)
        setTurnScreenOn(true)

        setContent {
            LockScreen(
                onUnlock = {
                    // Dismiss keyguard if possible, then go to home
                    val kg = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
                    try { kg.requestDismissKeyguard(this, null) } catch (_: Exception) { }
                    startActivity(Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_HOME)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    })
                    finish()
                }
            )
        }
    }
}