package com.example.lockapp.util

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast

object Toaster {
    @JvmStatic
    fun show5s(ctx: Context, text: CharSequence) {
        try {
            // LENGTH_LONG ≈ 3.5s，再补一个 SHORT ≈ 2s，合计 ~5.5s
            Toast.makeText(ctx, text, Toast.LENGTH_LONG).show()
            Handler(Looper.getMainLooper()).postDelayed({
                Toast.makeText(ctx, text, Toast.LENGTH_SHORT).show()
            }, 3500L)
        } catch (_: Throwable) {}
    }
}