package com.example.app.patchlock

object AppLockState {
    @Volatile private var locked: Boolean = true
    @Volatile private var lastDialogShownAt: Long = 0L
    private const val DEBOUNCE_MS = 1500L

    fun markLocked() { locked = true }
    fun markUnlocked() { locked = false }
    fun shouldLockNow(): Boolean = locked

    /** Allow showing lock dialog only once within a debounce window. */
    @Synchronized
    fun requestShowOnce(): Boolean {
        if (!locked) return false
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastDialogShownAt < DEBOUNCE_MS) return false
        lastDialogShownAt = now
        return true
    }
}
