package com.example.lockapp.setup

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import com.example.lockapp.LockScreenActivity

/** 创建主渠道（HIGH + 锁屏可见） */
fun ensureMainChannel(ctx: Context) {
    if (Build.VERSION.SDK_INT >= 26) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val id = "main"
        if (nm.getNotificationChannel(id) == null) {
            val ch = NotificationChannel(id, "General", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "General notifications"
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            nm.createNotificationChannel(ch)
        }
    }
}

/** 播种一条普通通知，让系统在设置里显示本应用（含锁屏通知开关） */
fun postSeedNotification(ctx: Context) {
    val n = NotificationCompat.Builder(ctx, "main")
        .setSmallIcon(android.R.drawable.ic_dialog_info)
        .setContentTitle("测试通知")
        .setContentText("用于让系统显示本应用的通知选项（含锁屏）")
        .setAutoCancel(true)
        .apply { if (Build.VERSION.SDK_INT < 26) priority = NotificationCompat.PRIORITY_HIGH }
        .build()
    (run { val __ctx = ctx; val __nm = __ctx.getSystemService(android.content.Context.NOTIFICATION_SERVICE) as android.app.NotificationManager; __nm.notify(10000, n) })
}

/** 跳到“本应用通知设置”（含锁屏通知相关） */
fun openAppNotificationSettings(ctx: Context) {
    try {
        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
            putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
        }
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Throwable) {
        val fb = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            .setData(Uri.parse("package:${ctx.packageName}"))
        ctx.startActivity(fb.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

/** 申请精确闹钟的特殊访问（Android 12/31+） */
fun requestExactAlarmAccess(ctx: Context) {
    if (Build.VERSION.SDK_INT >= 31) {
        try {
            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
            ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {
            val fb = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                .setData(Uri.parse("package:${ctx.packageName}"))
            ctx.startActivity(fb.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}

/** 立即调度一次精确闹钟，帮助系统识别“本应用在用闹钟” */
fun scheduleOneExactAlarm(ctx: Context) {
    try {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
        val flags = if (Build.VERSION.SDK_INT >= 23)
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT else 0
        val pi = PendingIntent.getActivity(
            ctx, 31415,
            Intent(ctx, LockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            flags
        )
        val t = System.currentTimeMillis() + 60_000 // 1 min later
        if (Build.VERSION.SDK_INT >= 23) {
            am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, t, pi)
        } else {
            am.setExact(android.app.AlarmManager.RTC_WAKEUP, t, pi)
        }
    } catch (_: Throwable) { }
}