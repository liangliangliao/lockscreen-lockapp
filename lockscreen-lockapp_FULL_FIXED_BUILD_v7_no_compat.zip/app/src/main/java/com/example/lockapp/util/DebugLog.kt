package com.example.lockapp.util

import android.util.Log

/**
 * 为了兼容“仅手机端日志报告”场景：
 * - 所有日志同时写入两个 TAG 前缀：LOCKAPP/DEBUG 与 LOCKAPP/调试
 * - 即便是 info/debug，也额外镜像一条 WARN，避免系统报告过滤低等级日志
 */
object DebugLog {
    private const val EN = "LOCKAPP/DEBUG"
    private const val CN = "LOCKAPP/调试"

    @JvmStatic fun i(tag: String, msg: String) {
        Log.i("$EN/$tag", msg); Log.i("$CN/$tag", msg)
        Log.w("$EN/$tag", "[I] " + msg); Log.w("$CN/$tag", "[I] " + msg)
    }
    @JvmStatic fun d(tag: String, msg: String) {
        Log.d("$EN/$tag", msg); Log.d("$CN/$tag", msg)
        Log.w("$EN/$tag", "[D] " + msg); Log.w("$CN/$tag", "[D] " + msg)
    }
    @JvmStatic fun w(tag: String, msg: String, tr: Throwable? = null) {
        if (tr != null) { Log.w("$EN/$tag", msg, tr); Log.w("$CN/$tag", msg, tr) }
        else { Log.w("$EN/$tag", msg); Log.w("$CN/$tag", msg) }
    }
    @JvmStatic fun e(tag: String, msg: String, tr: Throwable? = null) {
        if (tr != null) { Log.e("$EN/$tag", msg, tr); Log.e("$CN/$tag", msg, tr) }
        else { Log.e("$EN/$tag", msg); Log.e("$CN/$tag", msg) }
    }
}