
package com.example.lockapp.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationManagerCompat

/**
 * Create a channel if needed (no-op on pre-O).
 * @param importance one of NotificationManagerCompat.IMPORTANCE_*
 */
fun ensureChannel(
    context: Context,
    channelId: String,
    channelName: String,
    importance: Int = NotificationManagerCompat.IMPORTANCE_DEFAULT,
    description: String? = null
) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val sysImportance = when (importance) {
            NotificationManagerCompat.IMPORTANCE_MIN -> NotificationManager.IMPORTANCE_MIN
            NotificationManagerCompat.IMPORTANCE_LOW -> NotificationManager.IMPORTANCE_LOW
            NotificationManagerCompat.IMPORTANCE_HIGH -> NotificationManager.IMPORTANCE_HIGH
            NotificationManagerCompat.IMPORTANCE_MAX -> NotificationManager.IMPORTANCE_HIGH
            else -> NotificationManager.IMPORTANCE_DEFAULT
        }
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(channelId) == null) {
            val ch = NotificationChannel(channelId, channelName, sysImportance)
            if (description != null) ch.description = description
            nm.createNotificationChannel(ch)
        }
    }
}
