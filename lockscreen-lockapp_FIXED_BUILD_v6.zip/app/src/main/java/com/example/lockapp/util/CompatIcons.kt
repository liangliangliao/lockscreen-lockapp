package com.example.lockapp.util

object CompatIcons {
    val LAUNCHER_ICON = android.R.mipmap.ic_launcher
}
