package com.example.lockapp.wake

import android.content.*
import com.example.lockapp.setup.FsiPoke

class FsiAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        FsiPoke.poke(context.applicationContext)
    }
}
