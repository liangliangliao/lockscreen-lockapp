
一体化补丁（含源代码修复 + Gradle 根骨架 + 插件仓库修复）
------------------------------------------------
使用步骤：
1. 将本 ZIP 在仓库根目录解压（与 app/ 同级），选择覆盖已有同名文件。
2. 提交后在仓库根目录执行：gradle clean assembleDebug（或用 GitHub Actions 构建）。
3. 若 CI 中有误删根 Gradle 文件的命令（例如 rm -rf settings.gradle* build.gradle*），请删除。

已包含：
- settings.gradle.kts：已加入 pluginManagement/dependencyResolutionManagement 的 google()/mavenCentral()/gradlePluginPortal() 仓库。
- build.gradle.kts：最小根构建脚本 & clean 任务。
- Kotlin 源码“点修”：修复 setFullScreenIntent/notify 类型、补齐通知渠道、缺失类等。
