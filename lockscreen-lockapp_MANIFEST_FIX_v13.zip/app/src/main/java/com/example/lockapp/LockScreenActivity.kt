
// BUILD TAG: LOCKAPP-RESTORE-FSI-UI-20250907
package com.example.lockapp

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.lockapp.ui.LockScreen
import com.example.lockapp.ui.theme.LockScreenAppTheme
import com.example.lockapp.util.DebugLog

class LockScreenActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Ensure visible over lock screen and wake the screen
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        )
        DebugLog.w("LockScreen", "LockScreenActivity launched")

        setContent {
            LockScreenAppTheme {
                // Render the actual lock screen UI (password entry, preview, buttons, etc.)
                LockScreen(onUnlocked = {
                    // Close the lock UI when unlocked; return user to previous state
                    finish()
                })
            }
        }
    }
}
