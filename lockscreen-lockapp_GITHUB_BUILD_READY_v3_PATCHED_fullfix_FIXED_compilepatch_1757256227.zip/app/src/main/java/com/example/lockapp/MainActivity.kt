// BUILD TAG: LOCKAPP-FSI-FIX-CI-20250907T021838Z
package com.example.lockapp
import com.example.lockapp.util.setFullScreenIntent
import com.example.lockapp.R
import com.example.lockapp.service.LockGuardFgService
import com.example.lockapp.util.Toaster

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.lockapp.setup.SetupActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.core.content.ContextCompat
import com.example.lockapp.ui.MainScreen
import com.example.lockapp.ui.MainViewModel
import com.example.lockapp.ui.MainViewModelFactory
import com.example.lockapp.ui.theme.LockScreenAppTheme
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.launcher.TransparentTrampolineActivity
import com.example.lockapp.util.DebugLog
import com.example.lockapp.util.DebugTracer


class MainActivity : ComponentActivity() {
override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    // Minimal UI to avoid resource linkage issues
    val tv = android.widget.TextView(this)
    tv.text = "LockApp"
    setContentView(tv)
}
}