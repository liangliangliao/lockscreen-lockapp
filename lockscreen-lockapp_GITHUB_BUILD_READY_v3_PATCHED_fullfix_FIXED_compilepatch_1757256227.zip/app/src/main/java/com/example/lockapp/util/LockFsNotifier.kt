// BUILD TAG: LOCKAPP-FSI-FIX-CI-20250907T021838Z
package com.example.lockapp.util
import com.example.lockapp.util.setFullScreenIntent
import com.example.lockapp.R
import androidx.core.app.NotificationManagerCompat
import android.content.Intent
import com.example.lockapp.util.Toaster

import android.app.Notification
import android.app.PendingIntent
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat

/**
 * 通知工具：确保渠道 + 发送 heads-up（锁屏可见）。
 * 依赖仅保留 NotificationCompat（大多数工程已有）。发送使用框架 NotificationManager。
 */
object LockFsNotifier {
    private const val CHANNEL_ID_FG = "lock_guard_fg"
    private const val CHANNEL_NAME_FG = "LockApp 调试/前台"

    /** 确保高优先级渠道存在（Android 8.0+ 必须） */
    private fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = context.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL_ID_FG) == null) {
                val ch = NotificationChannel(
                    CHANNEL_ID_FG,
                    CHANNEL_NAME_FG,
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "用于锁屏弹窗与调试 heads-up 的高优先级渠道"
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
                nm.createNotificationChannel(ch)
            }
        }
    }

    /** 调试：快捷显示一个高优先级 heads-up 通知（锁屏也可见） */
    @JvmStatic
    fun showDebugHeadsUp(context: Context, title: String, text: String) {
        try {
            ensureChannels(context)
            val n: Notification = NotificationCompat.Builder(context, CHANNEL_ID_FG)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(text)
                .setPriority(if (Build.VERSION.SDK_INT < 26) NotificationCompat.PRIORITY_HIGH else 0)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setAutoCancel(true)
                .build()

            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify((System.currentTimeMillis() % 100000).toInt(), n)
        } catch (t: Throwable) {
            DebugLog.w("LockFsNotifier", "showDebugHeadsUp 失败: ${t.message}", t)
        }
    }

    /** 兜底：显示全屏通知（如果你的工程里有该方法体，可继续保留/合并） */
    @JvmStatic
    fun showFullScreen(context: Context) {
        try {
            ensureChannels(context)
            val n: Notification = NotificationCompat.Builder(context, CHANNEL_ID_FG)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("锁屏唤起")
                .setContentText("触发全屏通知兜底")
                .setPriority(if (Build.VERSION.SDK_INT < 26) NotificationCompat.PRIORITY_HIGH else 0)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                
Toaster.show5s(context, "正在发送全屏弹窗（FSI）")
.setFullScreenIntent(contentPi, true) // 这里按你现有实现填入 PendingIntent
                .build()
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify((System.currentTimeMillis() % 100000).toInt(), n)
        } catch (t: Throwable) {
            DebugLog.w("LockFsNotifier", "showFullScreen 失败: ${t.message}", t)
        }
    }
}