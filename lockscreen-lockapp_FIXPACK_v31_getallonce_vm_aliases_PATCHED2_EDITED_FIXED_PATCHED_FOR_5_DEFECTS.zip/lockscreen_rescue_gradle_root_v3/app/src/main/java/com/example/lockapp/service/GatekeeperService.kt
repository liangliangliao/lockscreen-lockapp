package com.example.lockapp.service

import android.app.*
import android.content.*
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.lockapp.R
import com.example.lockapp.LockScreenActivity

class GatekeeperService : Service() {

    private val channelId = "gk_foreground"
    private val alertChannelId = "gk_alerts"
    private var screenReceiver: BroadcastReceiver? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        startInForeground()

        // Dynamically listen for screen-on while service is alive
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
        }
        screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (Intent.ACTION_SCREEN_ON == intent.action) {
                    showLockNow()
                }
            }
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenReceiver, f, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(screenReceiver, f)
        }
    }

    override fun onDestroy() {
        try { screenReceiver?.let { unregisterReceiver(it) } } catch (_: Throwable) {}
        screenReceiver = null
        super.onDestroy()
    }

    private fun startInForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val n = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_lock_patch)
            .setContentTitle("LockApp 守护服务")
            .setContentText("监听亮屏以弹出解锁界面")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(1, n)
        }
    }

    /** Use a high-priority full-screen intent to bring our lock to front. */
    private fun showLockNow() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val chId = alertChannelId
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(chId, "Lock Alerts", NotificationManager.IMPORTANCE_HIGH).apply {
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
            )
        }
        val flags = if (Build.VERSION.SDK_INT >= 23)
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT else 0
        val pi = PendingIntent.getActivity(
            this, 10086,
            Intent(this, LockScreenActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or
                          Intent.FLAG_ACTIVITY_SINGLE_TOP or
                          Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS),
            flags
        )
        val n = NotificationCompat.Builder(this, chId)
            .setSmallIcon(R.drawable.ic_lock_patch)
            .setContentTitle("锁屏")
            .setContentText("点击或自动弹出解锁界面")
            .setCategory(Notification.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setDefaults(Notification.DEFAULT_ALL)
            .setFullScreenIntent(pi, true)
            .setAutoCancel(true)
            .build()
        nm.notify(10086, n)
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val fg = NotificationChannel(channelId, "Gatekeeper Service", NotificationManager.IMPORTANCE_MIN)
            nm.createNotificationChannel(fg)
            val alerts = NotificationChannel(alertChannelId, "Lock Alerts", NotificationManager.IMPORTANCE_HIGH)
            alerts.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(alerts)
        }
    }
}
