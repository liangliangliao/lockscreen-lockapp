package com.example.lockapp.ui.theme
import androidx.compose.ui.graphics.Color
val Purple90 = Color(0xFFD0BCFF)
val Teal90 = Color(0xFF66FFF9)
val Black = Color(0xFF000000)
val White = Color(0xFFFFFFFF)
val Purple40 = Color(0xFF6650a4)
val Teal40 = Color(0xFF03DAC5)
