package com.example.lockapp.data

import kotlinx.coroutines.flow.first

suspend fun ImagePasswordDao.getAllOnce(): List<ImagePassword> = all().first()
