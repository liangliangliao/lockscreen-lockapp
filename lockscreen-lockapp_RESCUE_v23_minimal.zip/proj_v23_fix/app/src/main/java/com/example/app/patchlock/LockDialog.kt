
package com.example.app.patchlock
/** Rescue stub: original LockDialog is replaced by LockActivity */
