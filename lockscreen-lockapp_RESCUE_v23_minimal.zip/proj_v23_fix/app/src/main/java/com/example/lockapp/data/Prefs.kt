
package com.example.lockapp.data

import android.content.Context
import android.net.Uri
import java.util.Random

enum class RotationMode { SEQUENTIAL, RANDOM }

object Prefs {
    private const val FILE = "lock_prefs"
    private const val KEY_PWD = "pwd"
    private const val KEY_URIS = "uris"
    private const val KEY_LAST_INDEX = "last_index"
    private const val KEY_ROTATION = "rotation_mode"
    private const val KEY_LOCKED = "locked"

    private fun sp(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun setPassword(ctx: Context, pwd: String) {
        sp(ctx).edit().putString(KEY_PWD, pwd).apply()
    }
    fun getPassword(ctx: Context): String? = sp(ctx).getString(KEY_PWD, null)

    fun setRotationMode(ctx: Context, mode: RotationMode) {
        sp(ctx).edit().putString(KEY_ROTATION, mode.name).apply()
    }
    fun getRotationMode(ctx: Context): RotationMode {
        val v = sp(ctx).getString(KEY_ROTATION, RotationMode.SEQUENTIAL.name)!!
        return try { RotationMode.valueOf(v) } catch (_: Exception){ RotationMode.SEQUENTIAL }
    }

    fun setImageUris(ctx: Context, uris: List<Uri>) {
        val s = uris.joinToString("|") { it.toString() }
        sp(ctx).edit().putString(KEY_URIS, s).apply()
        if (uris.isNotEmpty()) {
            val last = sp(ctx).getInt(KEY_LAST_INDEX, 0)
            val bounded = last.coerceIn(0, uris.size - 1)
            sp(ctx).edit().putInt(KEY_LAST_INDEX, bounded).apply()
        } else {
            sp(ctx).edit().putInt(KEY_LAST_INDEX, 0).apply()
        }
    }
    fun getImageUris(ctx: Context): List<Uri> {
        val s = sp(ctx).getString(KEY_URIS, "") ?: ""
        return if (s.isEmpty()) emptyList() else s.split("|").mapNotNull {
            try { Uri.parse(it) } catch (_: Exception){ null }
        }
    }

    /** index只在【解锁成功】时才推进；亮屏但未解锁不推进 */
    fun getCurrentImageUri(ctx: Context): Uri? {
        val list = getImageUris(ctx)
        if (list.isEmpty()) return null
        val idx = sp(ctx).getInt(KEY_LAST_INDEX, 0).coerceIn(0, list.size - 1)
        return list[idx]
    }

    fun advanceIndexAfterUnlock(ctx: Context) {
        val list = getImageUris(ctx)
        if (list.isEmpty()) return
        val mode = getRotationMode(ctx)
        val cur = sp(ctx).getInt(KEY_LAST_INDEX, 0).coerceIn(0, list.size - 1)
        val next = when(mode) {
            RotationMode.SEQUENTIAL -> (cur + 1) % list.size
            RotationMode.RANDOM -> if (list.size == 1) 0 else Random().let { 
                var r = cur
                while (r == cur) { r = it.nextInt(list.size) }
                r
            }
        }
        sp(ctx).edit().putInt(KEY_LAST_INDEX, next).apply()
    }

    fun setLocked(ctx: Context, locked: Boolean) {
        sp(ctx).edit().putBoolean(KEY_LOCKED, locked).apply()
    }
    fun isLocked(ctx: Context): Boolean = sp(ctx).getBoolean(KEY_LOCKED, true)
}
