
package com.example.lockapp

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.lockapp.data.Prefs
import com.example.lockapp.data.RotationMode
import com.example.lockapp.service.GatekeeperService

class MainActivity : AppCompatActivity() {

    private val PICK_IMAGES = 200

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
        }
        val btnSvc = Button(this).apply { text = "启动前台服务" }
        val btnPick = Button(this).apply { text = "导入图片" }
        val pwdEdit = EditText(this).apply { hint = "设置/修改密码"; isSingleLine = true }
        val btnSavePwd = Button(this).apply { text = "保存密码" }
        val modeGroup = RadioGroup(this)
        val rbSeq = RadioButton(this).apply { text = "顺序"; id = 1 }
        val rbRnd = RadioButton(this).apply { text = "随机"; id = 2 }
        modeGroup.addView(rbSeq); modeGroup.addView(rbRnd)
        val btnSaveMode = Button(this).apply { text = "保存轮播模式" }

        root.addView(btnSvc)
        root.addView(btnPick)
        root.addView(pwdEdit)
        root.addView(btnSavePwd)
        root.addView(modeGroup)
        root.addView(btnSaveMode)

        setContentView(root)

        btnSvc.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(Intent(this, GatekeeperService::class.java))
            } else {
                startService(Intent(this, GatekeeperService::class.java))
            }
            Toast.makeText(this, "尝试启动前台服务", Toast.LENGTH_SHORT).show()
        }

        btnPick.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }
            startActivityForResult(intent, PICK_IMAGES)
        }

        btnSavePwd.setOnClickListener {
            val p = pwdEdit.text?.toString() ?: ""
            Prefs.setPassword(this, p)
            Toast.makeText(this, "密码已保存", Toast.LENGTH_SHORT).show()
        }

        // 恢复单选状态
        val cur = Prefs.getRotationMode(this)
        if (cur == RotationMode.SEQUENTIAL) rbSeq.isChecked = true else rbRnd.isChecked = true

        btnSaveMode.setOnClickListener {
            val chosen = if (rbSeq.isChecked) RotationMode.SEQUENTIAL else RotationMode.RANDOM
            Prefs.setRotationMode(this, chosen)
            Toast.makeText(this, "轮播模式已保存：" + chosen.name, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGES && resultCode == Activity.RESULT_OK) {
            val list = mutableListOf<Uri>()
            data?.data?.let { list.add(it) }
            val clip = data?.clipData
            if (clip != null) {
                for (i in 0 until clip.itemCount) {
                    list.add(clip.getItemAt(i).uri)
                }
            }
            if (list.isNotEmpty()) {
                Prefs.setImageUris(this, list)
                Toast.makeText(this, "已导入 ${list.size} 张图片", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
