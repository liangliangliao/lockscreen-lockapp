
package com.example.lockapp.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.ui.LockActivity
import com.example.lockapp.data.Prefs

class GatekeeperService : Service() {
    companion object {
        const val CH_ID = "lock_fg"
        const val CH_NAME = "Lock Foreground"
        const val NOTI_ID = 1001
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (Intent.ACTION_SCREEN_ON == intent.action) {
                Toast.makeText(context, "SCREEN_ON received", Toast.LENGTH_SHORT).show()
                showFullScreenLock()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTI_ID, buildServiceNotification())
        registerReceiver(screenReceiver, IntentFilter(Intent.ACTION_SCREEN_ON))
        Toast.makeText(this, "GatekeeperService started & receiver registered", Toast.LENGTH_SHORT).show()
        // 默认进入锁定态
        Prefs.setLocked(this, true)
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildServiceNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT>=23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        return NotificationCompat.Builder(this, CH_ID)
            .setContentTitle("Lock Service Running")
            .setContentText("Listening for SCREEN_ON")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CH_ID, CH_NAME, NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Foreground + Full Screen"
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
            )
        }
    }

    private fun showFullScreenLock() {
        val intent = Intent(this, LockActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        // 不推进轮播索引：只是亮屏展示
        val bg = Prefs.getCurrentImageUri(this)
        if (bg != null) intent.putExtra(LockActivity.EXTRA_BG_URI, bg.toString())

        val fullPi = PendingIntent.getActivity(
            this, 1, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT>=23) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        val builder = NotificationCompat.Builder(this, CH_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("Unlock required")
            .setContentText("Tap to unlock")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL) // 使其有更高机会成为全屏
            .setAutoCancel(true)
            .setFullScreenIntent(fullPi, true)

        NotificationManagerCompat.from(this).notify(2001, builder.build())
        Toast.makeText(this, "Full-screen notification posted", Toast.LENGTH_SHORT).show()
    }
}
