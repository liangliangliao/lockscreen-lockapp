
package com.example.lockapp.util

import android.content.Context
import com.example.lockapp.data.Prefs

object LockState {
    fun isLocked(ctx: Context) = Prefs.isLocked(ctx)
    fun setLocked(ctx: Context, v: Boolean) = Prefs.setLocked(ctx, v)
}
