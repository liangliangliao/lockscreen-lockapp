
package com.example.lockapp.wake

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.example.lockapp.service.GatekeeperService

class FsiAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val a = intent.action ?: return
        if (a == Intent.ACTION_BOOT_COMPLETED || a == Intent.ACTION_MY_PACKAGE_REPLACED) {
            context.startForegroundService(Intent(context, GatekeeperService::class.java))
            Toast.makeText(context, "Boot/Update -> GatekeeperService started", Toast.LENGTH_SHORT).show()
        }
    }
}
