
package com.example.lockapp.ui

import android.app.KeyguardManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.lockapp.data.Prefs

class LockActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_BG_URI = "bg_uri"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 使其在锁屏上方显示 & 点亮屏幕
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val kg = getSystemService(KeyguardManager::class.java)
            kg?.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        val root = FrameLayout(this)
        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        root.addView(img)

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT
            )
        }
        val tip = TextView(this).apply { text = "请输入密码解锁" }
        val edit = EditText(this).apply { hint = "密码"; isSingleLine = true }
        val btn = Button(this).apply { text = "解锁" }
        panel.addView(tip); panel.addView(edit); panel.addView(btn)
        root.addView(panel)
        setContentView(root)

        // 背景：来自 full-screen 通知传入或当前索引
        val passed = intent?.getStringExtra(EXTRA_BG_URI)
        val uri = if (passed != null) Uri.parse(passed) else Prefs.getCurrentImageUri(this)
        if (uri != null) {
            try { img.setImageURI(uri) } catch (_: Exception) {}
        }

        btn.setOnClickListener {
            val input = edit.text?.toString() ?: ""
            val real = Prefs.getPassword(this) ?: ""
            if (real.isNotEmpty() && input == real) {
                // 解锁成功：推进索引 & 标记解锁
                Prefs.advanceIndexAfterUnlock(this)
                Prefs.setLocked(this, false)
                Toast.makeText(this, "解锁成功", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "密码错误", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
