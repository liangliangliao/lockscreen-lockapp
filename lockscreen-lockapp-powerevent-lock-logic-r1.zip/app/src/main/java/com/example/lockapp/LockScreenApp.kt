package com.example.lockapp

import android.app.Application
import androidx.room.Room
import androidx.lifecycle.ProcessLifecycleOwner
import com.example.lockapp.app.AppVisibility
import com.example.lockapp.data.AppDatabase

/**
 * Custom [Application] that holds a reference to the Room database. This allows the database
 * to be accessed throughout the app without repeatedly creating new instances.
 */
class LockScreenApp : Application() {
    // Singleton instance of the Room database.
    lateinit var database: AppDatabase
        private set

    override fun onCreate() {
        super.onCreate()
        // Build the database once when the application is created.
        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "image_password.db"
        ).build()
        // Track app foreground/background
        ProcessLifecycleOwner.get().lifecycle.addObserver(AppVisibility)
    }
}