package com.example.lockapp.app

import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import java.util.concurrent.atomic.AtomicBoolean

object AppVisibility : DefaultLifecycleObserver {
    private val _isForeground = AtomicBoolean(false)
    val isForeground: Boolean get() = _isForeground.get()

    override fun onStart(owner: LifecycleOwner) {
        _isForeground.set(true)
    }
    override fun onStop(owner: LifecycleOwner) {
        _isForeground.set(false)
    }
}
