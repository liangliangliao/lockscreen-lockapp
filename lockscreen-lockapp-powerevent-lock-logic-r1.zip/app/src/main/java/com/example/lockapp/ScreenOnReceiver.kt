
package com.example.lockapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.lockapp.ui.LockActivity
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.data.LockConfigStore
import com.example.lockapp.data.ActiveLockStore
import com.example.lockapp.service.GatekeeperService

class ScreenOnReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (LockConfigStore.isArmed(context)) {
            val pwd = ActiveLockStore.getPwd(context)
            if (!pwd.isNullOrEmpty()) {
                // Delegate to foreground service which will decide how to present UI
                val svc = Intent(context, GatekeeperService::class.java).apply {
                    action = GatekeeperService.ACTION_REQUEST_LOCK
                }
                try { context.startForegroundService(svc) } catch (_: Throwable) { context.startService(svc) }
            }
        }
    }
}
