package com.example.lockapp.data

import android.content.Context
import android.preference.PreferenceManager

class LockStateStore(context: Context) {
    private val prefs = PreferenceManager.getDefaultSharedPreferences(context)
    private val KEY_PWD = "lock_pwd_plain"
    private val KEY_LOCKED = "lock_is_locked"

    fun setPassword(p: String) { prefs.edit().putString(KEY_PWD, p).apply() }
    fun getPassword(): String = prefs.getString(KEY_PWD, "1234") ?: "1234"

    fun setLocked(v: Boolean) { prefs.edit().putBoolean(KEY_LOCKED, v).apply() }
    fun isLocked(): Boolean = prefs.getBoolean(KEY_LOCKED, false)
}