package com.example.lockapp.setup

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts.RequestPermission
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.ElevatedCard
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.service.GatekeeperService

@Composable
fun GuardSetupScreen(onAllDone: () -> Unit) {
    val ctx = LocalContext.current
    val notifGranted = remember { mutableStateOf(SetupChecks.hasPostNotificationsPermission(ctx)) }
    val overlayGranted = remember { mutableStateOf(SetupChecks.canDrawOverlays(ctx)) }
    val ignoreBatt = remember { mutableStateOf(SetupChecks.isIgnoringBatteryOptimizations(ctx)) }

    val reqNotif = rememberLauncherForActivityResult(RequestPermission()) { granted ->
        notifGranted.value = granted
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("必要设置", style = MaterialTheme.typography.titleLarge)

        // Notifications
        SettingRow(
            title = "通知权限",
            status = if (notifGranted.value) "已允许" else "未允许",
            ok = notifGranted.value
        ) {
            if (Build.VERSION.SDK_INT >= 33) {
                reqNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                runCatching { ctx.startActivity(SetupNavigator.notificationSettings(ctx)) }
            }
        }

        // Overlay
        SettingRow(
            title = "在其他应用上层(悬浮窗)",
            status = if (overlayGranted.value) "已允许" else "未允许",
            ok = overlayGranted.value
        ) {
            if (!SetupChecks.canDrawOverlays(ctx)) { try { ctx.startActivity(SetupNavigator.overlayPermission(ctx)) } catch (_: Throwable) { openOverlaySettingsRobust(ctx) } } else { openOverlaySettingsRobust(ctx) }
        }

        // Battery
        SettingRow(
            title = "电池优化",
            status = if (ignoreBatt.value) "已忽略" else "未忽略",
            ok = ignoreBatt.value
        ) {
            // first try direct request; if already granted, open the list for visibility
            if (!ignoreBatt.value) {
                runCatching { ctx.startActivity(SetupNavigator.requestIgnoreBatteryOptimizations(ctx)) }
                    .onFailure {
                        runCatching { ctx.startActivity(SetupNavigator.batteryOptimizationList()) }
                    }
            } else {
                runCatching { ctx.startActivity(SetupNavigator.batteryOptimizationList()) }
            }
        }

        // Test mask: start our lock screen directly
        ElevatedCard {
            Column(Modifier.padding(12.dp)) {
                Text("测试遮罩（立即弹出解锁界面）", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = {
                    val i = Intent(ctx, LockScreenActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or
                                  Intent.FLAG_ACTIVITY_CLEAR_TOP or
                                  Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
                    runCatching { ctx.startActivity(i) }
                }) { Text("立即测试") }
            }
        }

        Spacer(Modifier.height(8.dp))

        // Done button: start service + persist
        Button(onClick = {
            try {
                ensureServiceRunning(ctx)
            } catch (t: Throwable) {
                // swallow & continue to avoid crash; user can re-open later
            }
            ctx.getSharedPreferences("onboarding", Context.MODE_PRIVATE)
                .edit().putBoolean("done", true).apply()
            onAllDone()
        }, modifier = Modifier.fillMaxWidth()) {
            Text("我已完成设置")
        }
    }
}

private fun ensureServiceRunning(ctx: Context) {
    val i = Intent(ctx, GatekeeperService::class.java)
    if (Build.VERSION.SDK_INT >= 26) {
        ContextCompat.startForegroundService(ctx, i)
    } else {
        ctx.startService(i)
    }
}

private fun openOverlaySettingsRobust(ctx: Context) {
    // App-specific page
    val primary = SetupNavigator.overlayPermission(ctx)
    try {
        ctx.startActivity(primary)
        return
    } catch (_: Throwable) {}

    // Global list
    try {
        val list = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
        ctx.startActivity(list)
        return
    } catch (_: Throwable) {}

    // Vendor fallbacks
    for (it in SetupNavigator.vendorOverlayFallbackIntents(ctx)) {
        try {
            ctx.startActivity(it); return
        } catch (_: Throwable) {}
    }

    // Last resort: app details
    try { ctx.startActivity(SetupNavigator.appDetails(ctx)) } catch (_: Throwable) {}
}

@Composable
private fun SettingRow(title: String, status: String, ok: Boolean, onClick: () -> Unit) {
    ElevatedCard {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(status, style = MaterialTheme.typography.bodyMedium,
                    color = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.width(12.dp))
            TextButton(onClick = onClick) { Text("去设置") }
        }
    }
}
