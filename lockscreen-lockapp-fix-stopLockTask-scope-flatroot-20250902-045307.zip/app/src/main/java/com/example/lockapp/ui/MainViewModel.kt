package com.example.lockapp.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.lockapp.data.ImagePassword
import com.example.lockapp.data.ImagePasswordRepository
import com.example.lockapp.data.RotationManager
import com.example.lockapp.data.RotationMode
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * ViewModel driving the main screen. Exposes the list of images, rotation settings and
 * supports insertion, updating, deletion and re-ordering of image/password records.
 */
class MainViewModel(
    private val repository: ImagePasswordRepository,
    private val rotationManager: RotationManager
) : ViewModel() {
    // Expose the list of entries as a StateFlow so UI can collect it in Compose.
    val entries: StateFlow<List<ImagePassword>> = repository.entries
        .map { it.sortedBy { entry -> entry.orderIndex } }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    // Expose the current rotation mode.
    val rotationMode: StateFlow<RotationMode> = rotationManager.rotationMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), RotationMode.SEQUENTIAL)

    /** Insert a new image/password or update an existing one. */
    fun insertOrUpdate(uri: Uri, password: String, existing: ImagePassword? = null) {
        viewModelScope.launch {
            repository.insertOrUpdate(uri.toString(), password, existing)
        }
    }

    /** Update an existing entry (including changes to order index). */
    fun update(entry: ImagePassword) {
        viewModelScope.launch { repository.update(entry) }
    }

    /** Delete an existing entry. */
    fun delete(entry: ImagePassword) {
        viewModelScope.launch { repository.delete(entry) }
    }

    /** Set the rotation mode (sequential or shuffle). */
    fun setRotationMode(mode: RotationMode) {
        viewModelScope.launch { rotationManager.setRotationMode(mode) }
    }
}