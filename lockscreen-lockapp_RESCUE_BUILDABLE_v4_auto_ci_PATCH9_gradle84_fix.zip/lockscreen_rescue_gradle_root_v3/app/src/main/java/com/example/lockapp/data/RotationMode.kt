package com.example.lockapp.data
enum class RotationMode { SEQUENTIAL, RANDOM }