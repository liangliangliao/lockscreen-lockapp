package com.example.lockapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.lockapp.service.GatekeeperService

/**
 * 仅在屏幕状态变化时把 GatekeeperService 拉起，真正的逻辑在服务里处理。
 */
class ScreenOnReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        Log.i("LOCKAPP/ScreenOnReceiver", "onReceive: $action")

        when (action) {
            // 亮屏：启动前台服务（Android O+ 必须 startForegroundService）
            Intent.ACTION_SCREEN_ON -> {
                val svc = Intent(context, GatekeeperService::class.java)
                    .setAction(Intent.ACTION_SCREEN_ON)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(svc)
                } else {
                    context.startService(svc)
                }
            }

            // 熄屏：同样通知服务（服务里做 mark/清门闩等）
            Intent.ACTION_SCREEN_OFF -> {
                val svc = Intent(context, GatekeeperService::class.java)
                    .setAction(Intent.ACTION_SCREEN_OFF)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(svc)
                } else {
                    context.startService(svc)
                }
            }

            else -> Unit
        }
    }
}