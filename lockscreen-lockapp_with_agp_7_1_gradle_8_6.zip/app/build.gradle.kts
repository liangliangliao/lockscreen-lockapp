
plugins {
    id("com.android.application") version "7.1.0" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}

repositories {
    google()  // Ensure Google repository for Android Gradle Plugin
    mavenCentral()
}

android {
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.lockdemo"
        minSdk = 23
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("androidx.fragment:fragment-ktx:1.8.3")
}
