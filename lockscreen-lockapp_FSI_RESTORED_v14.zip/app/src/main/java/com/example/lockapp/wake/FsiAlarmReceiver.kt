// BUILD TAG: LOCKAPP-FSI-FIX-CI-20250907T031900Z
package com.example.lockapp.wake
import com.example.lockapp.R

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.util.DebugLog

class FsiAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        // Minimal full-screen notification to wake lockscreen flow
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val channelId = "lockapp_fsi_alarm"
        if (Build.VERSION.SDK_INT >= 26 && nm?.getNotificationChannel(channelId) == null) {
            nm?.createNotificationChannel(NotificationChannel(channelId, "LockApp FSI", NotificationManager.IMPORTANCE_HIGH))
        }
        val pi = PendingIntent.getActivity(
            ctx, 2100,
            Intent(ctx, LockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0) or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Unlock required")
            .setContentText("Tap to open the lock screen")
            .setCategory(Notification.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setFullScreenIntent(pi, true)
            .build()
        NotificationManagerCompat.from(ctx).notify(2101, n)
        DebugLog.w("FSI", "Alarm fallback: posted full-screen notification")
    }
}
