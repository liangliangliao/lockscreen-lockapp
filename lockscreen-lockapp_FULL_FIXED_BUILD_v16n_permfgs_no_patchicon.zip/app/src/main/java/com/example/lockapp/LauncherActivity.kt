package com.example.lockapp
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.content.Context
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R

import android.app.KeyguardManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import android.content.Intent
import com.example.lockapp.service.GatekeeperService
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.ui.LiveLockScreen
import com.example.lockapp.util.LockCoordinator

class LauncherActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try { startService(Intent(this, GatekeeperService::class.java)) } catch (_: Throwable) {}
        WindowCompat.setDecorFitsSystemWindows(window, false)

        val forceLock = intent?.getBooleanExtra("forceLock", false) == true
        val stillLocked = LockStateStore.isLocked(this)

        if (!forceLock && !stillLocked) {
            // 正常启动应用
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        setContent {
            LiveLockScreen(
                onUnlock = {
                    try { getSystemService(KeyguardManager::class.java)?.requestDismissKeyguard(this, null) } catch (_: Throwable) {}
                    LockCoordinator.markUnlocked(this)
                    LockCoordinator.leaveShowing()
                    finish()
                },
                onEmergency = {}
            )
        }
    }
}
