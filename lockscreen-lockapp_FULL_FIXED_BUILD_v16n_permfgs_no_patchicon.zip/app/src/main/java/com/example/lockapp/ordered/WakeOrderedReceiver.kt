package com.example.lockapp.ordered
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R
import com.example.lockapp.util.Toaster

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.util.LockCoordinator
import com.example.lockapp.util.LockFsNotifier
import com.example.lockapp.util.LockVisibilityTracker
import com.example.lockapp.util.DebugLog
import com.example.lockapp.util.DebugTracer

class WakeOrderedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        
        DebugTracer.w("WakeOrderedReceiver", "onReceive action="+(intent?.action ?: ""))
        try { DebugTracer.notify(context, "Trace", "WakeOrderedReceiver onReceive") } catch (t: Throwable) { }
if (ACTION_WAKE_ORDERED != intent.action) return
        try { val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lockapp:wakeOrdered").apply { acquire(2000) } } catch (_: Throwable) {}
        LockFsNotifier.showDebugHeadsUp(context, "模拟卸载路径", "WakeOrderedReceiver 进入，locked="+LockCoordinator.isLocked(context))
        DebugLog.i("WakeOrderedReceiver", "进入模拟卸载路径接收器，当前锁屏状态="+LockCoordinator.isLocked(context)+"，来源=前台有序广播（模拟卸载）")

        if (!LockCoordinator.isLocked(context)) {
            try {
                val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
                launch?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                if (launch != null) { context.startActivity(launch); LockFsNotifier.showDebugHeadsUp(context, "刷新分支", "Receiver: bring-to-front Launcher"); DebugLog.i("WakeOrderedReceiver", "分支：未锁屏 → 前台化应用（startActivity Launcher）") }
            } catch (_: Throwable) {}
            return
        }

        Handler(Looper.getMainLooper()).post {
            var started = false
            try {
                val i = Intent().apply { setClassName(context, "com.example.lockapp.launcher.TransparentTrampolineActivity"); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP); action = "com.example.lockapp.SHOW_LOCK_FROM_FSI"; putExtra("from_fsi", true) }
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .setAction("com.example.lockapp.SHOW_LOCK")
                context.startActivity(i)
                LockFsNotifier.showDebugHeadsUp(context, "锁屏分支", "Receiver: startActivity LockScreen")
                DebugLog.i("WakeOrderedReceiver", "分支：已锁屏 → 直接启动锁屏界面")
                started = true
            } catch (_: Throwable) {}

            if (true /*强制FSI*/ || !LockVisibilityTracker.visible) {
                try { LockFsNotifier.showFullScreen(context); LockFsNotifier.showDebugHeadsUp(context, "锁屏分支", "Receiver: FSI 兜底"); DebugLog.i("WakeOrderedReceiver", "分支：已锁屏 → FSI 兜底（透明跳板→锁屏）") } catch (_: Throwable) {}
            }
        }
    }
    companion object { const val ACTION_WAKE_ORDERED = "com.example.lockapp.ACTION_WAKE_ORDERED" }
}