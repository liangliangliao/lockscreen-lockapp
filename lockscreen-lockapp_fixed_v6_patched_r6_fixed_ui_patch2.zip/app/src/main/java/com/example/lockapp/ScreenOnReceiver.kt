package com.example.lockapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import com.example.lockapp.util.LockCoordinator
import com.example.lockapp.util.LockVisibilityTracker

class ScreenOnReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_SCREEN_OFF -> {
                // 息屏时立即置锁并复位闸门
                LockCoordinator.markLocked(context)
                LockCoordinator.leaveShowing()
                LockVisibilityTracker.visible = false
                return
            }
            Intent.ACTION_SCREEN_ON,
            Intent.ACTION_USER_PRESENT -> {
                val i = Intent(context, LockScreenActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                val pending = goAsync()
                Handler(Looper.getMainLooper()).postDelayed({
                    try {
                        if (LockCoordinator.isLocked(context)
                            && !LockVisibilityTracker.visible
                            && LockCoordinator.requestShowOnce()
                            && LockCoordinator.tryEnterShowing()
                        ) {
                            context.startActivity(i)
                        }
                    } finally {
                        pending.finish()
                    }
                }, 180)
            }
        }
    }
}
