
package com.example.lockapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.example.lockapp.util.LockCoordinator
import com.example.lockapp.util.LockVisibilityTracker

class ScreenOnReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Intent.ACTION_SCREEN_ON == intent.action || Intent.ACTION_USER_PRESENT == intent.action) {
            val i = Intent(context, LockScreenActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            Handler(Looper.getMainLooper()).postDelayed({ if (LockCoordinator.isLocked(context) && !LockVisibilityTracker.visible && LockCoordinator.requestShowOnce() && LockCoordinator.tryEnterShowing()) { context.startActivity(i) } }, 250)
        }
    }
}

when (intent.action) {
    Intent.ACTION_SCREEN_OFF -> {
        com.example.lockapp.util.LockCoordinator.markLocked(context)
        com.example.lockapp.util.LockCoordinator.leaveShowing()
        com.example.lockapp.util.LockVisibilityTracker.visible = false
        return
    }
    Intent.ACTION_SCREEN_ON,
    Intent.ACTION_USER_PRESENT -> {
        // Fallback: ensure we're locked even if OFF wasn't received
        com.example.lockapp.util.LockCoordinator.markLocked(context)

        val i = Intent(context, com.example.lockapp.LockScreenActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)

        if (com.example.lockapp.util.LockCoordinator.isLocked(context)
            && !com.example.lockapp.util.LockVisibilityTracker.visible
            && com.example.lockapp.util.LockCoordinator.requestShowOnce()
            && com.example.lockapp.util.LockCoordinator.tryEnterShowing()
        ) {
            try { context.startActivity(i) } catch (_: Throwable) {}
                // —— FSI兜底：如果未显示则用全屏通知唤起
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    if (!com.example.lockapp.util.LockVisibilityTracker.visible
                        && com.example.lockapp.util.LockCoordinator.isLocked(context)
                    ) {
                        com.example.lockapp.util.LockFsNotifier.showFullScreen(context)
                    }
                }, 120)

        }
    }
}
