package com.example.lockapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.example.lockapp.ui.Theme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Theme {
                MainScreen(
                    onPickImage = { pickBackground() },
                    onTestLock = { startActivity(Intent(this, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                )
            }
        }
    }

    private fun pickBackground() {
        val launcher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                getSharedPreferences("lockapp", MODE_PRIVATE)
                    .edit()
                    .putString("bg", uri.toString())
                    .apply()
            }
        }
        launcher.launch("image/*")
    }
}

@Composable
private fun MainScreen(onPickImage: () -> Unit, onTestLock: () -> Unit) {
    var pwd by remember { mutableStateOf(TextFieldValue("")) }
    val prefs = androidx.compose.ui.platform.LocalContext.current.getSharedPreferences("lockapp", 0)

    LaunchedEffect(Unit) {
        pwd = TextFieldValue(prefs.getString("pwd", "") ?: "")
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = onTestLock) { Text("测试锁屏") }
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("锁屏设置")
            OutlinedTextField(
                value = pwd,
                onValueChange = {
                    pwd = it
                    prefs.edit().putString("pwd", it.text).apply()
                },
                label = { Text("密码（明文）") }
            )
            Button(onClick = onPickImage) { Text("选择背景图片") }
            Text("提示：点“测试锁屏”可立即查看锁屏界面；亮屏解锁后也会自动弹出。")
        }
    }
}
