#!/usr/bin/env bash
set -euo pipefail

repo_root="$(pwd)"

find_root() {
  if [[ -f "settings.gradle" || -f "settings.gradle.kts" ]]; then
    echo "$repo_root"
    return 0
  fi
  local found
  found="$(git ls-files 2>/dev/null | grep -E 'settings\.gradle(\.kts)?$' || true)"
  if [[ -n "$found" ]]; then
    local first
    first="$(echo "$found" | head -n1)"
    echo "$(dirname "$repo_root/$first")"
    return 0
  fi
  if [[ -f "app/build.gradle" || -f "app/build.gradle.kts" ]]; then
    echo "$repo_root"
    return 0
  fi
  return 1
}

if root=$(find_root); then
  echo "gradle_root=$root" >> "$GITHUB_ENV"
  echo "::notice title=Gradle Root::Using $root"
  exit 0
else
  echo "::error::Could not find Gradle root. Ensure settings.gradle exists."
  exit 1
fi
