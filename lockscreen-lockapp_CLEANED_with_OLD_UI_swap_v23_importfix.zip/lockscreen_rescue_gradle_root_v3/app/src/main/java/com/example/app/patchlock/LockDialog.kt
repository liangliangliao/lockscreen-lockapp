package com.example.app.patchlock
import android.R
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.fragment.app.FragmentActivity
import android.app.Activity

import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.fragment.app.DialogFragment

/**
 * Minimal lock dialog to avoid syntax/balance errors and compile safely.
 * It exposes the same API: LockDialog.show(FragmentActivity)
 */
object LockDialog {
    private const val TAG = "PatchLockDialog"
    @Volatile private var isShowing: Boolean = false

    fun show(fa: FragmentActivity) {
        if (isShowing) return
        val dialog = UnlockDialog()
        dialog.isCancelable = false
        dialog.show(fa.supportFragmentManager, TAG)
    }

    class UnlockDialog : DialogFragment() {
        override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
        ): View {
            val root = FrameLayout(requireContext())
            val ok = Button(requireContext()).apply {
                text = getString(R.string.ok)
                setOnClickListener {
                    // Report success to possible listeners and close
                    parentFragmentManager.setFragmentResult("unlock", Bundle())
                    dismissAllowingStateLoss()
                }
            }
            root.addView(ok)
            return root
        }

        override fun onStart() {
            super.onStart()
            isShowing = true
        }

        override fun onDestroyView() {
            super.onDestroyView()
            isShowing = false
        }
    }
}



object LockDialogHelpers {
    fun show(activity: Activity) {
        if (activity is androidx.fragment.app.FragmentActivity) {
            LockDialog.show(activity)
        } else {
            // no-op for non-FragmentActivity; consider using a toast or log
        }
    }
}
