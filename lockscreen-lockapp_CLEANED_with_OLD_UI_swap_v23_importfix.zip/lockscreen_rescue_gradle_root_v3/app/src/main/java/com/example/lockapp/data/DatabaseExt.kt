package com.example.lockapp.data

import android.content.Context

/** Convenience top-level function to mirror the old code's `database(context)` helper. */
fun database(ctx: Context): AppDatabase = AppDatabase.get(ctx)
