package com.example.lockapp.service
import android.app.*
import android.content.*
import androidx.core.app.NotificationCompat
import com.example.lockapp.LauncherActivity
import com.example.lockapp.data.LockStateStore

class GatekeeperService : Service() {
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> LockStateStore.setLocked(context, true)
                Intent.ACTION_SCREEN_ON  -> showGate(context)
            }
        }
    }
    override fun onBind(intent: Intent?) = null
    override fun onCreate() {
        super.onCreate()
        startForegroundWithNotification()
        registerReceiver(screenReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        })
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(screenReceiver) } catch (_: Throwable) {}
    }
    private fun startForegroundWithNotification() {
        val chId = "gatekeeper_channel"
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(chId) == null) {
            nm.createNotificationChannel(NotificationChannel(chId, "Gatekeeper", NotificationManager.IMPORTANCE_MIN))
        }
        val pi = PendingIntent.getActivity(this, 0,
            Intent(this, LauncherActivity::class.java).putExtra("forceLock", true),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(this, chId)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("Lock Screen Active")
            .setContentText("Tap to unlock")
            .setOngoing(true)
            .setContentIntent(pi).build()
        startForeground(101, n)
    }
    private fun showGate(context: Context) {
        val it = Intent(context, LauncherActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("forceLock", true)
        }
        try { context.startActivity(it) } catch (_: Throwable) {
            val chId = "gatekeeper_alert"
            val nm = context.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(chId) == null) {
                val ch = NotificationChannel(chId, "Gate prompt", NotificationManager.IMPORTANCE_HIGH)
                ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                nm.createNotificationChannel(ch)
            }
            val pi = PendingIntent.getActivity(context, 1, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = NotificationCompat.Builder(context, chId)
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentTitle("需要解锁").setContentText("请验证密码继续")
                .setCategory(Notification.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setFullScreenIntent(pi, true).build()
            nm.notify(202, n)
        }
    }
}