// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    // No top-level plugins needed here
}

tasks.register<Delete>("clean") {
    delete(rootProject.buildDir)
}