package com.example.app.patchlock

import android.app.Activity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentActivity

object LockDialog {
    fun show(activity: Activity) {
        val fm = (activity as? FragmentActivity)?.supportFragmentManager ?: return
        if (fm.findFragmentByTag("patch_lock") != null) return
        PasswordDialogFragment().show(fm, "patch_lock")
    }
}

class PasswordDialogFragment : DialogFragment() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        isCancelable = false
    }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.patch_fragment_password_dialog, container, false)
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val et = view.findViewById<EditText>(R.id.etPassword)
        val btn = view.findViewById<Button>(R.id.btnUnlock)
        btn.setOnClickListener {
            val input = et.text?.toString()?.trim() ?: ""
            // TODO: 这里可以替换为你现有的密码校验逻辑；默认 1234 通过。
            if (input == "1234") {
                AppLockState.markUnlocked()
                dismissAllowingStateLoss()
            } else {
                Toast.makeText(requireContext(), "Wrong password, try 1234", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
