package com.example.lockapp.receiver

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.R
import com.example.lockapp.data.LockConfigStore
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.ui.LockActivity

/**
 * Static receiver for ACTION_USER_PRESENT to surface the lock screen immediately
 * after system keyguard is dismissed, even when the app process was not alive.
 */
class UserPresentReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!LockConfigStore.isArmed(context)) return

        // Mark that our app requires unlock
        LockStateStore.setRequireUnlock(context, true)

        // Ensure a high-importance channel exists
        val channelId = "lock_fullscreen"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(
                channelId,
                "Lock Screen",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Immediate unlock prompt"
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                setShowBadge(false)
            }
            nm.createNotificationChannel(ch)
        }

        val toLock = Intent(context, LockActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .setAction("com.example.lockapp.ACTION_LOCK")

        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                PendingIntent.FLAG_IMMUTABLE
            else 0)

        val pi = PendingIntent.getActivity(context, 2001, toLock, flags)

        val nb = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle(context.getString(R.string.app_name))
            .setContentText("请输入密码以继续")
            .setCategory(Notification.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .setOngoing(false)
            .setFullScreenIntent(pi, true)

        NotificationManagerCompat.from(context).notify(2002, nb.build())
    }
}
