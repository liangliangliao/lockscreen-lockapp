plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.kapt")
}

android {
    // Ensure legacy package is excluded from compilation (minimal, non-destructive change)
                // sourceSets exclude removed; replaced by task-level excludes for reliability


// cleaned by fix: removed excludes
    
