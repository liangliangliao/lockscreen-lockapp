package com.example.app.patchlock
import android.app.Application
object AppLifecycleHook {
    @JvmStatic fun install(app: Application) { /* no-op shim for build */ }
}
