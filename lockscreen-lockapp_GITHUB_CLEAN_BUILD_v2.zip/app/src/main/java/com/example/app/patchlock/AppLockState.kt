package com.example.app.patchlock
object AppLockState {
    @JvmStatic fun markLocked() {}
    @JvmStatic fun markUnlocked() {}
}
