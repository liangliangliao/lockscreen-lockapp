package com.example.lockapp.util
import android.content.Context
import com.example.lockapp.data.LockStateStore
import com.example.app.patchlock.AppLockState

object LockCoordinator {
    fun isLocked(context: Context): Boolean = LockStateStore.isLocked(context)
    fun markLocked(context: Context) {
        LockStateStore.setLocked(context, true)
        AppLockState.markLocked()
    }
    fun markUnlocked(context: Context) {
        LockStateStore.setLocked(context, false)
        AppLockState.markUnlocked()
    }
}
