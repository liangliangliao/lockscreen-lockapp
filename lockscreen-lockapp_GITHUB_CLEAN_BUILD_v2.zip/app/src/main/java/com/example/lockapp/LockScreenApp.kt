package com.example.lockapp
import android.app.Application
import androidx.room.Room
import com.example.lockapp.data.AppDatabase
import com.example.app.patchlock.AppLifecycleHook

class LockScreenApp : Application() {
    lateinit var database: AppDatabase
    override fun onCreate() {
        super.onCreate()
        AppLifecycleHook.install(this)
        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "image_password.db"
        ).build()
    }
}
