package com.example.lockapp.setup
import android.content.Context
import android.provider.Settings

object SettingsGuideHelpers {
    fun isBatteryOptDisabled(ctx: Context): Boolean {
        return try {
            Settings.Global.getInt(ctx.contentResolver, "stay_on_while_plugged_in", 0) != 0
        } catch (_: Throwable) { false }
    }
}
