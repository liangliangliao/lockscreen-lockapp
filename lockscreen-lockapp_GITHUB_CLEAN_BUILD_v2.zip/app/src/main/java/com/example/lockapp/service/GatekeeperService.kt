package com.example.lockapp.service
import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.app.PendingIntent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.R
import com.example.lockapp.LockScreenActivity

class GatekeeperService : Service() {
    private val CH_ID = "lock_gate_fsi"
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureChannel()
        val pi = PendingIntent.getActivity(
            this, 1,
            Intent(this, LockScreenActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(this, CH_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("锁屏守护已激活")
            .setContentText("用于在亮屏时拉起伪锁屏")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setFullScreenIntent(pi, true)
            .setAutoCancel(true)
        NotificationManagerCompat.from(this).notify(1002, builder.build())
        return START_NOT_STICKY
    }

    private fun ensureChannel() {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val mgr = getSystemService(android.app.NotificationManager::class.java)
            if (mgr.getNotificationChannel(CH_ID)==null) {
                val ch = android.app.NotificationChannel(CH_ID, "Lock Gate FSI", android.app.NotificationManager.IMPORTANCE_HIGH)
                ch.description = "用于伪锁屏的全屏通知"
                ch.setBypassDnd(true)
                mgr.createNotificationChannel(ch)
            }
        }
    }
}
