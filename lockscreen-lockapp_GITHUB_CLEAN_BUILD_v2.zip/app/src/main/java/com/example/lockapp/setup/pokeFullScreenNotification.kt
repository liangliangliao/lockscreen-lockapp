package com.example.lockapp.setup
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.R
import com.example.lockapp.LockScreenActivity

fun pokeFullScreenNotification(ctx: Context) {
    val chId = "lock_gate_fsi"
    if (android.os.Build.VERSION.SDK_INT >= 26) {
        val mgr = ctx.getSystemService(android.app.NotificationManager::class.java)
        if (mgr.getNotificationChannel(chId)==null) {
            val ch = android.app.NotificationChannel(chId, "Lock Gate FSI", android.app.NotificationManager.IMPORTANCE_HIGH)
            ch.setBypassDnd(true)
            ch.description = "用于伪锁屏的全屏通知"
            mgr.createNotificationChannel(ch)
        }
    }
    val pi = PendingIntent.getActivity(
        ctx, 2,
        Intent(ctx, LockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val b = NotificationCompat.Builder(ctx, chId)
        .setSmallIcon(R.mipmap.ic_launcher)
        .setContentTitle("测试全屏通知")
        .setContentText("用于拉起伪锁屏界面")
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setFullScreenIntent(pi, true)
        .setAutoCancel(true)
    NotificationManagerCompat.from(ctx).notify(1003, b.build())
}
