package com.example.lockapp.util
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.R
import com.example.lockapp.LockScreenActivity

object LockFsNotifier {
    private const val CH_ID = "lock_gate_fsi"

    fun showHeadsUp(ctx: Context, title: String, msg: String) {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val mgr = ctx.getSystemService(android.app.NotificationManager::class.java)
            if (mgr.getNotificationChannel(CH_ID)==null) {
                val c = android.app.NotificationChannel(CH_ID, "Lock Gate FSI", android.app.NotificationManager.IMPORTANCE_HIGH)
                c.setBypassDnd(true)
                mgr.createNotificationChannel(c)
            }
        }
        val pi = PendingIntent.getActivity(
            ctx, 3,
            Intent(ctx, LockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(ctx, CH_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(msg)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setFullScreenIntent(pi, true)
            .setAutoCancel(true)
        NotificationManagerCompat.from(ctx).notify(1004, b.build())
    }
}
