// BUILD TAG: LOCKAPP-FSI-FIX-CI-20250907T021838Z

package com.example.lockapp.util
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.content.Intent
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R

import android.content.Context
import android.os.PowerManager

object WakeHelper {
    @JvmStatic
    fun acquire(ctx: Context, tag: String, timeoutMs: Long = 2500L) {
        try {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lockapp:$tag")
            wl.setReferenceCounted(false)
            wl.acquire(timeoutMs)
            DebugLog.w("Wake", "Acquire PARTIAL_WAKE_LOCK($tag) for ${timeoutMs}ms")
        } catch (t: Throwable) {
            DebugLog.e("Wake", "Acquire wakelock failed: ${t.message}", t)
        }
    }
}
