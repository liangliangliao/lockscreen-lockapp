// BUILD TAG: LOCKAPP-FSI-FIX-CI-20250907T031900Z
package com.example.lockapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import com.example.lockapp.util.DebugLog

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DebugLog.w("MainActivity", "started")
        // UI omitted for CI build; add Compose/view content here if needed.
    }
}
