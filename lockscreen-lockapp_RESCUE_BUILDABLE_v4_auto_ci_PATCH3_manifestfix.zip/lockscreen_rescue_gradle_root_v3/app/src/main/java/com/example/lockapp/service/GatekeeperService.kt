package com.example.lockapp.service

import android.app.*
import android.content.*
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.lockapp.R
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.util.DebugToasts

class GatekeeperService : Service() {
    companion object {
        const val CHANNEL_ID = "lock_gk_channel"
        const val ACTION_SHOW_LOCK = "com.example.lockapp.SHOW_LOCK"
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (Intent.ACTION_SCREEN_ON == intent.action) {
                DebugToasts.show(context, "Screen ON → showing lock")
                showFullScreen()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(1, buildOngoing())
        // dynamic register screen ON
        val filter = IntentFilter(Intent.ACTION_SCREEN_ON)
        registerReceiver(screenReceiver, filter)
        DebugToasts.show(this, "GatekeeperService started & receiver registered")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_SHOW_LOCK) {
            showFullScreen()
        }
        return START_STICKY
    }

    private fun buildOngoing(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, LockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Lock running")
            .setContentText("Watching for screen on")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun showFullScreen() {
        val fullScreenIntent = Intent(this, LockScreenActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            this, 1, fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        val n = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Unlock required")
            .setContentText("Tap to unlock")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(Notification.CATEGORY_CALL)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setAutoCancel(true)
            .build()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(99, n)
        DebugToasts.show(this, "Full-screen notification posted")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Gatekeeper", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Lock foreground & full-screen"
                    setShowBadge(false)
                }
            )
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(screenReceiver) } catch (_:Throwable) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}