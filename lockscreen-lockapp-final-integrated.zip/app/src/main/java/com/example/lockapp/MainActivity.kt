
package com.example.lockapp

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.tooling.preview.Preview
import com.example.lockapp.ui.AppTheme
import com.example.lockapp.service.ScreenGuardService

class MainActivity : ComponentActivity() {

    private val notifPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* no-op */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33) {
            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        // Start the guard service
        startService(Intent(this, ScreenGuardService::class.java))

        setContent {
            AppTheme {
                Surface { SetupScreen() }
            }
        }
    }
}

@Composable
fun SetupScreen() {
    var pwd by remember { mutableStateOf("") }
    var bg by remember { mutableStateOf("") }

    val ctx = androidx.compose.ui.platform.LocalContext.current

    Column(modifier = androidx.compose.ui.Modifier
        .padding(16.dp)) {
        Text(text = "锁屏守护已开启，设置解锁密码与背景（可选）")
        Spacer(modifier = androidx.compose.ui.Modifier.height(12.dp))
        OutlinedTextField(
            value = pwd,
            onValueChange = { pwd = it },
            label = { Text("解锁密码（明文）") }
        )
        Spacer(modifier = androidx.compose.ui.Modifier.height(12.dp))
        OutlinedTextField(
            value = bg,
            onValueChange = { bg = it },
            label = { Text("背景图片URI（可留空）") }
        )
        Spacer(modifier = androidx.compose.ui.Modifier.height(12.dp))
        Button(onClick = {
            val sp = ctx.getSharedPreferences("lock_prefs", MODE_PRIVATE)
            sp.edit().putString("password", pwd).putString("bg_uri", bg).apply()
            ctx.startActivity(
                Intent(ctx, com.example.lockapp.ui.LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }) { Text("保存并测试锁屏") }

        Spacer(modifier = androidx.compose.ui.Modifier.height(24.dp))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = ctx.getSystemService(android.os.PowerManager::class.java)
            val ignoring = pm?.isIgnoringBatteryOptimizations(ctx.packageName) == true
            if (!ignoring) {
                Button(onClick = {
                    val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:${ctx.packageName}")
                    }
                    ctx.startActivity(i)
                }) { Text("允许电池后台运行") }
            }
        }
    }
}

@Preview
@Composable
fun PreviewSetup() { AppTheme { Surface { SetupScreen() } } }
