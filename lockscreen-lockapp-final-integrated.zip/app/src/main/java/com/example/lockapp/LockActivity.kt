package com.example.lockapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.lockapp.ui.Theme

class LockActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Theme {
                LockScreen(
                    expected = getSharedPreferences("lockapp", MODE_PRIVATE).getString("pwd", "") ?: "",
                    bg = getSharedPreferences("lockapp", MODE_PRIVATE).getString("bg", null)
                ) { success ->
                    if (success) finish()
                }
            }
        }
    }

    override fun onBackPressed() {
        // 允许返回，这个版本不屏蔽导航键
        super.onBackPressed()
    }
}

@Composable
fun LockScreen(expected: String, bg: String?, onResult: (Boolean) -> Unit) {
    var input by remember { mutableStateOf(TextFieldValue("")) }
    Box(Modifier.fillMaxSize()) {
        if (bg != null) {
            AsyncImage(
                model = ImageRequest.Builder(androidx.compose.ui.platform.LocalContext.current)
                    .data(Uri.parse(bg)).build(),
                contentDescription = null,
                modifier = Modifier.fillMaxSize()
            )
        }
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("请输入密码", textAlign = TextAlign.Center)
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                label = { Text("明文密码") }
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = { onResult(input.text == expected) }) { Text("解锁") }
        }
    }
}
