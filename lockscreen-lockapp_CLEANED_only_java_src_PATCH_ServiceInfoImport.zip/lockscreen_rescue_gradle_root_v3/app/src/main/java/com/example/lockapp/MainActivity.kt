package com.example.lockapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.example.lockapp.service.GatekeeperService
import com.example.lockapp.util.DebugToasts

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // minimal UI
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val b1 = Button(context).apply {
                text = "Start foreground service"
                setOnClickListener {
                    startForegroundService(Intent(context, GatekeeperService::class.java))
                    DebugToasts.toast("requested startForegroundService")
                }
            }
            val b2 = Button(context).apply {
                text = "Show lock now"
                setOnClickListener {
                    val i = Intent(context, GatekeeperService::class.java).apply {
                        action = "ACTION_POST_LOCK"
                    }
                    startService(i)
                    DebugToasts.toast("requested show lock")
                }
            }
            addView(b1)
            addView(b2)
        }
        setContentView(layout)

        // auto start FGS once
        startForegroundService(Intent(this, GatekeeperService::class.java))
        DebugToasts.toast("started foreground service")
    }
}
