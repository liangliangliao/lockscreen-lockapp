package com.example.lockapp.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ImagePasswordDao {

    @Query("SELECT * FROM ImagePassword ORDER BY id ASC")
    fun all(): Flow<List<ImagePassword>>

    @Query("SELECT * FROM ImagePassword ORDER BY id ASC")
    suspend fun getAllOnce(): List<ImagePassword>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: ImagePassword): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(entity: ImagePassword): Long

    @Update
    suspend fun update(entity: ImagePassword): Int

    @Delete
    suspend fun delete(entity: ImagePassword)

    @Query("DELETE FROM ImagePassword")
    suspend fun clear()
}
