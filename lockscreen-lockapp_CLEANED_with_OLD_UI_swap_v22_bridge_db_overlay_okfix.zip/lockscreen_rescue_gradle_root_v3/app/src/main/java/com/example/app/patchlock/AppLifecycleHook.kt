package com.example.app.patchlock

import android.app.Activity
import android.app.Application
import android.os.Bundle
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner

object AppLifecycleHook {
    // 默认关闭对话框锁入口，避免与系统锁屏 Activity 并存
    private const val USE_DIALOG_LOCK: Boolean = false
    @Volatile private var top: Activity? = null

    fun install(app: Application) {
        app.registerActivityLifecycleCallbacks(object: Application.ActivityLifecycleCallbacks {
            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
            override fun onActivityStarted(activity: Activity) {}
            override fun onActivityResumed(activity: Activity) {
                top = activity
                try { LockPositionKeeper.capture(activity) } catch (_: Throwable) {}
            }
            override fun onActivityPaused(activity: Activity) {
                if (top === activity) top = null
            }
            override fun onActivityStopped(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {}
        })

        ProcessLifecycleOwner.get().lifecycle.addObserver(object: DefaultLifecycleObserver {
            override fun onStart(owner: LifecycleOwner) {
                if (!USE_DIALOG_LOCK) return
                val activity = top ?: return
                if (com.example.lockapp.util.LockVisibilityTracker.visible) return
                if (com.example.lockapp.util.LockCoordinator.isLocked(activity)
                    && com.example.lockapp.util.LockCoordinator.requestShowOnce()
                    && com.example.lockapp.util.LockCoordinator.tryEnterShowing()
                ) {
                    LockDialogHelpers.show(activity)
                }
            }
        })
    }
}
