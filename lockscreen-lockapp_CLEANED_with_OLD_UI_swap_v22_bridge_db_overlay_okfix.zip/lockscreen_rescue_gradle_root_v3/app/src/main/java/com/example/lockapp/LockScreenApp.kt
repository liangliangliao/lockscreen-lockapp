package com.example.lockapp

import android.app.Application

class LockScreenApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppGlobals.init(this)
    }
}
