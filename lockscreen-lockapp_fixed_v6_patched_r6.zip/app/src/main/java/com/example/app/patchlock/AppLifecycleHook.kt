package com.example.app.patchlock

import android.app.Activity
import android.app.Application
import android.os.Bundle
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner

object AppLifecycleHook {
    private const val USE_DIALOG_LOCK: Boolean = false
    @Volatile private var top: Activity? = null

    fun install(app: Application) {
        app.registerActivityLifecycleCallbacks(object: Application.ActivityLifecycleCallbacks {
            override fun onActivityResumed(activity: Activity) {
                top = activity
                LockPositionKeeper.capture(activity)
            }
            override fun onActivityPaused(activity: Activity) { if (top==activity) top = null }
            override fun onActivityCreated(a: Activity, b: Bundle?) {}
            override fun onActivityStarted(a: Activity) {}
            override fun onActivityStopped(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(a: Activity) {}
        })
        ProcessLifecycleOwner.get().lifecycle.addObserver(object: DefaultLifecycleObserver {
            override fun onStart(owner: LifecycleOwner) {
                if (!USE_DIALOG_LOCK) return
                top?.let { activity ->
                    if (com.example.lockapp.util.LockVisibilityTracker.visible) return
                    if (com.example.lockapp.util.LockCoordinator.isLocked(activity)
                        && com.example.lockapp.util.LockCoordinator.requestShowOnce()
                        && com.example.lockapp.util.LockCoordinator.tryEnterShowing()
                    ) {
                        LockDialog.show(activity)
                    }
                }
            }
                }
            }
        })
    }
}
