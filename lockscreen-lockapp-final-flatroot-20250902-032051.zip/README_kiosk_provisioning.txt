
Notes for kiosk-like locking:
- This app uses Android screen pinning (LockTask) when showing the custom lock screen to block Home/Recents.
- On devices where the app is not device-owner, the first time it may prompt the user to enable screen pinning.
- For absolute kiosk mode (no exit), set the app as Device Owner and whitelist it for lock task.
- The lock is enforced on every screen-on; after successful unlock, it stays unlocked until the next screen-off.
