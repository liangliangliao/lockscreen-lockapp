package com.example.lockapp.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import com.example.lockapp.ui.LockActivity
import com.example.lockapp.AppVisibilityTracker
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.data.LockConfigStore

class GatekeeperService : Service() {

    override fun onCreate() {
        super.onCreate()
        startForegroundWithNotification()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        maybePrompt()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startForegroundWithNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = ensureChannel(this, nm)
        val notif: Notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("Lock service running")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(42, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(42, notif)
        }
    }

    private fun ensureChannel(ctx: Context, nm: NotificationManager): String {
        val id = "locksvc"
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(id, "Lock Service", NotificationManager.IMPORTANCE_LOW)
            ch.setSound(null, null)
            nm.createNotificationChannel(ch)
        }
        return id
    }

    private fun maybePrompt() {
        if (!LockConfigStore.isArmed(this) || !LockStateStore.isRequireUnlock(this)) return

        if (AppVisibilityTracker.isInForeground()) {
            // App is in foreground: start lock activity directly
            val i = Intent(this, LockActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(i)
        } else {
            // App is background or just awakened: use full-screen notification
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channelId = ensureChannel(this, nm)
            val pi = PendingIntent.getActivity(
                this, 1001,
                Intent(this, LockActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                (PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0))
            )
            val nb = NotificationCompat.Builder(this, channelId)
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentTitle("解锁")
                .setContentText("点击以输入密码")
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setFullScreenIntent(pi, true)
                .build()
            nm.notify(1002, nb)
        }
    }
}
