package com.example.lockapp.data

import android.content.Context

/**
 * Holds the currently chosen wallpaper (uri) and expected password.
 */
object ActiveLockStore {
    private const val PREF = "active_lock_store"
    private const val KEY_URI = "uri"
    private const val KEY_PWD = "pwd"

    /** Update both values; pass null to keep existing. */
    fun set(context: Context, uri: String?, password: String?) {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val editor = sp.edit()
        if (uri != null) editor.putString(KEY_URI, uri)
        if (password != null) editor.putString(KEY_PWD, password)
        editor.apply()
    }

    fun getUri(context: Context): String? =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_URI, null)

    fun getPwd(context: Context): String? =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_PWD, null)

    // Back-compat helpers
    fun setActive(context: Context, uri: String?, password: String?) = set(context, uri, password)
    fun getActiveUri(context: Context): String? = getUri(context)
    fun getActivePassword(context: Context): String? = getPwd(context)

    /** Back-compat for older code paths that pass (id, uri). */
    fun setActive(context: Context, id: Long, uri: String) {
        set(context, uri, null)
    }
}
