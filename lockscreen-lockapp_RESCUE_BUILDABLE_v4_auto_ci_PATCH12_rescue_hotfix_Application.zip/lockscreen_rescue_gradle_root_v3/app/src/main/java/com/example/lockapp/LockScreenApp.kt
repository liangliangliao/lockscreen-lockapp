package com.example.lockapp

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.widget.Toast

class LockScreenApp : Application() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
        // Lightweight debug toast to confirm Application is created
        try {
            Toast.makeText(this, "LockScreenApp initialized", Toast.LENGTH_SHORT).show()
        } catch (_: Throwable) {
            // ignore (e.g., if toasts are suppressed)
        }
        AppGlobals.app = this
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)

            val fg = NotificationChannel(
                "lock_fg",
                "LockApp Foreground Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Foreground service channel for lock app"
                setShowBadge(false)
            }

            val fsi = NotificationChannel(
                "lock_fsi",
                "LockApp Fullscreen Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Heads-up/fullscreen alerts for lock screen prompt"
                setShowBadge(false)
                enableVibration(false)
            }

            mgr?.createNotificationChannel(fg)
            mgr?.createNotificationChannel(fsi)
        }
    }
}

object AppGlobals {
    @JvmStatic
    lateinit var app: Application
        internal set
}
