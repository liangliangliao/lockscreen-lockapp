package com.example.lockapp.setup

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.Modifier
import androidx.compose.runtime.*
import com.example.lockapp.ui.theme.LockScreenAppTheme

class SetupActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            LockScreenAppTheme {
                GuardSetupScreen(onAllDone = {
                    getSharedPreferences("onboarding", MODE_PRIVATE)
                        .edit().putBoolean("done", true).apply()
                    finish()
                })
            }
        }
    }
}
