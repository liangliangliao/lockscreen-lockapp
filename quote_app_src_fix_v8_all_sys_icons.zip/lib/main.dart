import 'package:flutter/material.dart';
import 'services/notification_service.dart';
import 'services/scheduler_service.dart';
import 'data/dao.dart';
import 'pages/home_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.init();
  await SchedulerService.initBackground();
  await SchedulerService.registerPeriodic();

  // Seed a default quote for testing
  await QuoteDao().seedDefaultQuote();

  runApp(const MyApp());

  // Non-blocking bootstrap to avoid blocking first frame
  Future.microtask(() async {
    try {
      // Keep heavy inits out of the critical path
      // e.g. await initDatabase(); await initNotifications(); await initWorkmanager();
    } catch (e, st) {
      // debugPrint('Bootstrap error: $e\n$st');
    }
  });
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '名人名言',
      theme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}
