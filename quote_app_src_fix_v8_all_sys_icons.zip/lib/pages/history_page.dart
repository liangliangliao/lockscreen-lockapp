import 'package:flutter/material.dart';
import '../data/dao.dart';

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});

  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  final _dao = QuoteDao();
  final _searchCtrl = TextEditingController();
  final _scroll = ScrollController();

  List<Map<String, dynamic>> items = [];
  int offset = 0;
  bool loading = false;
  String query = "";

  @override
  void initState() {
    super.initState();
    _load();
    _scroll.addListener(() {
      if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 200 && !loading) {
        _loadMore();
      }
    });
    _searchCtrl.addListener(() {
      query = _searchCtrl.text.trim();
      offset = 0;
      items.clear();
      _load();
    });
  }

  Future _load() async {
    setState(() => loading = true);
    final rows = query.isEmpty ? await _dao.page(offset: offset, limit: 100) : await _dao.search(query, offset: offset, limit: 100);
    items.addAll(rows);
    offset += rows.length;
    setState(() => loading = false);
  }

  Future _loadMore() async {
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('历史记录')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _searchCtrl,
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: '搜索文本/作者/出处'),
            ),
          ),
          Expanded(
            child: ListView.separated(
              controller: _scroll,
              itemCount: items.length + 1,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, i) {
                if (i >= items.length) {
                  return Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Center(child: loading ? const CircularProgressIndicator() : const Text('— 没有更多了 —')),
                  );
                }
                final it = items[i];
                return ListTile(
                  title: Text(it['text'] as String),
                  subtitle: Text('${it['author']} · ${it['source']}'),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
