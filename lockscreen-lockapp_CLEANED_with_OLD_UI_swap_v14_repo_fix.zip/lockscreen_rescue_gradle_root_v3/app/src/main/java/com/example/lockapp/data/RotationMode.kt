package com.example.lockapp.data
enum class RotationMode { SEQUENTIAL, SHUFFLE, RANDOM }
