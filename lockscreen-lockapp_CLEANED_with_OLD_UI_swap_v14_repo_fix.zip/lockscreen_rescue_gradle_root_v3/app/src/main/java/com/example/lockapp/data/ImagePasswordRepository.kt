package com.example.lockapp.data

import kotlinx.coroutines.flow.Flow

class ImagePasswordRepository(
    private val dao: ImagePasswordDao
) {
    fun all(): Flow<List<ImagePassword>> = dao.all()

    suspend fun insert(p: ImagePassword): Long = dao.insert(p)

    suspend fun delete(p: ImagePassword) = dao.delete(p)

    suspend fun clear() = dao.clear()
}
