package com.example.lockapp.service

import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.example.lockapp.setup.pokeFullScreenNotification

/**
 * GatekeeperService: 负责在需要时触发一次全屏通知（FSI）来拉起锁屏界面。
 * 为了修复编译，仅保留触发入口，原业务逻辑可在后续按需补回。
 */
class GatekeeperService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        pokeFullScreenNotification(this)
        stopSelf(startId)
        return START_NOT_STICKY
    }
}
