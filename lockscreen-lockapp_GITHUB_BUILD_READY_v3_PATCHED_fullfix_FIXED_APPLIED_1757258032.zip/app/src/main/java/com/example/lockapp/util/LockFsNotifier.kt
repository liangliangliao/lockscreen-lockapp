package com.example.lockapp.util

import android.app.PendingIntent
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.setup.buildFullScreenNotification

object LockFsNotifier {
    fun showFsNotification(ctx: Context, fullScreenPi: PendingIntent, contentPi: PendingIntent? = null, id: Int = 12002) {
        val n = buildFullScreenNotification(ctx, fullScreenPi, contentPi)
        NotificationManagerCompat.from(ctx).notify(id, n)
    }
}
