package com.example.lockapp

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.setup.pokeFullScreenNotification

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 最小实现：进入页面时尝试准备一次FSI渠道（不一定立刻发送）
    }

    override fun onResume() {
        super.onResume()
        // 可选：调试时一键触发FSI
        // pokeFullScreenNotification(this)
    }
}
