package com.example.lockapp.setup

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat.getSystemService
import com.example.lockapp.R
import com.example.lockapp.MainActivity

private const val CH_ID = "lock_fullscreen_channel"
private const val CH_NAME = "Lock FullScreen"
private const val NOTIF_ID_FSI = 12001

fun pokeFullScreenNotification(ctx: Context) {
    val fullIntent = PendingIntent.getActivity(
        ctx, 0,
        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
    )
    val notif = buildFullScreenNotification(ctx, fullIntent, content = fullIntent)
    NotificationManagerCompat.from(ctx).notify(NOTIF_ID_FSI, notif)
}

fun buildFullScreenNotification(ctx: Context, fullScreen: PendingIntent, content: PendingIntent? = null): Notification {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val nm = getSystemService(ctx, NotificationManager::class.java)
        if (nm?.getNotificationChannel(CH_ID) == null) {
            nm?.createNotificationChannel(
                NotificationChannel(CH_ID, CH_NAME, NotificationManager.IMPORTANCE_HIGH).apply {
                    setShowBadge(false)
                }
            )
        }
    }
    val b = NotificationCompat.Builder(ctx, CH_ID)
        .setSmallIcon(R.mipmap.ic_launcher)
        .setContentTitle("正在唤起锁屏界面")
        .setPriority(NotificationCompat.PRIORITY_MAX)
        .setCategory(Notification.CATEGORY_CALL)
        .setAutoCancel(true)
        .setFullScreenIntent(fullScreen, true)

    if (content != null) b.setContentIntent(content)
    return b.build()
}
