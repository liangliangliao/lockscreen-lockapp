package com.example.lockapp.util

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import androidx.core.app.NotificationCompat

/**
 * Minimal shims to set full-screen intent and return a built Notification.
 */
fun setFullScreenIntent(builder: NotificationCompat.Builder, fullScreenPi: PendingIntent): Notification {
    builder.setFullScreenIntent(fullScreenPi, true)
    return builder.build()
}

fun setFullScreenIntent(ctx: Context, builder: NotificationCompat.Builder, fullScreenPi: PendingIntent): Notification {
    builder.setFullScreenIntent(fullScreenPi, true)
    return builder.build()
}
