package com.example.app.patchlock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.getSystemService
import androidx.lifecycle.LifecycleService
import com.example.lockapp.R
import com.example.lockapp.MainActivity

/**
 * 轻量级前台服务：用于保持应用常驻并保证广播与FSI的稳定发出。
 * 注意：仅做最小改动以修复编译问题，不改变既有业务流程。
 */
class LockGuardService : LifecycleService() {

    override fun onCreate() {
        super.onCreate()
        ensureChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // 点击通知回到应用
        val contentIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        val builder = NotificationCompat.Builder(this, "lock_guard_fgs")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("锁屏保护运行中")
            .setContentText("保持常驻以提高FSI成功率")
            .setCategory(Notification.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setContentIntent(contentIntent)

        val notif = builder.build()
        startForeground(1001, notif)
        return START_STICKY
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService<NotificationManager>() ?: return
            val ch = NotificationChannel("lock_guard_fgs", "Lock Guard Service", NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
    }
}
