package com.example.lockapp.data

import android.content.Context

/**
 * Single source of truth for active lock wallpaper (uri) and password.
 * Provides canonical API (set/getUri/getPwd) and backward-compatible aliases (getActiveUri/setActive).
 */
object ActiveLockStore {
    private const val PREF = "active_lock_store"
    private const val KEY_URI = "uri"
    private const val KEY_PWD = "pwd"

    /** Update both uri and password. Any one can be null to keep previous. */
    fun set(context: Context, uri: String?, password: String?) {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val curUri = sp.getString(KEY_URI, null)
        val curPwd = sp.getString(KEY_PWD, null)
        sp.edit()
            .putString(KEY_URI, uri ?: curUri)
            .putString(KEY_PWD, password ?: curPwd)
            .apply()
    }

    fun getUri(context: Context): String? =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_URI, null)

    fun getPwd(context: Context): String? =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_PWD, null)

    // --- Backward-compatible helpers ---
    fun setActive(context: Context, uri: String?, password: String?) = set(context, uri, password)
    fun getActiveUri(context: Context): String? = getUri(context)
    fun getActivePassword(context: Context): String? = getPwd(context)

    /** Overloads to absorb legacy call sites that passed an id/ts before uri. */
    fun setActive(context: Context, id: Long, uri: String?) = set(context, uri, getPwd(context))
    fun setActive(context: Context, id: Long?, uri: String?) = set(context, uri, getPwd(context))
    fun setActive(context: Context, id: Any?, uri: String?) = set(context, uri, getPwd(context))
}
