package com.example.app.patchlock

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class FullscreenLockActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } catch (_: Throwable) {}
        if (com.example.lockapp.util.LockCoordinator.isLocked(this)) {
            if (com.example.lockapp.util.LockCoordinator.requestShowOnce()) { LockDialog.show(this) }
        } else {
            finish()
        }
        supportFragmentManager.setFragmentResultListener("unlock", this) { _, _ ->
            com.example.lockapp.util.LockCoordinator.markUnlocked(this)
            LockPositionKeeper.restoreIfNeeded(this)
            finish()
            overridePendingTransition(0, 0)
        }
    }
}
