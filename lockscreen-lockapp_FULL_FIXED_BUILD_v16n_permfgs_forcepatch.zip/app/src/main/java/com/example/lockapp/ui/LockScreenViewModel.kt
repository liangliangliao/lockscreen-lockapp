package com.example.lockapp.ui
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.content.Context
import android.content.Intent
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.lockapp.data.ImagePassword
import com.example.lockapp.data.ImagePasswordRepository
import com.example.lockapp.data.RotationManager
import com.example.lockapp.data.RotationMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * ViewModel used by the lock screen activity. Determines which image should be displayed
 * according to the user's rotation settings and verifies passwords against the current entry.
 */
class LockScreenViewModel(
    private val repository: ImagePasswordRepository,
    private val rotationManager: RotationManager
) : ViewModel() {
    // Currently displayed image/password record. Null when no records exist.
    private val _currentEntry = MutableStateFlow<ImagePassword?>(null)
    val currentEntry: StateFlow<ImagePassword?> = _currentEntry

    // Expose unlock result: null = not attempted, true = success, false = failure.
    private val _unlockResult = MutableStateFlow<Boolean?>(null)
    val unlockResult: StateFlow<Boolean?> = _unlockResult

    init {
        // Load the next entry on initialization.
        viewModelScope.launch {
            loadNextEntry()
        }
    }

    /**
     * Computes the next image/password entry to show based on the rotation mode and the last
     * displayed index. Persists the new index via [RotationManager.setLastIndex].
     */
    private suspend fun loadNextEntry() {
        withContext(Dispatchers.IO) {
            val entries = repository.getAllOnce()
            if (entries.isEmpty()) {
                _currentEntry.value = null
                return@withContext
            }
            // Read rotation settings
            val mode = rotationManager.rotationMode.first()
            val lastIndex = rotationManager.lastIndex.first()
            // Compute next index
            val nextIndex = when (mode) {
                RotationMode.SEQUENTIAL -> {
                    val idx = (lastIndex + 1) % entries.size
                    if (lastIndex < 0) 0 else idx
                }
                RotationMode.SHUFFLE -> {
                    if (entries.size == 1) 0 else {
                        val indices = (entries.indices).toMutableList()
                        // Remove last index to avoid repeats if possible
                        if (lastIndex in indices && indices.size > 1) indices.remove(lastIndex)
                        indices.random()
                    }
                }
            }
            rotationManager.setLastIndex(nextIndex)
            _currentEntry.value = entries[nextIndex]
        }
    }

    /**
     * Verify the provided [password] against the current image's password. When correct
     * sets [_unlockResult] to true; otherwise sets it to false. Only the most recent result
     * is emitted. The caller should observe [unlockResult] and take appropriate action
     * (e.g. dismiss the lock screen on success).
     */
    fun verifyPassword(password: String) {
        val expected = currentEntry.value?.password
        _unlockResult.value = expected != null && expected == password
    }
}