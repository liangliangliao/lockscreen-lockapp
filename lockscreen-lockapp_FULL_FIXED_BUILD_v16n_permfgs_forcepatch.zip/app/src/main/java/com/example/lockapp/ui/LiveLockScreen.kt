package com.example.lockapp.ui
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.content.Context
import android.content.Intent
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import com.example.lockapp.LockScreenApp
import com.example.lockapp.data.ImagePassword
import com.example.lockapp.data.ImagePasswordRepository
import com.example.lockapp.data.RotationManager
import com.example.lockapp.data.RotationMode
import com.example.lockapp.data.ActiveLockStore

@Composable
fun LiveLockScreen(
    onUnlock: () -> Unit,
    onEmergency: () -> Unit = {}
) {
    val ctx = LocalContext.current
    var entry by remember { mutableStateOf<ImagePassword?>(null) }
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    // Pick next background (sequential/shuffle) and sync ActiveLockStore
    LaunchedEffect(Unit) {
        val db = (ctx.applicationContext as LockScreenApp).database
        val repo = ImagePasswordRepository(db.imagePasswordDao())
        val rotation = RotationManager(ctx)

        val all = withContext(Dispatchers.IO) { repo.getAllOnce() }
        if (all.isNotEmpty()) {
            val mode = rotation.rotationMode.first()
            val last = rotation.lastIndex.first()
            val next = when (mode) {
                RotationMode.SEQUENTIAL -> (last + 1).mod(all.size)
                RotationMode.SHUFFLE -> if (all.size == 1) 0 else {
                    val pool = all.indices.toMutableList()
                    if (last in pool && pool.size > 1) pool.remove(last)
                    pool.random()
                }
            }
            withContext(Dispatchers.IO) { rotation.setLastIndex(next) }
            entry = all[next]
            ActiveLockStore.set(ctx, entry!!.uri, entry!!.password)
        } else {
            entry = null
        }
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Background image (Coil)
            entry?.uri?.let { uriStr ->
                AsyncImage(
                    model = ImageRequest.Builder(ctx).data(uriStr).crossfade(true).build(),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            // Scrim overlay
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f)))

            // Bottom panel with multi-line input
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 20.dp, vertical = 24.dp),
                verticalArrangement = Arrangement.Bottom,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it; error = null },
                    placeholder = { Text("请输入解锁口令（支持换行，50字以上可见）") },
                    singleLine = false,
                    minLines = 4,
                    maxLines = 8,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp)
                )
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = {
                        val expected = entry?.password ?: ActiveLockStore.getPwd(ctx)
                        if (expected != null && text == expected) {
                            onUnlock()
                        } else {
                            error = "口令不正确"
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("解锁") }
                error?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }

    BackHandler(enabled = false) { /* Disable back */ }
}
