package com.example.app.patchlock
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.content.Context
import android.content.Intent
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R

object AppLockState {
    @Volatile private var locked: Boolean = true
    @Volatile private var lastDialogShownAt: Long = 0L
    private const val DEBOUNCE_MS = 1500L

    fun markLocked() { locked = true }
    fun markUnlocked() { locked = false }
    fun shouldLockNow(): Boolean = locked

    /** Allow showing lock dialog only once within a debounce window. */
    @Synchronized
    fun requestShowOnce(): Boolean {
        if (!locked) return false
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastDialogShownAt < DEBOUNCE_MS) return false
        lastDialogShownAt = now
        return true
    }
}
