package com.example.lockapp
import com.example.lockapp.util.Toaster

import android.app.KeyguardManager
import android.os.Bundle
import java.io.File
import android.net.Uri
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.lockapp.ui.LiveLockScreen
import com.example.lockapp.util.LockVisibilityTracker
import com.example.lockapp.util.DebugTracer

class LockScreenActivity : ComponentActivity() {

    private fun getPrefs() = getSharedPreferences("lockapp_prefs", MODE_PRIVATE)
    private fun cacheFile(): java.io.File = java.io.File(filesDir, "lock_bg.jpg")
    private fun loadLockBackground(): Pair<String, java.io.File?> {
        val cf = cacheFile()
        if (cf.exists() && cf.length() > 0L) {
            com.example.lockapp.util.DebugLog.w("LockScreen","bg source=cache path=" + cf.absolutePath)
            return "cache" to cf
        }
        val uriStr = getPrefs().getString("bg_uri", null)
        if (uriStr != null) {
            try {
                val uri = Uri.parse(uriStr)
                contentResolver.openInputStream(uri)?.use { ins ->
                    cf.outputStream().use { outs -> ins.copyTo(outs) }
                }
                if (cf.exists() && cf.length() > 0L) {
                    com.example.lockapp.util.DebugLog.w("LockScreen","bg source=uri cached=" + cf.absolutePath)
                    return "uri" to cf
                }
            } catch (t: Throwable) {
                com.example.lockapp.util.DebugLog.e("LockScreen","load from uri failed: " + t.message, t)
            }
        }
        com.example.lockapp.util.DebugLog.w("LockScreen","bg source=fallback")
        return "fallback" to null
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        
        val fromFsi = intent?.getBooleanExtra("from_fsi", false) == true || "com.example.lockapp.SHOW_LOCK_FROM_FSI" == intent?.action
if (!fromFsi) { Toaster.show5s(this, "伪锁屏：拒绝非FSI进入"); finish(); return }
Toaster.show5s(this, "伪锁屏：onCreate")
val fromFsi = intent?.getBooleanExtra("from_fsi", false) == true
        com.example.lockapp.util.DebugLog.w("LockScreen", "started (from_fsi=" + fromFsi + ")")
        val bg = loadLockBackground()
DebugTracer.w("LockScreen", "LockScreen onCreate")
        try { DebugTracer.notify(this, "Trace", "LockScreen onCreate") } catch (t: Throwable) { }
// Ensure we can appear above the keyguard and wake the screen
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        // Ask system to dismiss keyguard when possible
        getSystemService(KeyguardManager::class.java)
            ?.requestDismissKeyguard(this, null)

        setContent {
            LiveLockScreen(
                onEmergency = { /* no-op or start emergency activity if you have one */ },
                onUnlock = {
                    try { getSystemService(android.app.KeyguardManager::class.java)?.requestDismissKeyguard(this, null) } catch (_: Throwable) {}
                    com.example.lockapp.util.LockCoordinator.markUnlocked(this)
                    com.example.lockapp.util.LockCoordinator.leaveShowing()
                    finish()
                }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        
        Toaster.show5s(this, "伪锁屏：onResume")
DebugTracer.w("LockScreen", "LockScreen onResume")
        try { DebugTracer.notify(this, "Trace", "LockScreen onResume") } catch (t: Throwable) { }
LockVisibilityTracker.visible = true
    }

    override fun onDestroy() { super.onDestroy(); com.example.lockapp.util.LockVisibilityTracker.visible = false }

    override fun onPause() {
        super.onPause()
        LockVisibilityTracker.visible = false
    }
}