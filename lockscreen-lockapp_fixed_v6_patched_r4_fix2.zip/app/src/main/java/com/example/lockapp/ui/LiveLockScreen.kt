package com.example.lockapp.ui

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.border
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Spacer
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.room.Room
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.lockapp.data.ActiveLockStore
import com.example.lockapp.data.AppDatabase
import com.example.lockapp.data.ImagePassword
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.example.lockapp.data.RotationManager
import com.example.lockapp.data.RotationMode

@Composable
fun LiveLockScreen(
    onEmergency: () -> Unit = {},onUnlock: () -> Unit = {}) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val dao = remember { (ctx.applicationContext as com.example.lockapp.LockScreenApp).database.imagePasswordDao() }
    var entry by remember { mutableStateOf<ImagePassword?>(null) }
    var showInput by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var isBgLight by remember { mutableStateOf(false) }

        LaunchedEffect(Unit) {
        // Load entries and pick next based on rotation settings
        val repo = com.example.lockapp.data.ImagePasswordRepository(dao)
        val rotation = RotationManager(ctx)
        val all = withContext(Dispatchers.IO) { repo.getAllOnce() }
        if (all.isNotEmpty()) {
            val mode = rotation.rotationMode.first()
            val last = rotation.lastIndex.first()
            val next = when (mode) {
                RotationMode.SEQUENTIAL -> (last + 1).mod(all.size)
                RotationMode.SHUFFLE -> {
                    if (all.size == 1) 0 else {
                        val indices = all.indices.toMutableList()
                        if (last in indices && indices.size > 1) indices.remove(last)
                        indices.random()
                    }
                }
            }
            withContext(Dispatchers.IO) { rotation.setLastIndex(next) }
            entry = all[next]
            // Update active lock store for password continuity
            com.example.lockapp.data.ActiveLockStore.set(ctx, entry!!.uri, entry!!.password)
            // Preload image to detect luma (optional)
            withContext(Dispatchers.IO) {
                ctx.contentResolver.openInputStream(Uri.parse(entry!!.uri))?.use { input ->
                    val bmp = BitmapFactory.decodeStream(input)
                    if (bmp != null) {
                        // simple heuristic for background lightness
                        isBgLight = (bmp.getPixel(0,0) and 0x00FFFFFF) > 0x00777777
                    }
                }
            }
        } else {
            entry = null
        }
    }
BackHandler(enabled = showInput) { showInput = false }
    }
}