package com.example.lockapp

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class LockScreenApp : Application() {

    override fun onCreate() {
        super.onCreate()
        AppGlobals.app = this
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)
            val fg = NotificationChannel(
                "lock_fg",
                "Lock Foreground",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Foreground service channel"
            }
            val fsi = NotificationChannel(
                "lock_fsi",
                "Lock FullScreen",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Full screen lock prompt"
                enableVibration(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
            mgr?.createNotificationChannel(fg)
            mgr?.createNotificationChannel(fsi)
        }
    }
}

object AppGlobals {
    @JvmStatic
    lateinit var app: Application
        internal set
}
