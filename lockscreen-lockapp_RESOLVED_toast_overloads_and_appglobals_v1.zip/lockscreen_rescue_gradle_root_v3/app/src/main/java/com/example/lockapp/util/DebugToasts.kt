package com.example.lockapp.util

import android.content.Context
import android.widget.Toast

object DebugToasts {

    /** Overload compatible with existing call sites: DebugToasts.toast(context, "message") */
    @JvmStatic
    fun toast(context: Context, message: String) {
        show(context, message)
    }

    fun toast(message: String) {
        try { AppGlobals.app?.let { Toast.makeText(it, message, Toast.LENGTH_SHORT).show() } } catch (_: Throwable) {}
    }
    fun show(context: Context, msg: String) {
        Toast.makeText(context.applicationContext, msg, Toast.LENGTH_SHORT).show()
    }
}