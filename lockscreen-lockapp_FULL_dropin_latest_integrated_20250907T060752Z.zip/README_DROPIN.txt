一体化整合包（最新）
====================
用法：
1) 将 ZIP 解压到仓库根目录（与 app/ 同级），允许覆盖同名文件。
2) 确认 CI 中没有删除根 Gradle 文件的命令（如 rm -rf settings.gradle* build.gradle*）。
3) 运行：gradle clean assembleDebug （或 ./gradlew clean assembleDebug）

本包包含：
- 根 settings.gradle.kts：已配置 pluginManagement 和 dependencyResolutionManagement 的 google()/mavenCentral()/gradlePluginPortal()。
- 根 build.gradle.kts：最小骨架（插件坐标 + clean）。
- app/build.gradle.kts：为 app 子模块应用 Android/Kotlin 插件，提供 assembleDebug 任务。
- app/proguard-rules.pro：占位。
- 源码点修文件：修复通知 FSI 构建方式、缺失类等（不改变业务逻辑）。
