package com.example.app.patchlock

enum class AppLockState { FOREGROUND, BACKGROUND, UNKNOWN }
