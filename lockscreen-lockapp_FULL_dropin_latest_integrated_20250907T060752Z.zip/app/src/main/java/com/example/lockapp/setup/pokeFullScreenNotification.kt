package com.example.lockapp.setup

import android.app.*
import android.content.*
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object FsiPoke {
    private const val CHANNEL_ID = "lock_fs_channel"
    private const val NOTIF_ID = 4201

    fun poke(context: Context) {
        ensureChannel(context)

        val pi = PendingIntent.getActivity(
            context, 1201,
            Intent(context, Class.forName("com.example.lockapp.LockScreenActivity")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("fromFsi", true)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val nb = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(getSmallIconId(context))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(Notification.CATEGORY_CALL)
            .setContentTitle("锁屏保护")
            .setContentText("全屏兜底通知已触发")
            .setAutoCancel(true)
            .setFullScreenIntent(pi, true)

        NotificationManagerCompat.from(context).notify(NOTIF_ID, nb.build())
    }

    private fun getSmallIconId(ctx: Context): Int {
        val id = ctx.resources.getIdentifier("ic_launcher", "mipmap", ctx.packageName)
        return if (id != 0) id else android.R.drawable.ic_lock_lock
    }

    private fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (mgr.getNotificationChannel(CHANNEL_ID) == null) {
                mgr.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "锁屏通知", NotificationManager.IMPORTANCE_HIGH)
                )
            }
        }
    }
}
