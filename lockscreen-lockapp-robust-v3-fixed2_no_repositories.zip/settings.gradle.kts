
pluginManagement {
    repositories {
        google()  // Ensure Google repository for Android plugins
        mavenCentral()  // Ensure Maven Central repository
        gradlePluginPortal()  // Ensure Gradle Plugin Portal
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "lockscreen-lockapp"
include(":app")
