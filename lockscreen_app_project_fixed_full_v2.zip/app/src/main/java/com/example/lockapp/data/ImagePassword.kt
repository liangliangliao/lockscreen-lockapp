package com.example.lockapp.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "image_password")
data class ImagePassword(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uri: String,
    val passwordHash: String,
    val orderIndex: Int
)