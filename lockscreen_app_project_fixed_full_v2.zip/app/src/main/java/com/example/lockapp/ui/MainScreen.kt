package com.example.lockapp.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import coil.compose.rememberAsyncImagePainter
import com.example.lockapp.LockActivity
import com.example.lockapp.data.Repo
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    val ctx = LocalContext.current
    val repo = remember { Repo(ctx) }
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf(listOf<com.example.lockapp.data.ImagePassword>()) }
    var showPwdDialog by remember { mutableStateOf(false) }
    var pendingUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var currentUri by remember { mutableStateOf<Uri?>(null) }
    var pwd by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(),
        onResult = { uris ->
            if (uris != null && uris.isNotEmpty()) {
                pendingUris = uris
                currentUri = uris.first()
                pwd = ""
                showPwdDialog = true
            }
        }
    )

    LaunchedEffect(Unit) {
        items = repo.all()
    }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                text = { Text("添加图片") }
            )
        }
    ) { inner ->
        Column(Modifier.padding(inner).fillMaxSize().padding(16.dp)) {
            Button(onClick = {
                ctx.startActivity(Intent(ctx, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }) { Text("测试锁屏 / 预览") }

            Spacer(Modifier.height(16.dp))

            LazyColumn {
                items(items) { itx ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                        Image(
                            painter = rememberAsyncImagePainter(model = itx.uri),
                            contentDescription = null,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Text("序号: ${itx.orderIndex}")
                    }
                }
            }
        }
    }

    if (showPwdDialog && currentUri != null) {
        AlertDialog(
            onDismissRequest = { /* block */ },
            title = { Text("为图片设置密码（<=100字）") },
            text = {
                OutlinedTextField(
                    value = pwd,
                    onValueChange = { if (it.length <= 100) pwd = it },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    label = { Text("密码") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val u = currentUri!!
                    scope.launch {
                        repo.addImageWithPassword(u, pwd)
                        items = repo.all()
                        // Next
                        val rest = pendingUris.drop(1)
                        if (rest.isNotEmpty()) {
                            currentUri = rest.first()
                            pendingUris = rest
                            pwd = ""
                        } else {
                            showPwdDialog = false
                            currentUri = null
                            pendingUris = emptyList()
                        }
                    }
                }) { Text("确定") }
            }
        )
    }
}