import java.io.File

plugins {
    // no root plugins
}

allprojects {
    // nothing
}