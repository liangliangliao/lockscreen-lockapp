package com.example.lockapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.lockapp.service.GatekeeperService
import com.example.lockapp.util.DebugToasts

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_rescue)

        // start foreground service
        val svc = Intent(this, GatekeeperService::class.java)
        try {
            startForegroundService(svc)
            DebugToasts.toast(this, "started foreground service")
        } catch (t: Throwable) {
            Toast.makeText(this, "failed to start service: ${t.message}", Toast.LENGTH_LONG).show()
        }

        findViewById<Button>(R.id.btn_show_now)?.setOnClickListener {
            // route through service (avoid direct activity launch issues)
            val i = Intent(this, GatekeeperService::class.java).apply {
                action = GatekeeperService.ACTION_SHOW_LOCK_NOW
            }
            try {
                startForegroundService(i)
                DebugToasts.toast(this, "requesting lock via service")
            } catch (t: Throwable) {
                Toast.makeText(this, "failed to request lock: ${t.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}
