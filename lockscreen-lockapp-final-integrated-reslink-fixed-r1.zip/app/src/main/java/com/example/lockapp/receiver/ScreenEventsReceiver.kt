package com.example.lockapp.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.lockapp.LockActivity

class ScreenEventsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Intent.ACTION_SCREEN_ON == intent.action || Intent.ACTION_USER_PRESENT == intent.action) {
            val i = Intent(context, LockActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                action = "com.example.lockapp.SHOW_LOCK"
            }
            context.startActivity(i)
        }
    }
}
