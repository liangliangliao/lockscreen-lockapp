package com.example.lockapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties

class LockActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                LockScreen(onUnlock = { finish() })
            }
        }
    }
}

@Composable
fun LockScreen(onUnlock: () -> Unit) {
    // Background image from launcher icon as placeholder
    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = android.R.drawable.screen_background_dark),
            contentDescription = null,
            modifier = Modifier.fillMaxSize()
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("请输入密码（明文）", textAlign = TextAlign.Center)
            Spacer(Modifier.height(16.dp))
            var input by remember { mutableStateOf("") }
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                label = { Text("密码") }
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = {
                onUnlock()
            }) {
                Text("解锁")
            }
        }
    }
}
