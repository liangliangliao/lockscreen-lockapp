package com.example.lockapp

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                var password by remember { mutableStateOf(loadPassword()) }
                Column(
                    Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("设置密码（明文显示）")
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("密码") }
                    )
                    Button(onClick = {
                        savePassword(password)
                    }) {
                        Text("保存密码")
                    }
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = {
                        startActivity(Intent(this@MainActivity, LockActivity::class.java).apply {
                            action = "com.example.lockapp.SHOW_LOCK"
                        })
                    }) {
                        Text("测试显示锁屏")
                    }
                }
            }
        }
    }

    private fun savePassword(pwd: String) {
        val sp = getSharedPreferences("lock_prefs", Context.MODE_PRIVATE)
        sp.edit().putString("password", pwd).apply()
    }

    private fun loadPassword(): String {
        val sp = getSharedPreferences("lock_prefs", Context.MODE_PRIVATE)
        return sp.getString("password", "") ?: ""
    }
}
