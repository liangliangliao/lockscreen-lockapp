package com.example.lockapp

import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.lockapp.util.DebugToasts

class LockScreenActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show over lockscreen, turn screen on
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }

        val root = FrameLayout(this).apply {
            val tv = TextView(context).apply { text = "Lock screen placeholder" }
            val btn = Button(context).apply {
                text = "Unlock (close)"
                setOnClickListener { finish() }
            }
            addView(tv)
            addView(btn)
        }
        setContentView(root)

        DebugToasts.toast("LockScreenActivity created")
    }
}
