package com.example.lockapp.ui

import androidx.compose.runtime.Composable

/**
 * Thin wrapper kept for compatibility with earlier code paths.
 * Delegates to [LockScreen] which already handles background & password UI.
 */
@Composable
fun LiveLockScreen(
    onEmergency: () -> Unit = {},
    onUnlock: () -> Unit = {}
) {
    LockScreen(onUnlocked = onUnlock)
}
