package com.example.lockapp.util

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.*
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Display
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.launcher.TransparentTrampolineActivity

/**
 * Minimal, additive binder: when screen turns ON, trigger lock popup via FSI.
 * It registers both DisplayManager listener and ACTION_SCREEN_ON broadcast for better coverage.
 */
object ScreenOnBinder {
    private var registered = false
    private var displayListener: DisplayManager.DisplayListener? = null
    private var br: BroadcastReceiver? = null
    private const val CH_FSI = "lock_guard_fsi_v2" // new channel for Chinese texts

    fun init(app: Context) {
        if (registered) return
        registered = true
        try {
            // Dynamic display listener
            val dm = app.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            displayListener = object : DisplayManager.DisplayListener {
                override fun onDisplayChanged(id: Int) {
                    val d = dm.getDisplay(id) ?: return
                    if (d.state == Display.STATE_ON) {
                        DebugLog.w("Screen", "Display ON detected (DisplayManager) → schedule FSI")
                        scheduleFsi(app)
                    }
                }
                override fun onDisplayAdded(id: Int) {}
                override fun onDisplayRemoved(id: Int) {}
            }
            dm.registerDisplayListener(displayListener, Handler(Looper.getMainLooper()))
        } catch (_: Throwable) {}

        // ACTION_SCREEN_ON broadcast as supplement
        try {
            br = object : BroadcastReceiver() {
                override fun onReceive(context: Context, intent: Intent) {
                    if (Intent.ACTION_SCREEN_ON == intent.action) {
                        DebugLog.w("Screen", "ACTION_SCREEN_ON received → schedule FSI")
                        scheduleFsi(app)
                    }
                }
            }
            val flt = IntentFilter().apply { addAction(Intent.ACTION_SCREEN_ON) }
            app.registerReceiver(br, flt)
        } catch (_: Throwable) {}
    }

    private fun scheduleFsi(ctx: Context) {
        // slight delay to avoid OEM suppress window right after power key
        Handler(Looper.getMainLooper()).postDelayed({
            postFsiNow(ctx)
        }, 700)
    }

    // A localized FSI sender (Chinese texts). Reuse if there's a global one; harmless if duplicated.
    @SuppressLint("MissingPermission")
    private fun postFsiNow(ctx: Context) {
        ensureFsiChannel(ctx)
        val pi = PendingIntent.getActivity(
            ctx, 2100,
            Intent(ctx, TransparentTrampolineActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .setAction("com.example.lockapp.SHOW_LOCK_FROM_FSI"),
            PendingIntent.FLAG_CANCEL_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(ctx, CH_FSI)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("全屏弹窗测试")
            .setContentText("尝试在锁屏界面弹出全屏窗口")
            .setCategory(Notification.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(Notification.DEFAULT_ALL)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setFullScreenIntent(pi, true)
            .build()
        NotificationManagerCompat.from(ctx).notify(2100, n)
        DebugLog.w("FSI", "FSI sent from ScreenOnBinder (full-screen intent)")
    }

    private fun ensureFsiChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CH_FSI) == null) {
                val ch = NotificationChannel(
                    CH_FSI, "LockApp 全屏通知（FSI）", NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "用于锁屏场景的全屏弹窗测试"
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                    enableVibration(true)
                    setSound(Settings.System.DEFAULT_NOTIFICATION_URI, null)
                }
                nm.createNotificationChannel(ch)
            }
        }
    }
}