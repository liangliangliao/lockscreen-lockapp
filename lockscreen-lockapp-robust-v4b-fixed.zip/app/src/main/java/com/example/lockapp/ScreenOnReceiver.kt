
package com.example.lockapp


import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class ScreenOnReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
    Intent.ACTION_USER_PRESENT -> {
        // User has unlocked; just record state, do NOT launch UI here.
        com.example.lockapp.data.LockStateStore.setLocked(context, false)
    }
    Intent.ACTION_SCREEN_OFF -> {
        // Screen turned off; mark locked state for next entry.
        com.example.lockapp.data.LockStateStore.setLocked(context, true)
    }
}

    }
}
