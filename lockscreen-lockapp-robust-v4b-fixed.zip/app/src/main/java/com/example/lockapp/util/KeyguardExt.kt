package com.example.lockapp.util

import android.app.KeyguardManager
import android.content.Context

fun Context.isKeyguardLocked(): Boolean =
    getSystemService(KeyguardManager::class.java)?.isKeyguardLocked == true

fun Context.isDeviceSecure(): Boolean =
    getSystemService(KeyguardManager::class.java)?.isDeviceSecure == true
