package com.example.lockapp.util


object LockVisibilityTracker {
    @Volatile var visible: Boolean = false
}
