package com.example.lockapp.setup


import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

object SetupNavigator {
    fun appDetails(ctx: Context) =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:${ctx.packageName}")
        }

    fun notificationSettings(ctx: Context): Intent =
        if (Build.VERSION.SDK_INT >= 26) {
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
            }
        } else {
            @Suppress("DEPRECATION")
            Intent("android.settings.APP_NOTIFICATION_SETTINGS").apply {
                putExtra("app_package", ctx.packageName)
                putExtra("app_uid", ctx.applicationInfo.uid)
            }
        }

    fun requestIgnoreBatteryOptimizations(ctx: Context) =
        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = Uri.parse("package:${ctx.packageName}")
        }

    fun overlayPermission(ctx: Context) =
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${ctx.packageName}"))
}
