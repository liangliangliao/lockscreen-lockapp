package com.example.lockapp
import android.app.KeyguardManager
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.ui.LiveLockScreen
import com.example.lockapp.util.LockVisibilityTracker

class LockScreenActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Cancel gatekeeper FSI notification if any
        try { NotificationManagerCompat.from(this).cancel(20001) } catch (_: Throwable) {}
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD)
        getSystemService(KeyguardManager::class.java)?.requestDismissKeyguard(this, null)
        setContent {
            LiveLockScreen(
                onEmergency = { /* optional */ },
                onUnlock = {
                    finish()
                    try { if (android.os.Build.VERSION.SDK_INT >= 21) finishAndRemoveTask() } catch (_: Throwable) {}
                }
            )
        }
    }
    override fun onStart() { super.onStart(); LockVisibilityTracker.visible = true }
    override fun onResume() { super.onResume(); LockVisibilityTracker.visible = true }
    override fun onPause() { super.onPause(); LockVisibilityTracker.visible = false }
    override fun onNewIntent(intent: android.content.Intent?) { super.onNewIntent(intent) }
    override fun onDestroy() { super.onDestroy(); LockVisibilityTracker.visible = false }
}
