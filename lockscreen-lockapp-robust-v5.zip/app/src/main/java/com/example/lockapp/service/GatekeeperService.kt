package com.example.lockapp.service
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.overlay.OverlayLockService
import com.example.lockapp.util.LockVisibilityTracker

class GatekeeperService : Service() {
    private val prefs by lazy { getSharedPreferences("gatekeeper", MODE_PRIVATE) }
    private fun lastLaunchMs(): Long = prefs.getLong("last_launch_ms", 0L)
    private fun markLaunchNow() { prefs.edit().putLong("last_launch_ms", SystemClock.elapsedRealtime()).apply() }
    private fun shouldLaunch(): Boolean = (SystemClock.elapsedRealtime() - lastLaunchMs()) > 2500L

    private companion object {
        private const val NOTIF_ID_GATEKEEPER = 20001
        private const val CH_ID = "gatekeeper_alert_v3"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Single entry point to show gate (you can wire this from your receivers)
        showGate(this)
        return START_NOT_STICKY
    }

    private fun notifyFullScreen(context: Context, pendingIntent: PendingIntent) {
        val nm = context.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CH_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CH_ID, "Gate prompt", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Wake and present lock screen"
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                    setBypassDnd(true)
                }
            )
        }
        val n = NotificationCompat.Builder(context, CH_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("需要解锁")
            .setContentText("点击或自动弹出解锁界面")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setDefaults(Notification.DEFAULT_ALL)
            .setCategory(Notification.CATEGORY_CALL)
            .setFullScreenIntent(pendingIntent, true)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(context).notify(NOTIF_ID_GATEKEEPER, n)
    }

    private fun showGate(context: Context) {
        val intent = Intent(context, LockScreenActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        val pi = PendingIntent.getActivity(
            context, 1, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // Decide immediately based on device lock state
        val km = context.getSystemService(KeyguardManager::class.java)
        val isLocked = (km?.isKeyguardLocked == true) || (km?.isDeviceLocked == true)
        if (isLocked) {
            if (shouldLaunch()) {
                notifyFullScreen(context, pi)
                markLaunchNow()
            }
        } else {
            if (Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(context)) {
                if (shouldLaunch()) {
                    OverlayLockService.show(context)
                    markLaunchNow()
                }
            }
        }

        // Delayed fallback 1.5s: only if still locked and not visible and debounce passes
        Handler(Looper.getMainLooper()).postDelayed({
            val km2 = context.getSystemService(KeyguardManager::class.java)
            val lockedNow = (km2?.isKeyguardLocked == true) || (km2?.isDeviceLocked == true)
            if (!LockVisibilityTracker.visible && lockedNow && shouldLaunch()) {
                notifyFullScreen(context, pi)
                markLaunchNow()
            }
        }, 1500)
    }
}
