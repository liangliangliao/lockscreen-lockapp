package com.example.lockapp.setup

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class SetupGuideActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface {
                    GuideScreen(
                        onCreateChannel = { ensureMainChannel(this) },
                        onSeed = { postSeedNotification(this) },
                        onOpenNoti = { openAppNotificationSettings(this) },
                        onExactAccess = { requestExactAlarmAccess(this) },
                        onScheduleExact = { scheduleOneExactAlarm(this) },
                        onTestFullscreen = { pokeFullScreenNotification(this) }
                    )
                }
            }
        }
    }
}

@Composable
private fun GuideScreen(
    onCreateChannel: () -> Unit,
    onSeed: () -> Unit,
    onOpenNoti: () -> Unit,
    onExactAccess: () -> Unit,
    onScheduleExact: () -> Unit,
    onTestFullscreen: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("设置引导（锁屏通知 & 精确闹钟）", style = MaterialTheme.typography.titleLarge)
        Text("按顺序点击以下按钮完成系统设置，让应用能在三星锁屏稳定弹出:", style = MaterialTheme.typography.bodyMedium)

        Button(onClick = onCreateChannel) { Text("① 创建通知渠道（HIGH + 锁屏可见）") }
        Button(onClick = onSeed) { Text("② 发送一条测试通知（播种，让系统显示本应用）") }
        Button(onClick = onOpenNoti) { Text("③ 打开本应用通知设置（含锁屏显示开关）") }

        Divider()
        Text("精确闹钟（Android 12+ 建议开启）：", style = MaterialTheme.typography.titleMedium)
        Button(onClick = onExactAccess) { Text("④ 申请精确闹钟特殊访问权限") }
        Button(onClick = onScheduleExact) { Text("⑤ 调度一次精确闹钟（帮助系统识别）") }

        Divider()
        Button(onClick = onTestFullscreen) { Text("测试：触发全屏通知拉起锁屏弹窗") }
    }
}