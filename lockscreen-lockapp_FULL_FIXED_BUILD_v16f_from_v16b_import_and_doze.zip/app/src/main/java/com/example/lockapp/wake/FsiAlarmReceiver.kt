
package com.example.lockapp.wake

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.lockapp.util.DebugLog
import com.example.lockapp.util.ScreenOnBinder

class FsiAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if ("com.example.lockapp.ACTION_FSI_ALARM" != intent.action) return
        DebugLog.w("FSI", "Alarm fired → posting FSI (fallback)")
        try {
            val m = ScreenOnBinder::class.java.getDeclaredMethod("postFsiNow", Context::class.java)
            m.isAccessible = true
            m.invoke(null, ctx.applicationContext)
        } catch (t: Throwable) {
            DebugLog.e("FSI", "Invoke postFsiNow via reflection failed: ${t.message}", t)
        }
    }
}
