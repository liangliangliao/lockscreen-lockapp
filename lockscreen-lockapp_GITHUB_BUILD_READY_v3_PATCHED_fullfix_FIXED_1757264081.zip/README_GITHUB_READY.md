# LockApp – GitHub Ready Source

Build tag: **LOCKAPP-GITHUB-READY-20250907T023922Z**

This package contains minimal, conservative fixes to unblock Gradle build:
- Unified `R` namespace to `com.example.lockapp` (removed `import android.R`).
- Correct FSI usage: `.setFullScreenIntent(pi, true)` chained on `NotificationCompat.Builder`.
- Always pass `builder.build()` to `notify()/startForeground()`; fixed `.build` -> `.build()`.
- Unified small icon: `R.mipmap.ic_launcher` and added a fallback `mipmap-anydpi-v26/ic_launcher.xml`.
- Kept existing package structure to avoid business logic changes.

## How to build on GitHub
1. Commit all files in this archive to your repository root (overwriting existing ones).
2. Ensure the workflow below exists at `.github/workflows/android.yml`.
3. Trigger the workflow. In the logs, search for `LOCKAPP-GITHUB-READY-20250907T023922Z` to confirm the new code was used.

## Local build
```
./gradlew clean
./gradlew assembleDebug --no-daemon
```
