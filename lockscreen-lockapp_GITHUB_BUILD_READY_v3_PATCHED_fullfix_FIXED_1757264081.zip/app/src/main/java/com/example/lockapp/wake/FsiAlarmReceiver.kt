// BUILD TAG: LOCKAPP-FSI-FIX-CI-20250907T021838Z
package com.example.lockapp.wake
import com.example.lockapp.util.setFullScreenIntent
import com.example.lockapp.R
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import com.example.lockapp.util.Toaster

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.lockapp.util.DebugLog

/**
 * 闹钟兜底接收器：不依赖 ScreenOnBinder，直接发送一次 FSI 全屏通知。
 */
class FsiAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        if ("com.example.lockapp.ACTION_FSI_ALARM" != intent.action) return
        
        Toaster.show5s(ctx, "兜底闹钟触发：尝试发送全屏弹窗")
DebugLog.w("FSI", "Alarm fired → posting FSI (fallback)")
        try {
            postFsiNow(ctx.applicationContext)
        } catch (t: Throwable) {
            DebugLog.e("FSI", "postFsiNow failed: ${t.message}", t)
        }
    }

    private fun postFsiNow(ctx: Context) {
        Toaster.show5s(ctx, "正在发送全屏弹窗（FSI）[AlarmFallback]")
ensureFsiChannel(ctx)

        val launchIntent = Intent().apply {
            // 如你的透明跳板类名不同，请改为真实完整类名
            setClassName(ctx, "com.example.lockapp.launcher.TransparentTrampolineActivity")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            action = "com.example.lockapp.SHOW_LOCK_FROM_FSI"
            putExtra("from_fsi", true)
        }

        val pi = PendingIntent.getActivity(
            ctx,
            2101,
            launchIntent,
            PendingIntent.FLAG_CANCEL_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val n = androidx.core.app.NotificationCompat.Builder(ctx, FSI_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("全屏弹窗测试")
            .setContentText("尝试在锁屏界面弹出全屏窗口")
            .setCategory(Notification.CATEGORY_CALL)
            .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
            .setDefaults(Notification.DEFAULT_ALL)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            
Toaster.show5s(ctx, "正在发送全屏弹窗（FSI）")
.build()er.setFullScreenIntent(pi, true)
            .build()

        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(2101, n.build())
        DebugLog.w("FSI", "FSI sent from FsiAlarmReceiver (fallback)")
    }

    private fun ensureFsiChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(FSI_CHANNEL_ID) == null) {
                val ch = NotificationChannel(
                    FSI_CHANNEL_ID,
                    "LockApp 全屏通知（FSI）",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "用于锁屏场景的全屏弹窗测试"
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
                nm.createNotificationChannel(ch)
            }
        }
    }

    companion object {
        private const val FSI_CHANNEL_ID = "lock_guard_fsi_v2"
    }
}