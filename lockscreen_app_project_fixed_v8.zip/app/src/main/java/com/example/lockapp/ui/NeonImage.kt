package com.example.lockapp.ui

import android.graphics.RenderEffect
import android.graphics.Shader
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import coil.compose.AsyncImage

/**
 * Displays an image loaded via Coil with a bouncy, glowing animation reminiscent of
 * neon signage. The image scales up and down while applying a blur-based glow effect.
 * Use this composable on the lock screen to draw attention to the current image.
 *
 * @param model the model passed to Coil's AsyncImage (e.g. a URI string)
 * @param modifier optional modifier applied to the image container
 */
@Composable
fun NeonAnimatedImage(model: Any, modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "neon")
    val scale by infinite.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
        ),
        label = "scale"
    )
    val glow by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 20f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
        ),
        label = "glow"
    )
    AsyncImage(
        model = model,
        contentDescription = null,
        modifier = modifier.graphicsLayer {
            scaleX = scale
            scaleY = scale
            shadowElevation = glow
            // Apply a blur effect around the image to simulate neon glow
            renderEffect = RenderEffect.createBlurEffect(glow, glow, Shader.TileMode.CLAMP)
        },
        // We don't specify contentScale here to allow default sizing; caller should set size
    )
}