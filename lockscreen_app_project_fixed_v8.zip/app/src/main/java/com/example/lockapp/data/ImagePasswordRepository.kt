package com.example.lockapp.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

/**
 * Repository layer over [ImagePasswordDao], encapsulating common business logic such as
 * computing the next order index when inserting a new record.
 */
class ImagePasswordRepository(private val dao: ImagePasswordDao) {
    /** Reactive stream of all stored image/password entries, ordered by [ImagePassword.orderIndex]. */
    val entries: Flow<List<ImagePassword>> = dao.getAll()

    /**
     * Inserts a new record or updates an existing one. When creating a new entry the next
     * available [orderIndex] is automatically chosen.
     * @param uri the content URI of the image
     * @param password the user defined password bound to this image
     * @param existing optional existing record to replace; if null a new record is created
     */
    suspend fun insertOrUpdate(uri: String, password: String, existing: ImagePassword? = null) {
        withContext(Dispatchers.IO) {
            if (existing != null) {
                dao.upsert(existing.copy(uri = uri, password = password))
            } else {
                val current = dao.getAllOnce()
                val nextOrder = (current.maxOfOrNull { it.orderIndex } ?: -1) + 1
                dao.upsert(ImagePassword(uri = uri, password = password, orderIndex = nextOrder))
            }
        }
    }

    /** Updates an existing entry. */
    suspend fun update(entry: ImagePassword) {
        withContext(Dispatchers.IO) { dao.upsert(entry) }
    }

    /** Deletes the given entry. */
    suspend fun delete(entry: ImagePassword) {
        withContext(Dispatchers.IO) { dao.delete(entry) }
    }

    /** Retrieves all entries once. */
    suspend fun getAllOnce(): List<ImagePassword> = withContext(Dispatchers.IO) { dao.getAllOnce() }
}