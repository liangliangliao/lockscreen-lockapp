package com.example.lockapp.data

import androidx.room.*

@Dao
interface ImagePasswordDao {
    @Query("SELECT * FROM image_password ORDER BY orderIndex ASC")
    suspend fun getAllOnce(): List<ImagePassword>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: ImagePassword)

    @Delete
    suspend fun delete(item: ImagePassword)

    @Update
    suspend fun update(item: ImagePassword)

    @Query("SELECT COUNT(*) FROM image_password")
    suspend fun count(): Int
}