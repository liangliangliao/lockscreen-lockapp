package com.example.lockapp

import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.lockapp.data.ImageStore
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.util.DebugToasts

class LockScreenActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lock_rescue)

        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        )

        val imageView = findViewById<ImageView>(R.id.bg_image)
        val pwdEt = findViewById<EditText>(R.id.lock_pwd)
        val btn = findViewById<Button>(R.id.btn_unlock)
        val imageStore = ImageStore(this)
        val lockStore = LockStateStore(this)

        // Use current (do not advance) background until successful unlock
        val bgUri: Uri = imageStore.selectBackground(advance = false)
        try {
            imageView.setImageURI(bgUri)
            if (imageView.drawable == null) throw IllegalStateException("null drawable")
        } catch (_:Throwable) {
            imageView.setImageResource(R.drawable.ic_launcher_foreground)
        }

        btn.setOnClickListener {
            val ok = pwdEt.text.toString() == lockStore.getPassword()
            if (ok) {
                DebugToasts.show(this, "Unlocked")
                // advance background only after success
                imageStore.selectBackground(advance = true)
                finish()
            } else {
                DebugToasts.show(this, "Wrong password")
            }
        }
    }
}