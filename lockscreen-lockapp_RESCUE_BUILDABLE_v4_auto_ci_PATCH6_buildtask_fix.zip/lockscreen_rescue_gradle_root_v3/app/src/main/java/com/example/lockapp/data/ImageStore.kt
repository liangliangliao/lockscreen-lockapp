package com.example.lockapp.data

import android.content.Context
import android.net.Uri
import android.preference.PreferenceManager
import com.example.lockapp.R
import kotlin.random.Random

class ImageStore(private val context: Context) {
    private val prefs = PreferenceManager.getDefaultSharedPreferences(context)
    private val KEY_LIST = "image_list_uris"
    private val KEY_LAST_INDEX = "image_last_index"
    private val KEY_ROTATION = "image_rotation_mode" // "SEQUENTIAL" or "RANDOM"

    fun getRotationMode(): RotationMode {
        val raw = prefs.getString(KEY_ROTATION, RotationMode.SEQUENTIAL.name) ?: RotationMode.SEQUENTIAL.name
        return runCatching { RotationMode.valueOf(raw) }.getOrDefault(RotationMode.SEQUENTIAL)
    }

    fun setRotationMode(mode: RotationMode) {
        prefs.edit().putString(KEY_ROTATION, mode.name).apply()
    }

    fun setImages(uris: List<String>) {
        prefs.edit().putString(KEY_LIST, uris.joinToString("|")).apply()
    }

    fun getImages(): List<String> {
        val s = prefs.getString(KEY_LIST, "") ?: ""
        return s.split("|").filter { it.isNotBlank() }
    }

    fun getLastIndex(): Int = prefs.getInt(KEY_LAST_INDEX, -1)
    fun setLastIndex(i: Int) { prefs.edit().putInt(KEY_LAST_INDEX, i).apply() }

    /** 
     * Returns URI string for background.
     * If advance == true, we move the index according to rotation mode.
     * If list is empty, fallback to app icon.
     */
    fun selectBackground(advance: Boolean): Uri {
        val list = getImages()
        if (list.isEmpty()) {
            return Uri.parse("android.resource://${context.packageName}/${R.drawable.ic_launcher_foreground}")
        }
        val last = getLastIndex()
        val nextIdx = when (getRotationMode()) {
            RotationMode.SEQUENTIAL -> {
                if (advance) (last + 1).mod(list.size) else if (last in list.indices) last else 0
            }
            RotationMode.RANDOM -> {
                if (advance) Random.nextInt(list.size) else if (last in list.indices) last else 0
            }
        }
        if (advance) setLastIndex(nextIdx)
        val pick = list[if (advance) nextIdx else (if (last in list.indices) last else nextIdx)]
        return Uri.parse(pick)
    }
}