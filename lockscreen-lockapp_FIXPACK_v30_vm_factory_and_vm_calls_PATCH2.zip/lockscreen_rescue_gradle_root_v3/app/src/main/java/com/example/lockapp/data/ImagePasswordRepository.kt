package com.example.lockapp.data

import kotlinx.coroutines.flow.Flow

class ImagePasswordRepository(private val dao: ImagePasswordDao) {

    fun all(): Flow<List<ImagePassword>> = dao.all()

    suspend fun insert(entity: ImagePassword): Long = dao.insert(entity)

    suspend fun update(entity: ImagePassword) = dao.update(entity)

    suspend fun delete(entity: ImagePassword) = dao.delete(entity)

    suspend fun clear() = dao.clear()

    /**
     * Insert a new record or update an existing one.
     * Priority:
     * 1) If a row with the same uri exists -> update its password/orderIndex, return its id.
     * 2) Else if entity.id != 0 -> update that row, return id.
     * 3) Else insert as new row and return new id.
     */
    suspend fun insertOrUpdate(entity: ImagePassword): Long {
        // Try dedup by uri when creating new entities (id == 0)
        val existingByUri = if (entity.id == 0L) dao.findByUri(entity.uri) else null
        return if (existingByUri != null) {
            val merged = existingByUri.copy(
                uri = entity.uri,
                password = entity.password,
                orderIndex = entity.orderIndex
            )
            dao.update(merged)
            existingByUri.id
        } else {
            if (entity.id == 0L) {
                dao.insert(entity)
            } else {
                dao.update(entity)
                entity.id
            }
        }
    }

    suspend fun insertOrUpdate(uri: String, password: String, existing: ImagePassword? = null): Long {
        val current = existing ?: dao.findByUri(uri)
        val entity = if (current != null) {
            current.copy(uri = uri, password = password)
        } else {
            ImagePassword(uri = uri, password = password, orderIndex = 0)
        }
        return insertOrUpdate(entity)
    }
}
