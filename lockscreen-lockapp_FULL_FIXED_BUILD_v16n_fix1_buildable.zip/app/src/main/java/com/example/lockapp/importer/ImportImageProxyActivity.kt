
package com.example.lockapp.importer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import com.example.lockapp.util.DebugLog

class ImportImageProxyActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(0,0)
        super.onCreate(savedInstanceState)
        var ok = false
        try {
            val act = intent?.action
            val type = intent?.type ?: ""
            if (Intent.ACTION_SEND == act && type.startsWith("image/")) {
                val uri = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                if (uri != null) ok = ImageImportCoordinator.handlePickedImage(this, uri)
            } else if ((Intent.ACTION_VIEW == act || Intent.ACTION_OPEN_DOCUMENT == act) && type.startsWith("image/")) {
                val uri = intent.data
                if (uri != null) ok = ImageImportCoordinator.handlePickedImage(this, uri)
            }
        } catch (t: Throwable) {
            DebugLog.e("Img", "proxy import failed: ${t.message}", t)
        }
        if (!ok) {
            DebugLog.w("Img", "proxy import no-op (action/type mismatch)")
        }
        finish()
        overridePendingTransition(0,0)
    }
}
