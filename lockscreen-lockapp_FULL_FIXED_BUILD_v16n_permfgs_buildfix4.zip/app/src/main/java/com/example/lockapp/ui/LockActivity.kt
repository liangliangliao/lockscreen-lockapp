package com.example.lockapp.ui
import com.example.lockapp.util.Toaster

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import androidx.compose.material3.MaterialTheme

class LockActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val fromFsi = intent?.getBooleanExtra("from_fsi", false) == true || "com.example.lockapp.SHOW_LOCK_FROM_FSI" == intent?.action
if (!fromFsi) { Toaster.show5s(this, "伪锁屏：拒绝非FSI进入"); finish(); return }
// edge-to-edge to let preview全屏
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            MaterialTheme {
                LockScreen(onUnlock = { finish() })
            }
        }
    }
}
