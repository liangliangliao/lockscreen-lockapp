package com.example.lockapp.patchlock
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.lockapp.service.GatekeeperService
import com.example.lockapp.util.DebugTracer

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        
        DebugTracer.w("BootReceiver", "onReceive action="+(intent?.action ?: ""))
        try { DebugTracer.notify(context, "Trace", "BootReceiver onReceive") } catch (t: Throwable) { }
try {
            ContextCompat.startForegroundService(context, Intent(context, GatekeeperService::class.java))
        } catch (_: Throwable) {
            try { context.startService(Intent(context, GatekeeperService::class.java)) } catch (_: Throwable) {}
        }
    }
}