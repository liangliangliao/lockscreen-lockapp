package com.example.lockapp.wake
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.lockapp.ordered.WakeOrderedReceiver
import com.example.lockapp.service.GatekeeperService
import com.example.lockapp.util.DebugLog
import com.example.lockapp.util.LockFsNotifier
import com.example.lockapp.util.DebugTracer

class AlarmWakeReceiver : BroadcastReceiver() {
    companion object { const val ACTION_ALARM_WAKE = "com.example.lockapp.ACTION_ALARM_WAKE" }
    override fun onReceive(context: Context, intent: Intent) {
        
        DebugTracer.w("AlarmWakeReceiver", "onReceive action="+(intent?.action ?: ""))
        try { DebugTracer.notify(context, "Trace", "AlarmWakeReceiver onReceive") } catch (t: Throwable) { }
val action = intent.action ?: return
        DebugLog.i("AlarmWakeReceiver", "收到广播: $action")
        if (ACTION_ALARM_WAKE == action) {
            try {
                val svc = Intent(context, GatekeeperService::class.java).apply { putExtra("reason", "alarm_wake") }
                if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(svc) else context.startService(svc)
                DebugLog.i("AlarmWakeReceiver", "已启动/唤醒 GatekeeperService（reason=alarm_wake）")
            } catch (t: Throwable) { DebugLog.e("AlarmWakeReceiver", "启动服务失败: ${t.message}", t) }

            try {
                val br = Intent(WakeOrderedReceiver.ACTION_WAKE_ORDERED).addFlags(Intent.FLAG_RECEIVER_FOREGROUND)
                context.sendOrderedBroadcast(br, null)
                DebugLog.i("AlarmWakeReceiver", "已发送前台有序广播：ACTION_WAKE_ORDERED（模拟卸载路径）")
            } catch (t: Throwable) { DebugLog.e("AlarmWakeReceiver", "发送有序广播失败: ${t.message}", t) }

            try { LockFsNotifier.showDebugHeadsUp(context, "闹钟触发", "已拉起服务并发送前台有序广播") } catch (_: Throwable) {}
        }
    }
}