package com.example.lockapp.util
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.content.Context
import android.content.Intent
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R

import android.util.Log

object DebugLog {
    private const val TAG_BASE = "LOCKAPP/DEBUG"

    @JvmStatic fun i(tag: String, msg: String) { Log.i("$TAG_BASE/$tag", msg); Log.w("$TAG_BASE/$tag", "[I] " + msg) }
    @JvmStatic fun d(tag: String, msg: String) { Log.d("$TAG_BASE/$tag", msg); Log.w("$TAG_BASE/$tag", "[D] " + msg) }
    @JvmStatic fun w(tag: String, msg: String, tr: Throwable? = null) { if (tr != null) Log.w("$TAG_BASE/$tag", msg, tr) else Log.w("$TAG_BASE/$tag", msg) }
    @JvmStatic fun e(tag: String, msg: String, tr: Throwable? = null) {
        if (tr!=null) Log.e("$TAG_BASE/$tag", msg, tr) else Log.e("$TAG_BASE/$tag", msg)
    }
}