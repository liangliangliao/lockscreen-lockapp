package com.example.lockapp

import android.app.KeyguardManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.lockapp.util.DebugToasts

class LockScreenActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // show on top of lockscreen
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val km = getSystemService(KeyguardManager::class.java)
            km?.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }

        setContentView(R.layout.activity_lock_rescue)
        DebugToasts.toast(this, "lock activity started")

        val pwd = findViewById<EditText>(R.id.lock_pwd)
        val btn = findViewById<Button>(R.id.btn_unlock)
        btn?.setOnClickListener {
            val input = pwd?.text?.toString() ?: ""
            if (input == "1234") { // demo password
                DebugToasts.toast(this, "unlock success -> finishing")
                finish()
            } else {
                Toast.makeText(this, "wrong password", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onBackPressed() {
        // disable back
    }
}
