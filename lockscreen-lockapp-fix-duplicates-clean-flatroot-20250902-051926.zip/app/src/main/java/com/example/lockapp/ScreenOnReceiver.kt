
package com.example.lockapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.lockapp.ui.LockActivity
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.data.LockConfigStore
import com.example.lockapp.data.ActiveLockStore

class ScreenOnReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (LockStateStore.isLocked(context) && LockConfigStore.isArmed(context)) {
            val i = Intent(context, LockActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            val pwd = ActiveLockStore.getPwd(context)
            if (!pwd.isNullOrEmpty()) context.startActivity(i)
        }
    }
}
