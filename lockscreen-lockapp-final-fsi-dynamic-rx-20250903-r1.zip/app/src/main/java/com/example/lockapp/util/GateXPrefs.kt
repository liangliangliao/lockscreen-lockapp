package com.example.lockapp.util
import android.content.Context
object GateXPrefs {
    private const val FILE = "gatex_prefs"
    private const val KEY_PENDING = "pending_lock"
    private fun prefs(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    fun setPending(ctx: Context, pending: Boolean) {
        prefs(ctx).edit().putBoolean(KEY_PENDING, pending).apply()
    }
    fun consumePending(ctx: Context): Boolean {
        val p = prefs(ctx)
        val v = p.getBoolean(KEY_PENDING, false)
        if (v) p.edit().putBoolean(KEY_PENDING, false).apply()
        return v
    }
}
