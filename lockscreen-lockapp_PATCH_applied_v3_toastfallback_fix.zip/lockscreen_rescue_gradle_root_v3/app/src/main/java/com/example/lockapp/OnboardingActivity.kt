
package com.example.lockapp

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.lockapp.data.ImageStore
import com.example.lockapp.util.DebugToasts

class OnboardingActivity: AppCompatActivity() {

    private lateinit var store: ImageStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ImageStore(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24,24,24,24)
        }

        root.addView(TextView(this).apply{ text="首次使用：请授予通知、关闭电池优化、允许悬浮/全屏等"; textSize=18f })

        val notifBtn = Button(this).apply {
            text = "打开通知权限"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 2001)
                } else {
                    DebugToasts.toast("无需申请通知权限")
                }
            }
        }
        root.addView(notifBtn)

        val batteryBtn = Button(this).apply {
            text = "电池不受限制设置"
            setOnClickListener {
                try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Throwable) {}
            }
        }
        root.addView(batteryBtn)

        val done = Button(this).apply {
            text = "已完成设置，进入应用"
            setOnClickListener {
                store.setOnboardingDone(true)
                finish()
            }
        }
        root.addView(done)

        setContentView(root)
    }
}
