package com.example.lockapp.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.lockapp.R
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.util.DebugToasts

/**
 * Foreground service that stays alive (when explicitly started from the app)
 * and registers a screen-on receiver to post a full‑screen notification which
 * launches the lock UI.
 *
 * START_NOT_STICKY ensures it will NOT auto-restart after kill / reboot.
 */
class GatekeeperService : Service() {

    companion object {
        const val ACTION_START = "com.example.lockapp.action.START_GUARD"
        const val ACTION_STOP = "com.example.lockapp.action.STOP_GUARD"
        private const val CHANNEL_ID = "lock_guard_channel"
        private const val NOTIF_ID = 1001
    }

    private var screenReceiver: BroadcastReceiver? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startAsForeground()
        DebugToasts.toast("GatekeeperService created / foreground")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                registerScreenReceiver()
                DebugToasts.toast("receiver registered")
            }
            ACTION_STOP -> {
                unregisterScreenReceiver()
                stopForeground(true)
                stopSelf()
            }
            else -> {
                // Do nothing – keep it minimal to avoid unexpected auto-run
            }
        }
        DebugToasts.toast("gatekeeperservice started")
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        DebugToasts.toast("GatekeeperService task removed -> stopSelf")
        unregisterScreenReceiver()
        stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterScreenReceiver()
    }

    // ---- Internals ----

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID,
                "Lock Guard",
                NotificationManager.IMPORTANCE_HIGH
            )
            ch.setSound(null, null)
            nm.createNotificationChannel(ch)
        }
    }

    private fun baseNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, LockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Lock service running")
            .setContentText("Monitoring screen on")
            .setOngoing(true)
            .setContentIntent(openApp)
            .build()
    }

    private fun startAsForeground() {
        val notif = baseNotification()
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else if (Build.VERSION.SDK_INT >= 29) {
                // Any type > Q requires explicit type only on API 34. For 29..33 call the 2-arg overload.
                startForeground(NOTIF_ID, notif)
            } else {
                startForeground(NOTIF_ID, notif)
            }
            DebugToasts.toast("started foreground service")
        } catch (t: Throwable) {
            // Fallback to 2-arg call in case type mismatch on OEM ROMs
            try {
                startForeground(NOTIF_ID, notif)
            } catch (_: Throwable) {}
        }
    }

    private fun registerScreenReceiver() {
        if (screenReceiver != null) return
        screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val action = intent?.action ?: return
                if (action == Intent.ACTION_SCREEN_ON) {
                    DebugToasts.toast("screen on -> showing lock")
                    showFullScreenLock()
                }
            }
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
        }
        registerReceiver(screenReceiver, f)
    }

    private fun unregisterScreenReceiver() {
        try {
            if (screenReceiver != null) {
                unregisterReceiver(screenReceiver)
            }
        } catch (_: Throwable) {
        } finally {
            screenReceiver = null
        }
    }

    private fun showFullScreenLock() {
        val fullScreenIntent = Intent(this, LockScreenActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("from_fullscreen", true)
        }
        val p = PendingIntent.getActivity(
            this, 1, fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Unlock required")
            .setContentText("Tap to unlock")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setFullScreenIntent(p, true)
            .setAutoCancel(true)

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(2002, builder.build())
        DebugToasts.toast("full-screen notification posted")
    }
}
