package com.example.lockapp.util

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.example.lockapp.AppGlobals

/**
 * Small helper for debug toasts that is safe to call from any thread.
 */
object DebugToasts {

    @JvmStatic
    fun toast(message: String) {
        val ctx = AppGlobals.context
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(ctx, message, Toast.LENGTH_SHORT).show()
        }
    }

    @JvmStatic
    fun toast(ctx: Context, message: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(ctx.applicationContext, message, Toast.LENGTH_SHORT).show()
        }
    }
}
