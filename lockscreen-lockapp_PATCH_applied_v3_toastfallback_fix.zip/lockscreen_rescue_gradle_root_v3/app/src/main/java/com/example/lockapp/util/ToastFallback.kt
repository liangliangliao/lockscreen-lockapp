package com.example.lockapp.util

import android.widget.Toast
import com.example.lockapp.AppGlobals

/**
 * Fallback function: allows calling plain `toast("msg")` without Context.
 * Uses Application context from AppGlobals. Safe no-op if app is null.
 */
fun toast(message: String) {
    try {
        Toast.makeText(AppGlobals.context, message, Toast.LENGTH_SHORT).show()
    } catch (_: Throwable) {}
}
