package com.example.lockapp

import java.util.concurrent.atomic.AtomicBoolean

object AppVisibilityTracker {
    private val foreground = AtomicBoolean(false)
    fun isInForeground(): Boolean = foreground.get()
    fun setForeground(value: Boolean) { foreground.set(value) }
}
