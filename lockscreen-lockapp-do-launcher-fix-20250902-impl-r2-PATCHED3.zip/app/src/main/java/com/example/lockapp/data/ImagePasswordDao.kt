package com.example.lockapp.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ImagePasswordDao {
    @Query("SELECT * FROM image_password ORDER BY orderIndex ASC")
    fun getAll(): Flow<List<ImagePassword>>

    @Query("SELECT * FROM image_password ORDER BY orderIndex ASC LIMIT 1")
    suspend fun getFirst(): ImagePassword?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: ImagePassword)

    @Delete
    suspend fun delete(item: ImagePassword)

    @Update
    suspend fun update(vararg items: ImagePassword)
}
