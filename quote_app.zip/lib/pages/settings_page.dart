import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../data/dao.dart';
import '../services/scheduler_service.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool autoFetch = false;
  final _promptCtrl = TextEditingController();
  final _apiKeyCtrl = TextEditingController();
  bool _obscureKey = true;

  final _scheduleDao = ScheduleDao();
  final _settingsDao = SettingsDao();
  final _promptDao = PromptDao();

  List<Map<String, dynamic>> schedules = [];
  final Set<int> _selectedWeekdays = {};

  @override
  void initState() { super.initState(); _load(); }

  Future _load() async {
    schedules = await _scheduleDao.allEnabled();
    final key = await _settingsDao.getApiKey();
    _apiKeyCtrl.text = key ?? '';
    final defaultPrompt = await _promptDao.getDefaultContent();
    _promptCtrl.text = defaultPrompt ?? '';
    autoFetch = await _settingsDao.getAutoFetchEnabled();
    setState(() {});
  }

  Future _addDailyTime(BuildContext context) async {
    final tm = await showTimePicker(context: context, initialTime: TimeOfDay.now());
    if (tm == null) return;
    final now = TimeOfDay.now();
    if (tm.hour < now.hour || (tm.hour == now.hour && tm.minute <= now.minute)) {
      if (!mounted) return; ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('请选择大于当前时间的时刻'))); return;
    }
    final timeStr = '${tm.hour.toString().padLeft(2,'0')}:${tm.minute.toString().padLeft(2,'0')}:00';
    final next = SchedulerService.computeNextRunAt(type: 'daily', payload: {'time': timeStr});
    schedules.add({'type': 'daily', 'payload': {'time': timeStr}, 'enabled': 1, 'next_run_at': next});
    setState(() {});
  }

  Future _addWeeklyTimes(BuildContext context) async {
    if (_selectedWeekdays.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('请先选择星期'))); return; }
    final tm = await showTimePicker(context: context, initialTime: TimeOfDay.now());
    if (tm == null) return;
    final now = DateTime.now();
    for (final wd in _selectedWeekdays) {
      if (wd == now.weekday && (tm.hour < now.hour || (tm.hour == now.hour && tm.minute <= now.minute))) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('今天的时间需大于当前时刻')));
        continue;
      }
      final timeStr = '${tm.hour.toString().padLeft(2,'0')}:${tm.minute.toString().padLeft(2,'0')}:00';
      final next = SchedulerService.computeNextRunAt(type: 'weekly', payload: {'weekday': wd, 'time': timeStr});
      schedules.add({'type': 'weekly', 'payload': {'weekday': wd, 'time': timeStr}, 'enabled': 1, 'next_run_at': next});
    }
    setState(() {});
  }

  Future _addCustomDateTime(BuildContext context) async {
    final now = DateTime.now();
    final date = await showDatePicker(context: context, firstDate: DateTime(now.year, now.month, now.day), lastDate: DateTime(now.year + 3), initialDate: now);
    if (date == null) return;
    final tm = await showTimePicker(context: context, initialTime: TimeOfDay.now());
    if (tm == null) return;
    final dt = DateTime(date.year, date.month, date.day, tm.hour, tm.minute);
    if (dt.isBefore(now)) { if (!mounted) return; ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('请选择不早于当前的时间'))); return; }
    final dateStr = DateFormat('yyyy-MM-dd').format(dt);
    final timeStr = DateFormat('HH:mm:ss').format(dt);
    schedules.add({'type': 'custom', 'payload': {'date': dateStr, 'time': timeStr}, 'enabled': 1, 'next_run_at': dt.millisecondsSinceEpoch});
    setState(() {});
  }

  String _readableSchedule(Map<String, dynamic> s) {
    final type = s['type'] as String;
    final payload = (s['payload'] is String) ? jsonDecode(s['payload'] as String) : s['payload'] as Map<String, dynamic>;
    final next = s['next_run_at'] as int?;
    final nextStr = next == null ? '-' : DateFormat('yyyy-MM-dd HH:mm').format(DateTime.fromMillisecondsSinceEpoch(next).toLocal());
    if (type == 'daily') return '每日 · ${payload['time']}  → 下一次: $nextStr';
    if (type == 'weekly') return '每周${['一','二','三','四','五','六','日'][((payload['weekday'] as int) - 1).clamp(0,6)]} · ${payload['time']}  → 下一次: $nextStr';
    return '自定义 · ${payload['date']} ${payload['time']}  → 下一次: $nextStr';
  }

  Future _saveAll() async {
    await _settingsDao.updateApiKey(_apiKeyCtrl.text.trim());
    await _settingsDao.updateAutoFetchEnabled(autoFetch);
    final p = _promptCtrl.text.trim();
    if (p.isNotEmpty) {
      await _promptDao.upsertNewDefault(p);
    }
    for (final s in schedules) {
      final type = s['type'] as String;
      final payload = (s['payload'] is String) ? jsonDecode(s['payload'] as String) : s['payload'] as Map<String, dynamic>;
      s['next_run_at'] = SchedulerService.computeNextRunAt(type: type, payload: payload);
      s['payload'] = payload;
    }
    await _scheduleDao.replaceAll(schedules);
    if (!mounted) return; ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存所有设置')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('设置'),
        actions: [
          IconButton(onPressed: _saveAll, icon: const Icon(Icons.save)),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SwitchListTile(
            title: const Text('自动获取'),
            subtitle: const Text('开启后按计划调用 API，成功即保存并通知'),
            value: autoFetch,
            onChanged: (v) => setState(() => autoFetch = v),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('OpenAI API Key', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                TextField(
                  controller: _apiKeyCtrl,
                  obscureText: _obscureKey,
                  decoration: InputDecoration(
                    hintText: 'sk-...（仅用于本地原型）',
                    suffixIcon: IconButton(
                      icon: Icon(_obscureKey ? Icons.visibility : Icons.visibility_off),
                      onPressed: () => setState(() => _obscureKey = !_obscureKey),
                    ),
                  ),
                ),
                const SizedBox(height: 6),
                const Text('更改不会立刻写入，点击右上角保存后生效。', style: TextStyle(fontSize: 12)),
              ]),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('计划管理', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  FilledButton.icon(onPressed: () => _addDailyTime(context), icon: const Icon(Icons.access_time), label: const Text('添加「每日」时间')),
                ]),
                const SizedBox(height: 12),
                Text('每周'),
                const SizedBox(height: 6),
                Wrap(spacing: 6, children: List.generate(7, (i) {
                  final wd = i + 1; // 1..7
                  final selected = _selectedWeekdays.contains(wd);
                  return FilterChip(
                    label: Text(['一','二','三','四','五','六','日'][i]),
                    selected: selected,
                    onSelected: (v) { setState(() { if (v) _selectedWeekdays.add(wd); else _selectedWeekdays.remove(wd); }); },
                  );
                })),
                const SizedBox(height: 6),
                OutlinedButton.icon(onPressed: () => _addWeeklyTimes(context), icon: const Icon(Icons.add), label: const Text('为选中星期添加时间')),
                const SizedBox(height: 12),
                Text('自定义日期时间'),
                const SizedBox(height: 6),
                OutlinedButton.icon(onPressed: () => _addCustomDateTime(context), icon: const Icon(Icons.event), label: const Text('添加自定义')),
                const Divider(height: 24),
                for (int i = 0; i < schedules.length; i++)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(_readableSchedule(schedules[i])),
                    trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () { setState(() { schedules.removeAt(i); }); }),
                  ),
                const SizedBox(height: 6),
                const Text('更改不会立刻写入，点击右上角保存后生效。', style: TextStyle(fontSize: 12)),
              ]),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('提示词', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                TextField(controller: _promptCtrl, minLines: 3, maxLines: 8, decoration: const InputDecoration(hintText: '输入提示词，点击右上角保存生效')),
                const SizedBox(height: 6),
                const Text('保存后将作为默认提示词用于后续 API 调用。', style: TextStyle(fontSize: 12)),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}
