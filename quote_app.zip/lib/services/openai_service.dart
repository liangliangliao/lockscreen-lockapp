import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' as http;
import '../data/dao.dart';
import 'package:crypto/crypto.dart';

class OpenAIService {
  static Future<String?> get apiKey async {
    final sdao = SettingsDao();
    return sdao.getApiKey();
  }

  static Future<String?> loadActivePrompt() async {
    final pdao = PromptDao();
    final p = await pdao.getDefaultContent();
    return p ?? '请返回一个真实存在的名人名言，语言=中文，长度<120 字，包含作者和出处，输出 JSON {\"quote\":\"\",\"author\":\"\",\"source\":\"\",\"year\":\"\",\"lang\":\"zh\",\"tags\":[]} 只返回 JSON。';
  }

  static Future<Map<String, dynamic>?> fetchQuote({required String prompt}) async {
    final key = await apiKey;
    if (key == null || key.isEmpty) return null;

    final uri = Uri.parse('https://api.openai.com/v1/chat/completions');
    final headers = {
      'Authorization': 'Bearer $key',
      'Content-Type': 'application/json',
    };

    final system = '你是严谨的引文助手。只输出 JSON，不要任何额外文字。JSON 字段：'
        + '{\"quote\": string, \"author\": string, \"source\": string, \"year\": string|number, \"lang\": \"zh\", \"tags\": string[]}。'
        + '若无法确定，请返回最广为人知且可考据的中文译文与作者/出处。';

    final body = {
      'model': 'gpt-4o-mini',
      'messages': [
        {'role': 'system', 'content': system},
        {'role': 'user', 'content': prompt},
      ],
      'response_format': {'type': 'json_object'},
      'temperature': 0.7,
      'max_tokens': 200,
    };

    const maxRetry = 3;
    for (int i = 0; i < maxRetry; i++) {
      try {
        final resp = await http
            .post(uri, headers: headers, body: jsonEncode(body))
            .timeout(const Duration(seconds: 30));

        if (resp.statusCode == 200) {
          final m = jsonDecode(resp.body) as Map<String, dynamic>;
          final content = (m['choices']?[0]?['message']?['content'])?.toString();
          if (content == null || content.isEmpty) return null;
          final obj = jsonDecode(content) as Map<String, dynamic>;
          return obj;
        }

        if (resp.statusCode == 429 || resp.statusCode >= 500) {
          final jitter = Random().nextInt(300);
          await Future.delayed(Duration(milliseconds: (400 * pow(2, i)).toInt() + jitter));
          continue;
        } else {
          return null;
        }
      } catch (_) {
        final jitter = Random().nextInt(300);
        await Future.delayed(Duration(milliseconds: (400 * pow(2, i)).toInt() + jitter));
      }
    }
    return null;
  }

  static Future<bool> persistQuote(Map<String, dynamic> j) async {
    final dao = QuoteDao();
    final text = (j['quote'] ?? '').toString();
    final author = (j['author'] ?? '佚名').toString();
    final source = (j['source'] ?? '未知').toString();
    final lang = (j['lang'] ?? 'zh').toString();
    final tags = (j['tags'] ?? []).toString();
    final now = DateTime.now().millisecondsSinceEpoch;
    final hash = md5.convert(utf8.encode('$text|$author')).toString();
    final row = {
      'text': text,
      'author': author,
      'source': source,
      'lang': lang,
      'tags': tags,
      'prompt_id': 0,
      'created_at': now,
      'hash': hash,
    };
    final id = await dao.insert(row);
    return id > 0;
  }
}
