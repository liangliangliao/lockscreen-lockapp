import 'dart:async';
import 'dart:convert';
import 'package:flutter/widgets.dart';
import 'package:workmanager/workmanager.dart';
import '../data/dao.dart';
import 'openai_service.dart';
import 'notification_service.dart';

const taskName = 'fetch_quote_task';

class SchedulerService {
  static Timer? _ticker;

  static Future initBackground() async {
    await Workmanager().initialize(callbackDispatcher, isInDebugMode: false);
  }

  static Future registerPeriodic({Duration frequency = const Duration(minutes: 15)}) async {
    await Workmanager().registerPeriodicTask('fetch-1', taskName, frequency: frequency, constraints: Constraints(networkType: NetworkType.connected));
  }

  static void start15sTicker(VoidCallback onTick) {
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(seconds: 15), (_) => onTick());
  }

  static void stop15sTicker() { _ticker?.cancel(); }

  static int computeNextRunAt({required String type, required Map<String, dynamic> payload, DateTime? now}) {
    now ??= DateTime.now();
    if (type == 'daily') {
      final time = (payload['time'] as String);
      final parts = time.split(':').map(int.parse).toList();
      var candidate = DateTime(now.year, now.month, now.day, parts[0], parts[1], parts[2]);
      if (candidate.isBefore(now)) candidate = candidate.add(const Duration(days: 1));
      return candidate.millisecondsSinceEpoch;
    } else if (type == 'weekly') {
      final weekday = payload['weekday'] as int;
      final time = (payload['time'] as String);
      final parts = time.split(':').map(int.parse).toList();
      int delta = (weekday - now.weekday);
      if (delta < 0) delta += 7;
      var candidate = DateTime(now.year, now.month, now.day, parts[0], parts[1], parts[2]).add(Duration(days: delta));
      if (candidate.isBefore(now)) candidate = candidate.add(const Duration(days: 7));
      return candidate.millisecondsSinceEpoch;
    } else if (type == 'custom') {
      final date = payload['date'] as String;
      final time = payload['time'] as String;
      final dt = DateTime.parse('${date}T$time');
      return dt.millisecondsSinceEpoch;
    }
    return DateTime.now().millisecondsSinceEpoch + 3600 * 1000;
  }
}

@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    try {
      final sdao = SettingsDao();
      final settings = await sdao.getOne();
      final enabled = settings != null && (settings['auto_fetch_enabled'] as int? ?? 0) == 1;
      if (!enabled) return Future.value(true);

      final prompt = await OpenAIService.loadActivePrompt();
      if (prompt == null) return Future.value(true);

      final sdaoSched = ScheduleDao();
      final due = await sdaoSched.dueSchedules(DateTime.now().millisecondsSinceEpoch);

      for (final s in due) {
        final res = await OpenAIService.fetchQuote(prompt: prompt);
        if (res != null) {
          final inserted = await OpenAIService.persistQuote(res);
          if (inserted) {
            await NotificationService.showQuote(
              id: DateTime.now().millisecondsSinceEpoch ~/ 1000,
              title: (res['author'] ?? '名人名言') as String,
              body: (res['quote'] ?? '') as String,
              increaseBadge: true,
            );
          }
        }
        final type = s['type'] as String;
        final payload = jsonDecode(s['payload'] as String) as Map<String, dynamic>;
        if (type == 'custom') {
          await sdaoSched.disable(s['id'] as int);
        } else {
          final next = SchedulerService.computeNextRunAt(type: type, payload: payload);
          await sdaoSched.updateNextRunAt(id: s['id'] as int, nextRunAt: next);
        }
      }
      return Future.value(true);
    } catch (_) {
      return Future.value(false);
    }
  });
}
