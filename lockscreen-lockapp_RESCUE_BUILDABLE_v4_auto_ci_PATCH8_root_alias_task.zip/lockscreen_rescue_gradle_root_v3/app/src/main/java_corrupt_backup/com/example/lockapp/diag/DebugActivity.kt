// BUILD TAG: LOCKAPP-FSI-FIX-CI-20250907T021838Z
package com.example.lockapp.diag
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.content.Context
import android.content.Intent
import android.app.PendingIntent
import android.app.Notification

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.lockapp.util.LockFsNotifier
import com.example.lockapp.util.DebugLog
import com.example.lockapp.R

class DebugActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_debug_tools)

        val info = findViewById<TextView>(R.id.tvInfo)
        val btnPerm = findViewById<Button>(R.id.btnRequestNotif)
        val btnTest = findViewById<Button>(R.id.btnSendHeadsup)

        info.text = "用于调试：一键申请通知权限、发送调试 heads-up 通知并写入日志。\n关键字：LOCKAPP/调试"

        btnPerm.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 33) {
                val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
                if (!granted) {
                    ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
                } else {
                    LockFsNotifier.showDebugHeadsUp(this, "权限检查", "通知权限已授予")
                    DebugLog.i("DebugActivity", "通知权限已授予（POST_NOTIFICATIONS=GRANTED）")
                }
            } else {
                LockFsNotifier.showDebugHeadsUp(this, "权限检查", "Android 13 以下无需 POST_NOTIFICATIONS")
                DebugLog.i("DebugActivity", "Android 13 以下无需 POST_NOTIFICATIONS")
            }
        }

        btnTest.setOnClickListener {
            try {
                LockFsNotifier.showDebugHeadsUp(this, "调试", "这是一个测试 heads-up 通知（检查渠道与权限是否可见）")
                DebugLog.i("DebugActivity", "发送测试 heads-up 通知：用于确认渠道与权限是否正常")
            } catch (t: Throwable) {
                DebugLog.e("DebugActivity", "发送测试 heads-up 通知失败: " + t.message, t)
            }
        }
    }
}