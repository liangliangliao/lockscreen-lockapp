
package com.example.lockapp.data

import android.content.Context
import android.content.SharedPreferences

object LockConfigStore {
    private const val PREF = "lock_config_prefs"
    private const val KEY_ARMED = "armed"

    private fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun isArmed(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_ARMED, false)

    fun setArmed(ctx: Context, armed: Boolean) {
        prefs(ctx).edit().putBoolean(KEY_ARMED, armed).apply()
    }
}
