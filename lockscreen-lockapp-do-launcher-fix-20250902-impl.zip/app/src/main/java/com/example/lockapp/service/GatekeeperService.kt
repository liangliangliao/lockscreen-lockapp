package com.example.lockapp.service

import android.app.*
import android.content.*
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.lockapp.ui.LockActivity
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.data.LockConfigStore

class GatekeeperService : Service() {

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    if (LockConfigStore.isArmed(context)) {
                        LockStateStore.setRequireUnlock(context, true)
                        cancelHeadsUp()
                    }
                }
                Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> {
                    maybePrompt()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundWithNotification()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        registerReceiver(screenReceiver, filter)
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(screenReceiver) } catch (_: Throwable) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun maybePrompt() {
        if (LockConfigStore.isArmed(this) && LockStateStore.isRequireUnlock(this)) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channelId = ensureChannel(this, nm)
            val pi = PendingIntent.getActivity(
                this, 1001,
                Intent(this, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                (PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0))
            )
            val nb = NotificationCompat.Builder(this, channelId)
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentTitle("解锁")
                .setContentText("点击以输入密码")
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setOngoing(false)
                .setAutoCancel(true)
                .setFullScreenIntent(pi, true)
                .build()
            nm.notify(1002, nb)
        }
    }

    private fun cancelHeadsUp() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(1002)
    }

    private fun startForegroundWithNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = ensureChannel(this, nm)
        val pi = PendingIntent.getActivity(
            this, 1000,
            Intent(this, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            (PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0))
        )
        val n = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("Lock 服务运行中")
            .setContentText("保护您的屏幕解锁")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1001, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(1001, n)
        }
    }

    companion object {
        private const val CHANNEL_ID = "lock_guard_channel"
        fun ensureChannel(ctx: Context, nm: NotificationManager = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager): String {
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel(
                        CHANNEL_ID, "Lock Guard", NotificationManager.IMPORTANCE_HIGH
                    ).apply {
                        description = "Lock guard notifications"
                        lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                    }
                )
            }
            return CHANNEL_ID
        }
    }
}
