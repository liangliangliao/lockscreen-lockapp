import java.io.File

buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        // No legacy plugins here; we use plugins DSL in modules
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}