package com.example.lockapp.data

import androidx.room.*

@Dao
interface ImagePasswordDao {
    @Query("SELECT * FROM ImagePassword ORDER BY orderIndex ASC")
    suspend fun getAllOnce(): List<ImagePassword>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: ImagePassword)

    @Delete
    suspend fun delete(item: ImagePassword)

    @Update
    suspend fun update(item: ImagePassword)
}