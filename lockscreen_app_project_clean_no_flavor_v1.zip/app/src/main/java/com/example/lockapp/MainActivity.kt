package com.example.lockapp

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import com.example.lockapp.ui.MainScreen
import com.example.lockapp.data.AppDatabase
import com.example.lockapp.data.ImagePassword
import kotlinx.coroutines.launch
import java.security.MessageDigest

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val db = Room.databaseBuilder(this, AppDatabase::class.java, "lockdb")
            .fallbackToDestructiveMigration()
            .build()

        setContent {
            MaterialTheme {
                Surface {
                    MainScreen(
                        onPickImages = { launchPicker { uris ->
                            // For each uri ask password and save
                            // Password dialogs are inside MainScreen; here we just callback
                        } },
                        db = db
                    )
                }
            }
        }
    }

    private fun launchPicker(onPicked: (List<Uri>) -> Unit) {
        // No-op here; actual launcher is managed in Compose (MainScreen)
    }
}