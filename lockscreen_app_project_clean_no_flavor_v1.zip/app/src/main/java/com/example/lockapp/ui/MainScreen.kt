package com.example.lockapp.ui

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import com.example.lockapp.data.AppDatabase
import com.example.lockapp.data.ImagePassword
import kotlinx.coroutines.launch
import java.security.MessageDigest

@Composable
fun MainScreen(
    onPickImages: () -> Unit = {},
    db: AppDatabase
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var showPasswordDialog by remember { mutableStateOf(false) }
    var pendingUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var currentIndex by remember { mutableStateOf(0) }
    var passwordInput by remember { mutableStateOf("") }
    var snack by remember { mutableStateOf("") }

    // Photo Picker launcher (multiple)
    val pickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(),
        onResult = { uris ->
            if (uris.isNullOrEmpty()) return@rememberLauncherForActivityResult
            // Persist permissions
            uris.forEach { tryPersist(context, it) }
            pendingUris = uris.take(50)
            currentIndex = 0
            passwordInput = ""
            showPasswordDialog = true
        }
    )

    Scaffold(
        topBar = { SmallTopAppBar(title = { Text("LockScreen App (Demo)") }) },
        snackbarHost = {
            SnackbarHost(hostState = remember { SnackbarHostState() }) { data ->
                Snackbar { Text(text = data.visuals.message) }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Button(onClick = {
                pickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            }) {
                Text("＋ 添加图片并设定密码")
            }
            Spacer(Modifier.height(12.dp))
            Text("每张图片会绑定一个密码（中文/英文100字以内），最多添加50张。")
        }
    }

    if (showPasswordDialog && currentIndex < pendingUris.size) {
        val uri = pendingUris[currentIndex]
        AlertDialog(
            onDismissRequest = { showPasswordDialog = false },
            confirmButton = {
                TextButton(onClick = {
                    val pwd = passwordInput.trim()
                    if (pwd.isEmpty() || pwd.length > 100) return@TextButton
                    scope.launch {
                        db.dao().upsert(
                            ImagePassword(
                                uri = uri.toString(),
                                passwordHash = sha256(pwd),
                                orderIndex = currentIndex
                            )
                        )
                        passwordInput = ""
                        if (currentIndex + 1 < pendingUris.size) {
                            currentIndex += 1
                        } else {
                            showPasswordDialog = false
                        }
                    }
                }) { Text("保存并下一张") }
            },
            dismissButton = {
                TextButton(onClick = {
                    showPasswordDialog = false
                }) { Text("取消") }
            },
            title = { Text("为第 ${currentIndex + 1} 张图片设定密码") },
            text = {
                Column {
                    Text(text = "URI: ${uri}")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = { if (it.length <= 100) passwordInput = it },
                        label = { Text("密码（中文/英文，≤100字）") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true
                    )
                }
            }
        )
    }
}

private fun tryPersist(context: Context, uri: Uri) {
    try {
        val flag = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        context.contentResolver.takePersistableUriPermission(uri, flag and Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
    } catch (_: Exception) { /* ignore */ }
}

private fun sha256(input: String): String {
    val md = MessageDigest.getInstance("SHA-256")
    val digest = md.digest(input.toByteArray())
    return digest.joinToString("") { "%02x".format(it) }
}