package com.example.lockapp.wake

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.lockapp.service.GatekeeperService

/**
 * 通过 AlarmManager 唤醒应用的接收器（例如自动息屏分支的延时重试）。
 * 这里只负责把服务拉起来，不在接收器里直接起界面。
 */
class AlarmWakeReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: "(null)"
        Log.i("LOCKAPP/AlarmWake", "onReceive: $action")

        // 把触发事件交给 GatekeeperService 统一处理
        val svc = Intent(context, GatekeeperService::class.java)
            .setAction(ACTION_ALARM_WAKE)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(svc)
        } else {
            context.startService(svc)
        }
    }

    companion object {
        /** 内部使用的唤醒动作（若用 AlarmManager 设置 PendingIntent，请使用这个 action） */
        const val ACTION_ALARM_WAKE = "com.example.lockapp.ACTION_ALARM_WAKE"
    }
}