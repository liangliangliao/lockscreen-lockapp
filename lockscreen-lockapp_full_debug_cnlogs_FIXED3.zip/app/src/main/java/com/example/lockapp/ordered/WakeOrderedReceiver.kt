package com.example.lockapp.ordered

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import com.example.lockapp.LockScreenActivity
import com.example.lockapp.util.LockCoordinator
import com.example.lockapp.util.LockFsNotifier
import com.example.lockapp.util.LockVisibilityTracker
import com.example.lockapp.util.DebugLog

class WakeOrderedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (ACTION_WAKE_ORDERED != intent.action) return
        try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lockapp:wakeOrdered").apply { acquire(2000) }
        } catch (_: Throwable) {}

        // 调试通知：标记已走到模拟卸载路径
        try { LockFsNotifier.showDebugHeadsUp(context, "模拟卸载路径", "WakeOrderedReceiver 已执行，locked="+LockCoordinator.isLocked(context)) } catch (_: Throwable) {}

        if (!LockCoordinator.isLocked(context)) {
            try {
                val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
                launch?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                if (launch != null) context.startActivity(launch)
                LockFsNotifier.showDebugHeadsUp(context, "刷新分支", "Receiver: bring-to-front Launcher");
                DebugLog.i("WakeOrderedReceiver", "分支：未锁屏 → 尝试将应用前台化（等价用户点击图标），已调用 startActivity(Launcher)")
            } catch (_: Throwable) {}
            return
        }

        Handler(Looper.getMainLooper()).post {
            var started = false
            try {
                val i = Intent(context, LockScreenActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .setAction("com.example.lockapp.SHOW_LOCK")
                context.startActivity(i)
                LockFsNotifier.showDebugHeadsUp(context, "锁屏分支", "Receiver: startActivity LockScreen");
                DebugLog.i("WakeOrderedReceiver", "分支：已锁屏 → 尝试直接启动锁屏界面（startActivity LockScreenActivity）")
                started = true
            } catch (_: Throwable) {}

            if (!started || !LockVisibilityTracker.visible) {
                try { LockFsNotifier.showFullScreen(context)
                LockFsNotifier.showDebugHeadsUp(context, "锁屏分支", "Receiver: FSI 兜底");
                DebugLog.i("WakeOrderedReceiver", "分支：已锁屏 → 走 FSI 全屏通知兜底（透明跳板 → 锁屏界面）") } catch (_: Throwable) {}
            }
        }
    }
    companion object { const val ACTION_WAKE_ORDERED = "com.example.lockapp.ACTION_WAKE_ORDERED" }
}