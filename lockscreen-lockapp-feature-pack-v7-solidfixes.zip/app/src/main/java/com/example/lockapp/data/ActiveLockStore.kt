
package com.example.lockapp.data

import android.content.Context

object ActiveLockStore {
    private const val PREF = "active_lock_prefs"
    private const val KEY_URI = "active_uri"
    private const val KEY_ID = "active_id"

    fun setActive(context: Context, id: Long, uri: String) {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        sp.edit().putLong(KEY_ID, id).putString(KEY_URI, uri).apply()
    }

    fun getActiveId(context: Context): Long = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getLong(KEY_ID, 0L)
    fun getActiveUri(context: Context): String? = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_URI, null)
}
