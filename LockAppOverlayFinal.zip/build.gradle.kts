plugins {
    // empty - plugins are applied in modules
}