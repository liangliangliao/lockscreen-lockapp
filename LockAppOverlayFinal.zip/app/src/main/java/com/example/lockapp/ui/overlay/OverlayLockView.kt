package com.example.lockapp.ui.overlay

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.example.lockapp.data.LockPrefs

class OverlayLockView(private val ctx: Context, private val onPassed: () -> Unit) {

    val root: FrameLayout = FrameLayout(ctx).apply {
        layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        setBackgroundColor(0xCC000000.toInt())
    }

    private fun loadBgInto(iv: ImageView) {
        try {
            val s = LockPrefs.getBgUri(ctx) ?: return
            val uri = Uri.parse(s)
            val source = if (Build.VERSION.SDK_INT >= 28) {
                ImageDecoder.createSource(ctx.contentResolver, uri)
            } else null

            val bmp: Bitmap? = if (Build.VERSION.SDK_INT >= 28) {
                ImageDecoder.decodeBitmap(source!!)
            } else {
                val input = ctx.contentResolver.openInputStream(uri)
                @Suppress("DEPRECATION")
                android.graphics.BitmapFactory.decodeStream(input).also { input?.close() }
            }
            if (bmp != null) {
                iv.setImageBitmap(bmp)
            }
        } catch (_: Throwable) { /* ignore */ }
    }

    init {
        val bg = ImageView(ctx).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        loadBgInto(bg)
        root.addView(bg)

        val panel = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(32, 32, 32, 32)
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        root.addView(panel)

        val et = EditText(ctx).apply {
            hint = "输入密码（明文）"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(24, 24, 24, 24)
            }
        }

        val btn = Button(ctx).apply {
            text = "解锁"
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(24, 8, 24, 24)
            }
            setOnClickListener {
                val expect = LockPrefs.getPassword(ctx)
                if (et.text.toString() == expect && expect.isNotEmpty()) {
                    onPassed()
                } else {
                    Toast.makeText(ctx, "密码错误", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val emergency = Button(ctx).apply {
            text = "紧急呼救"
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(24, 8, 24, 24)
            }
            setOnClickListener {
                val i = Intent(Intent.ACTION_DIAL, Uri.parse("tel:112"))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
            }
        }

        val spacer = Space(ctx).apply { layoutParams = LinearLayout.LayoutParams(1, 0, 1f) }
        panel.addView(spacer)
        panel.addView(et)
        panel.addView(btn)
        panel.addView(emergency)
        panel.addView(Space(ctx).apply { layoutParams = LinearLayout.LayoutParams(1, 0, 1f) })
    }
}