package com.example.lockapp.service.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.*
import android.graphics.PixelFormat
import android.os.Build
import android.view.WindowManager
import android.view.WindowManager.LayoutParams.*
import com.example.lockapp.data.LockPrefs
import com.example.lockapp.ui.overlay.OverlayLockView

class LockOverlayAccessibilityService : AccessibilityService() {

    private var wm: WindowManager? = null
    private var overlay: OverlayLockView? = null
    private var shown = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_USER_PRESENT -> maybeShow()
                Intent.ACTION_SCREEN_ON -> { /* wait user present */ }
                ACTION_FORCE_SHOW -> maybeShow()
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(ACTION_FORCE_SHOW)
        }
        registerReceiver(receiver, f)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        try { unregisterReceiver(receiver) } catch (_: Throwable) {}
        remove()
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}

    override fun onInterrupt() {}

    private fun maybeShow() {
        if (!LockPrefs.isEnabled(this)) return
        if (shown) return
        show()
    }

    private fun show() {
        if (overlay != null) return
        overlay = OverlayLockView(this) {
            // passed
            remove()
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= 26) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            },
            FLAG_LAYOUT_IN_SCREEN or FLAG_LAYOUT_INSET_DECOR,
            PixelFormat.TRANSLUCENT
        ).apply {
            title = "LockOverlay"
        }
        wm?.addView(overlay!!.root, lp)
        shown = true
    }

    private fun remove() {
        overlay?.let {
            try { wm?.removeView(it.root) } catch (_: Throwable) {}
        }
        overlay = null
        shown = false
    }

    companion object {
        const val ACTION_FORCE_SHOW = "com.example.lockapp.action.FORCE_SHOW"
        fun requestShow(ctx: Context) {
            ctx.sendBroadcast(Intent(ACTION_FORCE_SHOW))
        }
    }
}