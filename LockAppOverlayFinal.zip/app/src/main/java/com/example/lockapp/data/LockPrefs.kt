package com.example.lockapp.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

private val Context.dataStore by preferencesDataStore("lock_prefs")

object LockPrefs {
    private val KEY_ENABLED = booleanPreferencesKey("enabled")
    private val KEY_PASSWORD = stringPreferencesKey("password_plain")
    private val KEY_BG_URI = stringPreferencesKey("bg_uri")

    fun isEnabled(ctx: Context): Boolean = runBlocking {
        ctx.dataStore.data.first()[KEY_ENABLED] ?: false
    }

    fun getPassword(ctx: Context): String = runBlocking {
        ctx.dataStore.data.first()[KEY_PASSWORD] ?: ""
    }

    fun getBgUri(ctx: Context): String? = runBlocking {
        ctx.dataStore.data.first()[KEY_BG_URI]
    }

    fun setEnabled(ctx: Context, enabled: Boolean) = runBlocking {
        ctx.dataStore.edit { it[KEY_ENABLED] = enabled }
    }

    fun setPassword(ctx: Context, pwd: String) = runBlocking {
        ctx.dataStore.edit { it[KEY_PASSWORD] = pwd }
    }

    fun setBgUri(ctx: Context, uri: String?) = runBlocking {
        ctx.dataStore.edit { prefs ->
            if (uri == null) prefs.remove(KEY_BG_URI) else prefs[KEY_BG_URI] = uri
        }
    }
}