package com.example.lockapp.ui

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.lockapp.R
import com.example.lockapp.data.LockPrefs
import com.example.lockapp.service.accessibility.LockOverlayAccessibilityService
import com.example.lockapp.ui.setup.SetupWizardActivity
import com.example.lockapp.util.Permissions

class MainActivity : AppCompatActivity() {

    private lateinit var etPassword: EditText
    private lateinit var ivPreview: ImageView
    private lateinit var cbEnable: CheckBox
    private var pickedUri: Uri? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            pickedUri = uri
            ivPreview.setImageURI(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etPassword = findViewById(R.id.etPassword)
        ivPreview = findViewById(R.id.ivPreview)
        cbEnable = findViewById(R.id.cbEnable)

        // Load existing
        etPassword.setText(LockPrefs.getPassword(this))
        LockPrefs.getBgUri(this)?.let { ivPreview.setImageURI(Uri.parse(it)) }
        cbEnable.isChecked = LockPrefs.isEnabled(this)

        findViewById<Button>(R.id.btnPick).setOnClickListener {
            pickImage.launch(arrayOf("image/*"))
        }

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            val pwd = etPassword.text.toString()
            LockPrefs.setPassword(this, pwd)
            LockPrefs.setEnabled(this, cbEnable.isChecked)
            LockPrefs.setBgUri(this, pickedUri?.toString() ?: LockPrefs.getBgUri(this))

            if (cbEnable.isChecked) {
                val acc = ComponentName(this, LockOverlayAccessibilityService::class.java).flattenToString()
                if (!Permissions.canDrawOverlays(this) || !Permissions.isAccessibilityEnabled(this, acc)) {
                    startActivity(Intent(this, SetupWizardActivity::class.java))
                    Toast.makeText(this, "请先完成权限向导", Toast.LENGTH_SHORT).show()
                } else {
                    // 立刻试弹一次
                    LockOverlayAccessibilityService.requestShow(this)
                }
            } else {
                Toast.makeText(this, "已保存，当前未启用", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btnSetup).setOnClickListener {
            startActivity(Intent(this, SetupWizardActivity::class.java))
        }
    }
}