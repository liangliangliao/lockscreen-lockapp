package com.example.lockapp.ui.setup

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.lockapp.R
import com.example.lockapp.service.accessibility.LockOverlayAccessibilityService
import com.example.lockapp.util.Permissions

class SetupWizardActivity : AppCompatActivity() {

    private var step = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup_wizard)
        render()
        findViewById<Button>(R.id.btnGo).setOnClickListener {
            when(step){
                0 -> Permissions.requestOverlay(this)
                1 -> Permissions.requestAccessibility(this)
                2 -> Permissions.requestIgnoreBatteryOptimizations(this)
                else -> { finish(); }
            }
        }
        findViewById<Button>(R.id.btnNext).setOnClickListener {
            step++
            render()
        }
    }

    private fun render() {
        val tv = findViewById<TextView>(R.id.tvStep)
        val acc = ComponentName(this, LockOverlayAccessibilityService::class.java).flattenToString()
        step = when {
            !Permissions.canDrawOverlays(this) -> 0
            !Permissions.isAccessibilityEnabled(this, acc) -> 1
            !Permissions.isIgnoringBatteryOptimizations(this) -> 2
            else -> 3
        }
        tv.text = when(step){
            0 -> getString(R.string.step_overlay)
            1 -> getString(R.string.step_accessibility)
            2 -> getString(R.string.step_battery)
            else -> getString(R.string.step_finish)
        }
    }
}