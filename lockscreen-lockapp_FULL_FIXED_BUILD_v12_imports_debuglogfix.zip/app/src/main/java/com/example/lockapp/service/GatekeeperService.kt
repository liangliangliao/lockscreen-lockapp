package com.example.lockapp.service
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Notification
import android.app.PendingIntent
import android.hardware.display.DisplayManager
import android.view.Display
import android.app.KeyguardManager
import android.os.PowerManager
import com.example.lockapp.LockScreenActivity

import android.app.*
import android.content.*
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import com.example.lockapp.LauncherActivity
import com.example.lockapp.data.LockStateStore
import com.example.lockapp.util.LockCoordinator
import com.example.lockapp.util.LockVisibilityTracker
import android.os.Handler
import android.os.Looper

class GatekeeperService : Service() {

    // 临时前台：短时间提高优先级，过时自动降回后台
    private var tempFgHandler: Handler? = null
    private fun ensureTempForegroundFor(ms: Long) {
        if (Build.VERSION.SDK_INT < 26) return
        try {
            val nm = getSystemService(NotificationManager::class.java)
            val chId = "lock_temp_keepalive"
            if (nm.getNotificationChannel(chId) == null) {
                val ch = NotificationChannel(chId, "Lock Temp Keepalive", NotificationManager.IMPORTANCE_MIN).apply {
                    description = "Keeps lock service briefly after screen events"
                    setShowBadge(false)
                    enableLights(false)
                    enableVibration(false)
                    lockscreenVisibility = Notification.VISIBILITY_SECRET
                }
                nm.createNotificationChannel(ch)
            }
            val pi = PendingIntent.getActivity(
                this, 2101,
                Intent(this, LockScreenActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0) or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(this, "lock_temp_keepalive")
                .setSmallIcon(android.R.drawable.stat_sys_warning)
                .setContentTitle("Lock service active")
                .setContentText("Boosting reliability briefly")
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .setContentIntent(pi)
                .build()
            try { startForeground(1903, n) } catch (_: Throwable) {}
            if (tempFgHandler == null) tempFgHandler = Handler(Looper.getMainLooper())
            tempFgHandler?.removeCallbacksAndMessages(null)
            tempFgHandler?.postDelayed({ try { stopForeground(true) } catch (_: Throwable) {} }, ms.coerceAtLeast(1000))
        } catch (_: Throwable) { }
    }

    private val ACTION_BOOST = "com.example.lockapp.action.BOOST"


    private var dmListener: DisplayManager.DisplayListener? = null
    private fun registerDisplayListener() {
        try {
            val dm = getSystemService(DisplayManager::class.java) ?: return
            if (dmListener != null) return
            dmListener = object : DisplayManager.DisplayListener {
                override fun onDisplayAdded(displayId: Int) {}
                override fun onDisplayRemoved(displayId: Int) {}
                override fun onDisplayChanged(displayId: Int) {
                    try {
                        val dmLocal = getSystemService(DisplayManager::class.java) ?: return
                        val d = dmLocal.getDisplay(displayId) ?: return
                        if (d.state == Display.STATE_ON) {
                            val km = getSystemService(KeyguardManager::class.java)
                            Handler(Looper.getMainLooper()).postDelayed({
                                if (km?.isKeyguardLocked == true &&
                                    com.example.lockapp.util.LockCoordinator.isLocked(this@GatekeeperService) &&
                                    !com.example.lockapp.util.LockVisibilityTracker.visible
                                ) {
                                    val pm = getSystemService(PowerManager::class.java)
                                    val wl = try { pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lockapp:dl") } catch (_: Throwable) { null }
                                    try {
                                        if (wl != null) try { wl.acquire(500) } catch (_: Throwable) {}
                                        try { attemptShow(this@GatekeeperService) } catch (_: Throwable) {}
                                    } finally { try { if (wl != null && wl.isHeld) wl.release() } catch (_: Throwable) {} }
                                }
                            }, 180)
                        }
                    } catch (_: Throwable) {}
                }
            }
            dm.registerDisplayListener(dmListener, Handler(Looper.getMainLooper()))
        } catch (_: Throwable) {}
    }
    private fun unregisterDisplayListener() {
        try {
            val dm = getSystemService(DisplayManager::class.java) ?: return
            dmListener?.let { dm.unregisterDisplayListener(it) }
            dmListener = null
        } catch (_: Throwable) {}
    }


    private fun attemptShow(ctx: Context) {
        LockCoordinator.markLocked(ctx)
        val i = Intent(ctx, LockScreenActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)

        if (LockCoordinator.isLocked(ctx)
            && !LockVisibilityTracker.visible
            && LockCoordinator.requestShowOnce()
            && LockCoordinator.tryEnterShowing()
        ) {
            try { ctx.startActivity(i) } catch (_: Throwable) {}
        }

        Handler(Looper.getMainLooper()).postDelayed({
            if (!LockVisibilityTracker.visible && LockCoordinator.isLocked(ctx)) {
                try { com.example.lockapp.util.LockFsNotifier.showFullScreen(ctx) } catch (_: Throwable) {}
            }
        }, 120)
    }


    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> LockCoordinator.markLocked(context)
                Intent.ACTION_SCREEN_ON -> {
                        // Safety timeout: release gating if UI still not visible
                        Handler(Looper.getMainLooper()).postDelayed({
                            if (!LockVisibilityTracker.visible && LockCoordinator.isLocked(context)) {
                                try { LockCoordinator.releaseShowOnce() } catch (_: Throwable) {}
                            }
                        }, 900)
/* UI launch disabled (r6) */}
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        registerDisplayListener()
        // register screen on/off
        registerReceiver(screenReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        })
        // foreground right away
        startForegroundWithNotification()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        unregisterDisplayListener()
        super.onDestroy()
        try { unregisterReceiver(screenReceiver) } catch (_: Throwable) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startForegroundWithNotification() {
        val channelId = ensureChannel(this)
        val launchIntent = Intent(this, LauncherActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("forceLock", true)
        }
        val pi = PendingIntent.getActivity(
            this, 0, launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_lock) // always valid
            .setContentTitle("Lock screen guard")
            .setContentText("Running")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setContentIntent(pi)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(101, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            @Suppress("DEPRECATION")
            startForeground(101, notification)
        }
    }

    private fun showGate(context: Context) { /* disabled */ return
        val it = Intent(context, LauncherActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("forceLock", true)
        }
        try {
            context.startActivity(it)
        } catch (_: Throwable) {
            val chId = "gatekeeper_alert_v2"
            val nm = context.getSystemService(NotificationManager::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm.getNotificationChannel(chId) == null) {
                val ch = NotificationChannel(chId, "Gate prompt", NotificationManager.IMPORTANCE_HIGH).apply {
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            setBypassDnd(true)
                }
                nm.createNotificationChannel(ch)
            }
            val pi = PendingIntent.getActivity(
                context, 1, it,
                PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            )
            val n = NotificationCompat.Builder(context, chId)
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentTitle("需要解锁")
                .setContentText("请验证密码继续")
                .setCategory(Notification.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_MAX)
            .setDefaults(Notification.DEFAULT_ALL)
                .setFullScreenIntent(pi, true)
                .build()
            nm.notify(202, n)
        }
    }

    companion object {
        private const val FG_CHANNEL_ID = "gatekeeper_foreground"
        private const val FG_CHANNEL_NAME = "Gatekeeper"
        fun ensureChannel(ctx: Context): String {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = ctx.getSystemService(NotificationManager::class.java)
                if (nm.getNotificationChannel(FG_CHANNEL_ID) == null) {
                    val ch = NotificationChannel(
                        FG_CHANNEL_ID, FG_CHANNEL_NAME, NotificationManager.IMPORTANCE_MIN
                    ).apply {
                        setShowBadge(false)
                        lockscreenVisibility = Notification.VISIBILITY_SECRET
                    }
                    nm.createNotificationChannel(ch)
                }
            }
            return FG_CHANNEL_ID
        }
    }
}
