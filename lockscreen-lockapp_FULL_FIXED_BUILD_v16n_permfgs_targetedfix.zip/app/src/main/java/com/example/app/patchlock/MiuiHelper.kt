package com.example.app.patchlock
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R

import android.content.Context
import android.content.Intent
import android.widget.Toast

object MiuiHelper {
    fun openMiuiAutoStart(context: Context) = runCatching {
        Intent("miui.intent.action.APP_PERM_EDITOR").apply {
            setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
            putExtra("extra_pkgname", context.packageName)
        }.also { context.startActivity(it) }
    }.onFailure {
        Toast.makeText(context, "MIUI permission page not available", Toast.LENGTH_SHORT).show()
    }
}
