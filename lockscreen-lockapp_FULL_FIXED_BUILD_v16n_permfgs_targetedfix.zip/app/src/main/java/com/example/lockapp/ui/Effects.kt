package com.example.lockapp.ui
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.content.Context
import android.content.Intent
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color

@Composable
fun FireworksOverlay(modifier: androidx.compose.ui.Modifier = androidx.compose.ui.Modifier) {
    val anim = rememberInfiniteTransition(label = "fw")
    val t by anim.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(1200), repeatMode = RepeatMode.Restart),
        label = "t"
    )
    Canvas(modifier = modifier) {
        val w = size.width; val h = size.height
        val centers = listOf(
            Offset(w*0.2f, h*0.25f),
            Offset(w*0.8f, h*0.35f),
            Offset(w*0.5f, h*0.75f)
        )
        val colors = listOf(Color(0xFFFF5252), Color(0xFF40C4FF), Color(0xFFFFEB3B), Color(0xFF7C4DFF))
        centers.forEachIndexed { idx, c ->
            val radius = 40f + 160f * t
            val alpha = 1f - t
            drawCircle(color = colors[idx % colors.size].copy(alpha = alpha), radius = radius, center = c)
        }
    }
}