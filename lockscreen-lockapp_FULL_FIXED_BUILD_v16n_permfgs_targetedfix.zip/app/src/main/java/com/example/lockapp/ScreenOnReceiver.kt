package com.example.lockapp
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R
import com.example.lockapp.util.Toaster

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.lockapp.service.GatekeeperService
import com.example.lockapp.util.DebugLog
import com.example.lockapp.util.DebugTracer

class ScreenOnReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        
        Toaster.show5s(context, "检测到亮屏/解锁广播：准备调度全屏弹窗")
DebugTracer.w("ScreenOnReceiver", "onReceive action="+(intent?.action ?: ""))
        try { DebugTracer.notify(context, "Trace", "ScreenOnReceiver onReceive") } catch (t: Throwable) { }
val action = intent.action ?: return
        DebugLog.i("ScreenOnReceiver", "收到系统广播: $action")
        when (action) {
            Intent.ACTION_SCREEN_ON -> {
                DebugLog.i("ScreenOnReceiver", "ACTION_SCREEN_ON：启动/唤醒 GatekeeperService")
                startKeeper(context, "screen_on")
            }
            Intent.ACTION_SCREEN_OFF -> {
                DebugLog.i("ScreenOnReceiver", "ACTION_SCREEN_OFF：记录状态并保持服务存活")
                startKeeper(context, "screen_off")
            }
            else -> { /* ignore */ }
        }
    }
    private fun startKeeper(context: Context, reason: String) {
        try {
            val svc = Intent(context, GatekeeperService::class.java).apply { putExtra("reason", reason) }
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(svc) else context.startService(svc)
        } catch (t: Throwable) {
            com.example.lockapp.util.DebugLog.e("ScreenOnReceiver", "启动 GatekeeperService 失败: ${t.message}", t)
        }
    }
}