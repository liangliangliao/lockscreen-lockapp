package com.example.lockapp.admin
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat
import android.content.Context
import android.content.Intent
import android.app.PendingIntent
import android.app.Notification
import com.example.lockapp.R
import android.app.admin.DeviceAdminReceiver
class MyDeviceAdminReceiver : DeviceAdminReceiver()