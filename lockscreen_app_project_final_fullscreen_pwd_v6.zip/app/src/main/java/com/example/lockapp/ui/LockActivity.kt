package com.example.lockapp.ui

import android.app.KeyguardManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModelProvider
import com.example.lockapp.LockScreenApp
import com.example.lockapp.ui.theme.LockScreenAppTheme

/**
 * Activity that displays over the system keyguard when the device is locked. It uses
 * [LockScreenViewModel] to choose which image/password pair to present and verifies the
 * password before allowing the user to proceed to the main launcher.
 */
class LockActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Request that this activity appear on top of the lock screen and turn the screen on
        setShowWhenLocked(true)
        setTurnScreenOn(true)

        // Acquire the keyguard manager for requesting system dismiss of the keyguard
        val keyguardManager = getSystemService(KeyguardManager::class.java)

        // Acquire ViewModel via factory
        val viewModelFactory = LockScreenViewModelFactory(application as LockScreenApp)
        val viewModel: LockScreenViewModel by viewModels { viewModelFactory }

        setContent {
            LockScreenAppTheme {
                LockScreenContent(viewModel, keyguardManager)
            }
        }
    }

    /**
     * Called when password has been verified. Dismisses the keyguard if necessary and
     * finishes this activity. If the app is in kiosk mode (lock task) this will also
     * invoke [stopLockTask] to return to the launcher.
     */
    private fun handleUnlock(keyguardManager: KeyguardManager?) {
        // Request dismissal of the keyguard for standard variant. The system may still require
        // biometric/PIN unlock depending on device security settings.
        keyguardManager?.requestDismissKeyguard(this, null)
        // Exit lock task mode if running as device owner
        try {
            stopLockTask()
        } catch (_: Exception) {
            // Ignore if not in lock task mode
        }
        // Finish this activity to reveal the underlying launcher or last app
        finish()
    }

    /** Composable wrapper capturing the keyguard manager and invoking [handleUnlock] from Compose. */
    @Composable
    private fun LockScreenContent(viewModel: LockScreenViewModel, keyguardManager: KeyguardManager?) {
        LockScreen(onUnlock = { finish() }, ) {
            // When the password is verified, handle unlocking outside of Compose
            handleUnlock(keyguardManager)
        }
    }
}