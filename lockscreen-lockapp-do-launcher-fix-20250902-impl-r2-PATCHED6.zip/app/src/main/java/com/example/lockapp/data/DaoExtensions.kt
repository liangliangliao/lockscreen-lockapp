package com.example.lockapp.data

import kotlinx.coroutines.flow.first

/** Convenience suspend helper to fetch the current list once from a Flow DAO. */
suspend fun ImagePasswordDao.getAllOnce(): List<ImagePassword> = this.getAll().first()
