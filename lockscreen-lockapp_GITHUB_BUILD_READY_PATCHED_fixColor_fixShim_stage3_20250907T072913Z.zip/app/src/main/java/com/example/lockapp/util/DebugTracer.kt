// BUILD TAG: LOCKAPP-FSI-FIX-CI-20250907T021838Z
package com.example.lockapp.util
import android.content.Intent
import android.app.PendingIntent
import com.example.lockapp.R

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/**
 * Unified debug logger + optional heads-up notifier.
 * Toggle ENABLE_NOTIF to silence notifications while keeping logs.
 */
object DebugTracer {
    private const val TAG_BASE = "LOCKAPP/DEBUG"
    private const val CH_ID = "lockapp_debug_trace"
    private const val CH_NAME = "LockApp Debug Trace"
    private const val ENABLE_NOTIF = true
    private var inited = false

    private fun ensureChannel(ctx: Context) {
        if (inited) return
        inited = true
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CH_ID) == null) {
                val ch = NotificationChannel(CH_ID, CH_NAME, NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Debug heads-up for tracing lock flow"
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                    enableVibration(true)
                    setSound(android.provider.Settings.System.DEFAULT_NOTIFICATION_URI, null)
                }
                nm.createNotificationChannel(ch)
            }
        }
    }

    // ---- logs ----
    @JvmStatic fun i(tag: String, msg: String) {
        android.util.Log.i("$TAG_BASE/$tag", msg)
        android.util.Log.w("$TAG_BASE/$tag", "[I] $msg")
    }
    @JvmStatic fun d(tag: String, msg: String) {
        android.util.Log.d("$TAG_BASE/$tag", msg)
        android.util.Log.w("$TAG_BASE/$tag", "[D] $msg")
    }
    @JvmStatic fun w(tag: String, msg: String, tr: Throwable? = null) {
        if (tr != null) android.util.Log.w("$TAG_BASE/$tag", msg, tr)
        else android.util.Log.w("$TAG_BASE/$tag", msg)
    }
    @JvmStatic fun e(tag: String, msg: String, tr: Throwable? = null) {
        if (tr != null) android.util.Log.e("$TAG_BASE/$tag", msg, tr)
        else android.util.Log.e("$TAG_BASE/$tag", msg)
    }

    // ---- debug heads-up ----
    @JvmStatic fun notify(ctx: Context, title: String, text: String) {
        if (!ENABLE_NOTIF) return
        ensureChannel(ctx)
        val n = NotificationCompat.Builder(ctx, CH_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(ctx).notify((System.currentTimeMillis() % 100000).toInt(), n.build())
    }
}