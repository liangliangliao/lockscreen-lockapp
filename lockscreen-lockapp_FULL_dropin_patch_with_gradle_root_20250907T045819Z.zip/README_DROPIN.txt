
使用方法（直接落地到仓库根目录即可构建）
------------------------------------------------
1. 将此 ZIP 在仓库根目录解压，保持相对路径不变（与 app/ 同级包含 settings.gradle.kts、build.gradle.kts）。
2. 该包仅包含：修复编译错误的 Kotlin 源文件 + Gradle 根骨架（不会覆盖你 app/ 模块的 build.gradle、Manifest 或资源）。
3. 提交后执行：gradle clean assembleDebug （或用你的 GitHub Actions 触发构建）。

已修复要点：
- 统一使用 NotificationCompat.Builder(...).setFullScreenIntent(pi, true)
- notify(id, builder.build())（不再把 Builder 直接传给 notify）
- O+ 通知渠道 lock_fs_channel，避免 FSI/Heads-up 失效
- 小图标优先 mipmap/ic_launcher，不存在则回退系统图标
- 提供 com.example.app.patchlock.AppLifecycleHook / AppLockState 占位，避免未解析引用
