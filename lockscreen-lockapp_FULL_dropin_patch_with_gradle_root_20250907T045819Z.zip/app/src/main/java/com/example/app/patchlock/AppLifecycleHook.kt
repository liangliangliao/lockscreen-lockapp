package com.example.app.patchlock

interface AppLifecycleHook { fun install(app: android.app.Application) {} }
