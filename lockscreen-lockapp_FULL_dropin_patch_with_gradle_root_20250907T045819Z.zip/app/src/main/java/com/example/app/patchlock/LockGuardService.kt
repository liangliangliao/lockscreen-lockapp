package com.example.app.patchlock

import android.app.*
import android.content.*
import android.os.Build
import android.graphics.Color
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class LockGuardService : Service() {

    companion object {
        private const val NOTIF_ID = 4001
        private const val CHANNEL_ID = "lock_fs_channel"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val ctx = this
        ensureChannel(ctx)

        val fullScreenPi = PendingIntent.getActivity(
            ctx, 1001,
            Intent(ctx, Class.forName("com.example.lockapp.LockScreenActivity")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("fromFsi", true)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val nb = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(getSmallIconId(ctx))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(Notification.CATEGORY_CALL)
            .setContentTitle("锁屏保护")
            .setContentText("正在唤起锁屏界面…")
            .setAutoCancel(true)
            .setFullScreenIntent(fullScreenPi, true)

        NotificationManagerCompat.from(ctx).notify(NOTIF_ID, nb.build())

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIF_ID, nb.build(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST
            )
        } else {
            startForeground(NOTIF_ID, nb.build())
        }
        stopSelf()
        return START_NOT_STICKY
    }

    private fun getSmallIconId(ctx: Context): Int {
        val id = ctx.resources.getIdentifier("ic_launcher", "mipmap", ctx.packageName)
        return if (id != 0) id else android.R.drawable.ic_lock_lock
    }

    private fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (mgr.getNotificationChannel(CHANNEL_ID) == null) {
                val ch = NotificationChannel(CHANNEL_ID, "锁屏通知", NotificationManager.IMPORTANCE_HIGH)
                ch.enableLights(true)
                ch.lightColor = android.graphics.Color.WHITE
                ch.enableVibration(false)
                ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                mgr.createNotificationChannel(ch)
            }
        }
    }
}
