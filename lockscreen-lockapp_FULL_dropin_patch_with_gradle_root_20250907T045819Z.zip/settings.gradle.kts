rootProject.name = "lockscreen-lockapp"
include(":app")
