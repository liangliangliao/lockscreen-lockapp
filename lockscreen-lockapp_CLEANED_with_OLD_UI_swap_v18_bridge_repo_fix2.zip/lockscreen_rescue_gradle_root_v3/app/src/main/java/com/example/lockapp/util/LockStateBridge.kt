package com.example.lockapp.util
import com.example.lockapp.data.LockStateStore

object LockStateBridge {
    fun setLocked(v: Boolean) = LockStateStore.setLocked(v)
    fun isLocked(): Boolean = LockStateStore.isLocked()
}
