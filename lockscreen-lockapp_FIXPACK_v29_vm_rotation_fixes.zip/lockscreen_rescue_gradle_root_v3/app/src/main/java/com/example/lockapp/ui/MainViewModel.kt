package com.example.lockapp.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.lockapp.data.ImagePassword
import com.example.lockapp.data.ImagePasswordRepository
import com.example.lockapp.data.RotationManager
import com.example.lockapp.data.RotationMode
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * ViewModel for the main screen. It exposes a list of saved [ImagePassword] entries and
 * the current [RotationMode]. It also provides operations used by the UI:
 *  - [insertOrUpdate] to add/update an entry based on a picked image
 *  - [delete] to remove an entry
 *  - [setRotationMode] to persist a new rotation mode
 */
class MainViewModel(
    application: Application,
    private val repo: ImagePasswordRepository,
    private val rotationManager: RotationManager
) : AndroidViewModel(application) {

    /** Stream of entries from the repository as a hot [StateFlow]. */
    val entries: StateFlow<List<ImagePassword>> =
        repo.all()
            .map { it.sortedBy { e -> e.orderIndex } }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5_000),
                initialValue = emptyList()
            )

    /** Currently selected rotation mode. */
    val rotationMode: StateFlow<RotationMode> =
        rotationManager.rotationMode.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = RotationMode.SEQUENTIAL
        )

    /**
     * Insert a new entry or update an existing one from the picker result.
     * Matches usage in MainScreen.kt: insertOrUpdate(uri, password, existing)
     */
    fun insertOrUpdate(uri: Uri, password: String, existing: ImagePassword?) {
        viewModelScope.launch {
            if (existing == null) {
                repo.insertOrUpdate(uri.toString(), password)
            } else {
                // keep the same id/order when updating
                val updated = existing.copy(imageUri = uri.toString(), password = password)
                repo.update(updated)
            }
        }
    }

    /** Delete an entry. */
    fun delete(entry: ImagePassword) {
        viewModelScope.launch {
            repo.delete(entry)
        }
    }

    /** Persist a new rotation mode. */
    fun setRotationMode(mode: RotationMode) {
        viewModelScope.launch {
            rotationManager.setRotationMode(mode)
        }
    }
}
